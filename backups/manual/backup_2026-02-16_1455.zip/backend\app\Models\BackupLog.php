<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BackupLog extends Model
{
    protected $primaryKey = 'backup_id';

    public $timestamps = false;

    protected $fillable = [
        'backup_date',
        'backup_type',
        'file_name',
        'file_size',
        'status',
        'created_by',
        'notes',
    ];

    protected $casts = [
        'backup_date' => 'datetime',
        'file_size' => 'integer',
        'created_at' => 'datetime',
    ];

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by', 'user_id');
    }
}

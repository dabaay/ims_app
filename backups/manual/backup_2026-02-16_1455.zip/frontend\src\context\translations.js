export const translations = {
    so: {
        // Sidebar
        dashboard: 'Dashboard',
        products: 'Alaabta (Products)',
        customers: 'Macaamiisha',
        pos: 'Iibinta (POS)',
        reports: 'Warbixinada',
        expenses: 'Kharashyada',
        suppliers: 'Ganacsatada',
        accounting: 'Accounting',
        users: 'Isticmaalayaasha',
        logs: 'Logs',
        sales_history: 'Taariikhda Iibka',
        purchases: 'Iibsashada',
        walpo: 'Daymaha (Walpo)',
        settings: 'Settings',
        logout: 'Kabax (Logout)',

        // Dashboard
        welcome: 'Soo dhawaaw',
        dashboard_title: 'Dashboard-ka Guud',
        dashboard_subtitle: 'Halkan kala soco dhaqdhaqaaqa ganacsiga.',
        today_sales: 'Maanta Iibkeeda',
        new_customers: 'Macmiil Cusub',
        low_stock: 'Alaab Gabaabsi ah',
        total_customers: 'Wadarta Macaamiisha',
        total_revenue: 'Dakhliga Guud',
        estimated_profit: 'Faa\'iidada Qiyaasta',
        inventory_value: 'Qiimaha Kaydka',
        outstanding_debt: 'Deymaha Maqan',
        recent_activity: 'Dhaqdhaqaaqii U Danbeeyay',
        best_sellers: 'Alaabta ugu Iibka Badan',
        system_summary: 'Guud ahaan Nidaamka',
        see_all: 'Eeg Dhammaan',
        today: 'Maanta',
        this_week: 'Toddobaadkan',
        loading: 'Xogta waa la soo rarayaa...',
        loading_stats: 'Xogta Dashboard-ka waa la soo rarayaa...',
        last_updated: 'Ugu danbeysay',
        
        // Chart Titles
        revenue_trend: 'Isbeddelka Dakhliga',
        payment_distribution: 'Qaybinta Habka Lacag Bixinta',
        expense_breakdown: 'Kala Qaybinta Kharashyada',
        sales_vs_expenses: 'Iibka iyo Kharashyada',
        customer_growth: 'Korodhka Macaamiisha',
        inventory_status: 'Xaalada Kaydka',
        top_customers: 'Macaamiisha ugu Wanaagsan',
        debt_status: 'Xaalada Deymaha',
        monthly_revenue: 'Dakhliga Bisha',
        profit_margin: 'Faa\'iidada',
        payment_trends: 'Isbeddelka Lacag Bixinta',
        category_sales: 'Iibka Qaybaha',
        
        // Chart Labels
        sales: 'Iibka',
        expenses_label: 'Kharashyada',
        profit: 'Faa\'iido',
        revenue: 'Dakhli',
        margin: 'Faa\'iidada %',
        customers_count: 'Tirada Macaamiisha',
        transactions: 'Wax kala iibsiga',
        month: 'Bil',
        
        // Time Ranges
        this_month: 'Bisha',
        this_quarter: 'Rubuca',
        this_year: 'Sannadkan',
        last_30_days: '30 Maalmood ee u danbeeyay',
        last_90_days: '90 Maalmood ee u danbeeyay',
        
        // Common
        save: 'Keydi',
        cancel: 'Jooji',
        delete: 'Tirtir',
        edit: 'Wax ka bedel',
        add: 'Ku dar',
        search: 'Raadi...',
        no_data: 'Xog lama helin.',
        actions: 'Ficilada',
        status: 'Xaalad',
        date: 'Taariikh',
        total: 'Wadarta',
        close: 'Xir',
        confirm: 'Xaqiiji',
        view: 'Eeg',
        print: 'Daabac',
        export: 'Soo Saari',
        filter: 'Shaandhee',
        
        // Products
        product_name: 'Magaca Alaabta',
        category: 'Qaybta',
        price: 'Qiimaha',
        cost_price: 'Qiimaha Kharashka',
        selling_price: 'Qiimaha Iibka',
        stock: 'Kaydka',
        current_stock: 'Kaydka Hadda',
        barcode: 'Barcode',
        add_product: 'Ku dar Alaab Cusub',
        edit_product: 'Wax ka bedel Alaabta',
        
        // Customers
        customer_name: 'Magaca Macmiilka',
        phone: 'Telefoon',
        email: 'Email',
        address: 'Cinwaanka',
        balance: 'Haraaga',
        credit_limit: 'Xadka Deynta',
        add_customer: 'Ku dar Macmiil Cusub',
        
        // POS
        cart: 'Shanta',
        add_to_cart: 'Ku dar Shanta',
        checkout: 'Bixinta',
        payment_method: 'Habka Lacag Bixinta',
        cash: 'Lacag Caddaan',
        amount_paid: 'Lacagta la Bixiyay',
        change: 'Lacagta Beddelka',
        complete_sale: 'Dhamaystir Iibka',
        
        // Sales History
        invoice_number: 'Lambarka Invoice',
        sale_date: 'Taariikhda Iibka',
        customer: 'Macmiilka',
        amount: 'Qadarka',
        payment_status: 'Xaaladda Lacag Bixinta',
        
        // Expenses
        expense_category: 'Qaybta Kharashka',
        expense_date: 'Taariikhda Kharashka',
        description: 'Sharaxaad',
        add_expense: 'Ku dar Kharash Cusub',
        
        // Suppliers
        supplier_name: 'Magaca Ganacsatada',
        company: 'Shirkadda',
        contact: 'Xiriir',
        add_supplier: 'Ku dar Ganacsi Cusub',
        
        // Purchases
        purchase_date: 'Taariikhda Iibsashada',
        supplier: 'Ganacsatada',
        quantity: 'Tirada',
        add_purchase: 'Ku dar Iibsasho Cusub',
        
        // Walpo (Debts)
        debt_amount: 'Qadarka Deynta',
        remaining: 'Haraaga',
        paid: 'La Bixiyay',
        payment_date: 'Taariikhda Lacag Bixinta',
        add_payment: 'Ku dar Lacag Bixin',
        
        // Reports
        generate_report: 'Samee Warbixin',
        date_range: 'Muddada Taariikhda',
        from: 'Laga bilaabo',
        to: 'Ilaa',
        
        // Users
        username: 'Magaca Isticmaale',
        full_name: 'Magaca Buuxa',
        role: 'Doorka',
        password: 'Furaha Sirta',
        add_user: 'Ku dar Isticmaale Cusub',
        admin: 'Maamule',
        cashier: 'Lacag Qaade',
    },
    en: {
        // Sidebar
        dashboard: 'Dashboard',
        products: 'Products',
        customers: 'Customers',
        pos: 'Sales (POS)',
        reports: 'Reports',
        expenses: 'Expenses',
        suppliers: 'Suppliers',
        accounting: 'Accounting',
        users: 'Users',
        logs: 'Logs',
        sales_history: 'Sales History',
        purchases: 'Purchases',
        walpo: 'Debts (Walpo)',
        settings: 'Settings',
        logout: 'Logout',

        // Dashboard
        welcome: 'Welcome',
        dashboard_title: 'General Dashboard',
        dashboard_subtitle: 'Monitor your business activities here.',
        today_sales: "Today's Sales",
        new_customers: 'New Customers',
        low_stock: 'Low Stock Alert',
        total_customers: 'Total Customers',
        total_revenue: 'Total Revenue',
        estimated_profit: 'Estimated Profit',
        inventory_value: 'Inventory Value',
        outstanding_debt: 'Outstanding Debt',
        recent_activity: 'Recent Activity',
        best_sellers: 'Best Sellers',
        system_summary: 'System Modules Summary',
        see_all: 'See All',
        today: 'Today',
        this_week: 'This Week',
        loading: 'Loading data...',
        loading_stats: 'Loading Dashboard data...',
        last_updated: 'Last updated',
        
        // Chart Titles
        revenue_trend: 'Revenue Trend',
        payment_distribution: 'Payment Distribution',
        expense_breakdown: 'Expense Breakdown',
        sales_vs_expenses: 'Sales vs Expenses',
        customer_growth: 'Customer Growth',
        inventory_status: 'Inventory Status',
        top_customers: 'Top Customers',
        debt_status: 'Debt Status',
        monthly_revenue: 'Monthly Revenue',
        profit_margin: 'Profit Margin',
        payment_trends: 'Payment Trends',
        category_sales: 'Category Sales',
        
        // Chart Labels
        sales: 'Sales',
        expenses_label: 'Expenses',
        profit: 'Profit',
        revenue: 'Revenue',
        margin: 'Margin %',
        customers_count: 'Customers',
        transactions: 'Transactions',
        month: 'Month',
        
        // Time Ranges
        this_month: 'This Month',
        this_quarter: 'This Quarter',
        this_year: 'This Year',
        last_30_days: 'Last 30 Days',
        last_90_days: 'Last 90 Days',

        // Common
        save: 'Save',
        cancel: 'Cancel',
        delete: 'Delete',
        edit: 'Edit',
        add: 'Add',
        search: 'Search...',
        no_data: 'No data found.',
        actions: 'Actions',
        status: 'Status',
        date: 'Date',
        total: 'Total',
        close: 'Close',
        confirm: 'Confirm',
        view: 'View',
        print: 'Print',
        export: 'Export',
        filter: 'Filter',
        
        // Products
        product_name: 'Product Name',
        category: 'Category',
        price: 'Price',
        cost_price: 'Cost Price',
        selling_price: 'Selling Price',
        stock: 'Stock',
        current_stock: 'Current Stock',
        barcode: 'Barcode',
        add_product: 'Add New Product',
        edit_product: 'Edit Product',
        
        // Customers
        customer_name: 'Customer Name',
        phone: 'Phone',
        email: 'Email',
        address: 'Address',
        balance: 'Balance',
        credit_limit: 'Credit Limit',
        add_customer: 'Add New Customer',
        
        // POS
        cart: 'Cart',
        add_to_cart: 'Add to Cart',
        checkout: 'Checkout',
        payment_method: 'Payment Method',
        cash: 'Cash',
        amount_paid: 'Amount Paid',
        change: 'Change',
        complete_sale: 'Complete Sale',
        
        // Sales History
        invoice_number: 'Invoice Number',
        sale_date: 'Sale Date',
        customer: 'Customer',
        amount: 'Amount',
        payment_status: 'Payment Status',
        
        // Expenses
        expense_category: 'Expense Category',
        expense_date: 'Expense Date',
        description: 'Description',
        add_expense: 'Add New Expense',
        
        // Suppliers
        supplier_name: 'Supplier Name',
        company: 'Company',
        contact: 'Contact',
        add_supplier: 'Add New Supplier',
        
        // Purchases
        purchase_date: 'Purchase Date',
        supplier: 'Supplier',
        quantity: 'Quantity',
        add_purchase: 'Add New Purchase',
        
        // Walpo (Debts)
        debt_amount: 'Debt Amount',
        remaining: 'Remaining',
        paid: 'Paid',
        payment_date: 'Payment Date',
        add_payment: 'Add Payment',
        
        // Reports
        generate_report: 'Generate Report',
        date_range: 'Date Range',
        from: 'From',
        to: 'To',
        
        // Users
        username: 'Username',
        full_name: 'Full Name',
        role: 'Role',
        password: 'Password',
        add_user: 'Add New User',
        admin: 'Admin',
        cashier: 'Cashier',
    }
};

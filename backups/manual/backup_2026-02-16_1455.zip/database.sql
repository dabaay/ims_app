-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ims_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounting_and_expense_tables`
--

DROP TABLE IF EXISTS `accounting_and_expense_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_and_expense_tables` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_and_expense_tables`
--

LOCK TABLES `accounting_and_expense_tables` WRITE;
/*!40000 ALTER TABLE `accounting_and_expense_tables` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_and_expense_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  `old_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_data`)),
  `new_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_data`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `active_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `inactive_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `audit_log_user_id_foreign` (`user_id`),
  CONSTRAINT `audit_log_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-14 08:23:16','2026-02-14 08:23:16'),(2,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-14 08:23:25','2026-02-14 08:23:25'),(3,1,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-14 08:24:24','2026-02-14 08:24:24'),(4,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-14 08:41:45','2026-02-14 08:41:45'),(5,1,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-14 09:17:40','2026-02-14 09:17:40'),(6,1,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 04:01:19','2026-02-15 04:01:19'),(7,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 05:47:00','2026-02-15 05:47:00'),(8,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 07:07:48','2026-02-15 07:07:48'),(9,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 07:52:51','2026-02-15 07:52:51'),(10,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:34:45','2026-02-15 08:34:45'),(11,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:35:54','2026-02-15 08:35:54'),(12,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:37:19','2026-02-15 08:37:19'),(13,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:38:50','2026-02-15 08:38:50'),(14,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:38:59','2026-02-15 08:38:59'),(15,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:45:27','2026-02-15 08:45:27'),(16,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:45:39','2026-02-15 08:45:39'),(17,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:45:48','2026-02-15 08:45:48'),(18,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:45:59','2026-02-15 08:45:59'),(19,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:46:26','2026-02-15 08:46:26'),(20,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:46:38','2026-02-15 08:46:38'),(21,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:46:46','2026-02-15 08:46:46'),(22,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:56:46','2026-02-15 08:56:46'),(23,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 08:56:53','2026-02-15 08:56:53'),(24,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 10:19:50','2026-02-15 10:19:50'),(25,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-15 10:21:08','2026-02-15 10:21:08'),(26,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 04:32:35','2026-02-16 04:32:35'),(27,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 04:33:39','2026-02-16 04:33:39'),(28,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 05:55:24','2026-02-16 05:55:24'),(29,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 06:34:21','2026-02-16 06:34:21'),(30,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 06:51:48','2026-02-16 06:51:48'),(31,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 06:54:33','2026-02-16 06:54:33'),(32,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 08:20:03','2026-02-16 08:20:03'),(33,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 08:20:46','2026-02-16 08:20:46'),(34,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 08:32:36','2026-02-16 08:32:36'),(35,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 08:36:36','2026-02-16 08:36:36');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `credit_limit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `current_balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_purchases` decimal(12,2) NOT NULL DEFAULT 0.00,
  `last_purchase_date` date DEFAULT NULL,
  `status` enum('active','blocked','inactive') NOT NULL DEFAULT 'active',
  `registered_by` bigint(20) unsigned DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `customers_phone_unique` (`phone`),
  KEY `customers_registered_by_foreign` (`registered_by`),
  CONSTRAINT `customers_registered_by_foreign` FOREIGN KEY (`registered_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Cali Axmed Salaad','0615112233','Xamar Weyne, Muqdisho',NULL,0.00,0.00,0.00,NULL,'active',1,'2026-02-14 09:25:04',NULL,'2026-02-14 06:25:04','2026-02-15 10:14:50',NULL),(2,'Faadumo Jaamac','0615998877','Hodan, Muqdisho',NULL,0.00,0.00,0.00,NULL,'active',1,'2026-02-14 09:25:04',NULL,'2026-02-14 06:25:04','2026-02-15 09:45:07',NULL),(4,'maanka','683632095',NULL,NULL,0.00,0.00,0.00,NULL,'active',1,'2026-02-14 12:22:14',NULL,'2026-02-14 09:22:14','2026-02-15 10:02:04',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_summaries`
--

DROP TABLE IF EXISTS `daily_summaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_summaries` (
  `summary_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `summary_date` date NOT NULL,
  `total_sales` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_cash_sales` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_evc_sales` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_shilin_sales` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_expenses` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_purchases` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_transportation` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_debt_collected` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_debt_created` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_profit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `transaction_count` int(11) NOT NULL DEFAULT 0,
  `customer_count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`summary_id`),
  UNIQUE KEY `daily_summaries_summary_date_unique` (`summary_date`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_summaries`
--

LOCK TABLES `daily_summaries` WRITE;
/*!40000 ALTER TABLE `daily_summaries` DISABLE KEYS */;
INSERT INTO `daily_summaries` VALUES (1,'2026-02-14',0.60,0.00,0.00,0.60,300.00,0.00,0.00,0.00,0.00,-299.40,1,0,'2026-02-14 08:00:42','2026-02-14 08:09:24'),(2,'2026-02-15',44.60,44.60,0.00,0.00,0.00,0.00,0.00,248.40,0.00,44.60,3,0,'2026-02-15 04:49:30','2026-02-15 10:14:50'),(3,'2026-02-16',28.00,28.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,28.00,1,0,'2026-02-16 07:08:50','2026-02-16 07:08:50');
/*!40000 ALTER TABLE `daily_summaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debt_payments`
--

DROP TABLE IF EXISTS `debt_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debt_payments` (
  `payment_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `debt_id` bigint(20) unsigned NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_method` varchar(50) NOT NULL,
  `received_by` bigint(20) unsigned NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `debt_payments_debt_id_foreign` (`debt_id`),
  KEY `debt_payments_received_by_foreign` (`received_by`),
  CONSTRAINT `debt_payments_debt_id_foreign` FOREIGN KEY (`debt_id`) REFERENCES `debts` (`debt_id`),
  CONSTRAINT `debt_payments_received_by_foreign` FOREIGN KEY (`received_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debt_payments`
--

LOCK TABLES `debt_payments` WRITE;
/*!40000 ALTER TABLE `debt_payments` DISABLE KEYS */;
INSERT INTO `debt_payments` VALUES (1,6,8.50,'2026-02-15 09:31:00','cash',3,NULL,'2026-02-15 09:31:00','2026-02-15 09:31:00'),(2,4,0.60,'2026-02-15 09:41:36','cash',3,NULL,'2026-02-15 09:41:36','2026-02-15 09:41:36'),(3,7,32.00,'2026-02-15 09:43:09','cash',3,NULL,'2026-02-15 09:43:09','2026-02-15 09:43:09'),(4,9,32.00,'2026-02-15 09:43:35','cash',3,NULL,'2026-02-15 09:43:35','2026-02-15 09:43:35'),(5,8,22.00,'2026-02-15 09:44:02','cash',3,NULL,'2026-02-15 09:44:02','2026-02-15 09:44:02'),(6,10,28.00,'2026-02-15 09:45:07','cash',3,NULL,'2026-02-15 09:45:07','2026-02-15 09:45:07'),(7,5,8.50,'2026-02-15 09:53:12','cash',3,NULL,'2026-02-15 09:53:12','2026-02-15 09:53:12'),(8,3,84.20,'2026-02-15 10:02:04','cash',3,NULL,'2026-02-15 10:02:04','2026-02-15 10:02:04'),(9,1,0.60,'2026-02-15 10:11:21','evc_plus',3,NULL,'2026-02-15 10:11:21','2026-02-15 10:11:21'),(10,2,32.00,'2026-02-15 10:14:50','evc_plus',3,NULL,'2026-02-15 10:14:50','2026-02-15 10:14:50');
/*!40000 ALTER TABLE `debt_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debts`
--

DROP TABLE IF EXISTS `debts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debts` (
  `debt_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `sale_id` bigint(20) unsigned NOT NULL,
  `original_amount` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('pending','partial','paid','overdue','written_off') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`debt_id`),
  KEY `debts_customer_id_foreign` (`customer_id`),
  KEY `debts_sale_id_foreign` (`sale_id`),
  CONSTRAINT `debts_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  CONSTRAINT `debts_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debts`
--

LOCK TABLES `debts` WRITE;
/*!40000 ALTER TABLE `debts` DISABLE KEYS */;
INSERT INTO `debts` VALUES (1,1,11,0.60,0.00,'2026-03-16','paid',NULL,'2026-02-14 08:59:11','2026-02-15 10:11:21'),(2,1,12,32.00,0.00,'2026-03-16','paid',NULL,'2026-02-14 08:59:41','2026-02-15 10:14:50'),(3,4,13,84.20,0.00,'2026-03-16','paid',NULL,'2026-02-14 09:22:48','2026-02-15 10:02:04'),(4,1,14,0.60,0.00,'2026-03-17','paid',NULL,'2026-02-15 04:49:30','2026-02-15 09:41:36'),(5,4,15,8.50,0.00,'2026-03-17','paid',NULL,'2026-02-15 04:51:32','2026-02-15 09:53:12'),(6,4,16,8.50,0.00,'2026-03-17','paid',NULL,'2026-02-15 05:04:21','2026-02-15 09:31:00'),(7,2,17,32.00,0.00,'2026-03-17','paid',NULL,'2026-02-15 05:21:35','2026-02-15 09:43:09'),(8,2,18,22.00,0.00,'2026-03-17','paid',NULL,'2026-02-15 06:14:08','2026-02-15 09:44:02'),(9,2,22,32.00,0.00,'2026-03-17','paid',NULL,'2026-02-15 07:41:57','2026-02-15 09:43:35'),(10,2,23,28.00,0.00,'2026-03-17','paid',NULL,'2026-02-15 09:44:41','2026-02-15 09:45:07');
/*!40000 ALTER TABLE `debts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `expense_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `expense_number` varchar(255) NOT NULL,
  `expense_category` enum('rent','electricity','water','tax','salary','maintenance','transport','marketing','office','other') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `description` text NOT NULL,
  `cashier_note` text DEFAULT NULL,
  `expense_date` date NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `document_path` varchar(255) DEFAULT NULL,
  `requested_by` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `is_admin_present` tinyint(1) NOT NULL DEFAULT 0,
  `admin_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  UNIQUE KEY `expenses_expense_number_unique` (`expense_number`),
  KEY `expenses_requested_by_foreign` (`requested_by`),
  KEY `expenses_approved_by_foreign` (`approved_by`),
  CONSTRAINT `expenses_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `expenses_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,'EXP-TEST','water',10.00,'Test',NULL,'2026-02-14','cash','approved',NULL,1,3,'2026-02-15 05:55:39',NULL,0,NULL,'2026-02-14 07:58:25','2026-02-15 05:55:39');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_transactions`
--

DROP TABLE IF EXISTS `financial_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_transactions` (
  `transaction_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `transaction_type` varchar(255) NOT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `reference_table` varchar(255) DEFAULT NULL,
  `debit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(12,2) NOT NULL,
  `description` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `financial_transactions_created_by_foreign` (`created_by`),
  CONSTRAINT `financial_transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_transactions`
--

LOCK TABLES `financial_transactions` WRITE;
/*!40000 ALTER TABLE `financial_transactions` DISABLE KEYS */;
INSERT INTO `financial_transactions` VALUES (1,'2026-02-14 08:00:42','expense',2,'expenses',300.00,0.00,-300.00,'Kharash: Waa Lacagta Kirada Bishaan (EXP-699055DAC4414)',1,'Payment via: Evc plus',NULL,NULL),(2,'2026-02-14 08:09:24','sale',9,'sales',0.00,0.60,-299.40,'Iibka Invoice: INV-699057E40E3B0',1,'Payment via: Shilin somali',NULL,NULL),(3,'2026-02-14 08:59:11','walpo_created',11,'sales',0.00,0.00,-299.40,'Walpo Invoice: WALPO-6990638FA5FD6 - Cali Axmed Salaad',2,'Payment via: Credit. Debt created: $0.60',NULL,NULL),(4,'2026-02-14 08:59:41','walpo_created',12,'sales',0.00,0.00,-299.40,'Walpo Invoice: WALPO-699063AD74341 - Cali Axmed Salaad',2,'Payment via: Credit. Debt created: $32.00',NULL,NULL),(5,'2026-02-14 09:22:48','walpo_created',13,'sales',0.00,0.00,-299.40,'Walpo Invoice: WALPO-699069189C24D - maanka',1,'Payment via: Credit. Debt created: $84.20',NULL,NULL),(6,'2026-02-15 04:49:30','walpo_created',14,'sales',0.00,0.00,-299.40,'Walpo Invoice: WALPO-69917A8A4BC10 - Cali Axmed Salaad',1,'Payment via: Credit. Debt created: $0.60',NULL,NULL),(7,'2026-02-15 04:51:32','walpo_created',15,'sales',0.00,0.00,-299.40,'Walpo Invoice: WALPO-69917B04DC3BE - maanka',1,'Payment via: Credit. Debt created: $8.50',NULL,NULL),(8,'2026-02-15 05:04:21','walpo_created',16,'sales',0.00,0.00,-299.40,'Walpo Invoice: WALPO-69917E05AAEBD - maanka',1,'Payment via: Credit. Debt created: $8.50',NULL,NULL),(9,'2026-02-15 05:21:35','walpo_created',17,'sales',0.00,0.00,-299.40,'Walpo Invoice: WALPO-6991820FA6C02 - Faadumo Jaamac',1,'Payment via: Credit. Debt created: $32.00',NULL,NULL),(10,'2026-02-15 06:14:08','walpo_created',18,'sales',0.00,0.00,-299.40,'Walpo Invoice: WALPO-69918E60386B3 - Faadumo Jaamac',3,'Payment via: Credit. Debt created: $22.00',NULL,NULL),(11,'2026-02-15 06:18:41','sale',19,'sales',0.00,22.00,-277.40,'Iibka Invoice: INV-69918F716445D',3,'Payment via: Cash',NULL,NULL),(12,'2026-02-15 07:19:08','sale',20,'sales',0.00,0.60,-276.80,'Iibka Invoice: INV-69919D9C723CF',2,'Payment via: Cash',NULL,NULL),(13,'2026-02-15 07:20:59','sale',21,'sales',0.00,22.00,-254.80,'Iibka Invoice: INV-69919E0B97EB7',2,'Payment via: Cash',NULL,NULL),(14,'2026-02-15 07:41:57','walpo_created',22,'sales',0.00,0.00,-254.80,'Walpo Invoice: WALPO-6991A2F52F2B9 - Faadumo Jaamac',2,'Payment via: Credit. Debt created: $32.00',NULL,NULL),(15,'2026-02-15 09:31:00','debt_collection',1,'debt_payments',0.00,8.50,-246.30,'Debt Collection: maanka (Inv: WALPO-69917E05AAEBD)',3,'Payment via: Cash',NULL,NULL),(16,'2026-02-15 09:41:36','debt_collection',2,'debt_payments',0.00,0.60,-245.70,'Debt Collection: Cali Axmed Salaad (Inv: WALPO-69917A8A4BC10)',3,'Payment via: Cash',NULL,NULL),(17,'2026-02-15 09:43:09','debt_collection',3,'debt_payments',0.00,32.00,-213.70,'Debt Collection: Faadumo Jaamac (Inv: WALPO-6991820FA6C02)',3,'Payment via: Cash',NULL,NULL),(18,'2026-02-15 09:43:35','debt_collection',4,'debt_payments',0.00,32.00,-181.70,'Debt Collection: Faadumo Jaamac (Inv: WALPO-6991A2F52F2B9)',3,'Payment via: Cash',NULL,NULL),(19,'2026-02-15 09:44:02','debt_collection',5,'debt_payments',0.00,22.00,-159.70,'Debt Collection: Faadumo Jaamac (Inv: WALPO-69918E60386B3)',3,'Payment via: Cash',NULL,NULL),(20,'2026-02-15 09:44:41','walpo_created',23,'sales',0.00,0.00,-159.70,'Walpo Invoice: WALPO-6991BFB9816AF - Faadumo Jaamac',3,'Payment via: Credit. Debt created: $28.00',NULL,NULL),(21,'2026-02-15 09:45:07','debt_collection',6,'debt_payments',0.00,28.00,-131.70,'Debt Collection: Faadumo Jaamac (Inv: WALPO-6991BFB9816AF)',3,'Payment via: Cash',NULL,NULL),(22,'2026-02-15 09:53:12','debt_collection',7,'debt_payments',0.00,8.50,-123.20,'Debt Collection: maanka (Inv: WALPO-69917B04DC3BE)',3,'Payment via: Cash',NULL,NULL),(23,'2026-02-15 10:02:04','debt_collection',8,'debt_payments',0.00,84.20,-39.00,'Debt Collection: maanka (Inv: WALPO-699069189C24D)',3,'Payment via: Cash',NULL,NULL),(24,'2026-02-15 10:11:21','debt_collection',9,'debt_payments',0.00,0.60,-38.40,'Debt Collection: Cali Axmed Salaad (Inv: WALPO-6990638FA5FD6)',3,'Payment via: Evc plus',NULL,NULL),(25,'2026-02-15 10:14:50','debt_collection',10,'debt_payments',0.00,32.00,-6.40,'Debt Collection: Cali Axmed Salaad (Inv: WALPO-699063AD74341)',3,'Payment via: Evc plus',NULL,NULL),(26,'2026-02-16 07:08:50','sale',24,'sales',0.00,28.00,21.60,'Iibka Invoice: INV-6992ECB25B9A3',3,'Payment via: Cash',NULL,NULL);
/*!40000 ALTER TABLE `financial_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2026_02_14_083159_create_personal_access_tokens_table',1),(2,'2026_02_14_085710_create_users_table',1),(3,'2026_02_14_085711_create_customers_table',1),(4,'2026_02_14_085712_create_suppliers_table',1),(5,'2026_02_14_085713_create_products_table',1),(6,'2026_02_14_085714_create_sales_table',1),(7,'2026_02_14_085715_create_sale_items_table',1),(8,'2026_02_14_090648_create_cache_table',1),(9,'2026_02_14_090648_create_jobs_table',1),(10,'2026_02_14_090648_create_sessions_table',1),(11,'2026_02_14_102813_add_image_path_to_products_table',2),(12,'2026_02_14_102814_add_plain_password_to_users_table',2),(14,'2026_02_14_105043_create_accounting_and_expense_tables',3),(15,'2026_02_14_110521_add_notes_to_expenses_table',4),(16,'2026_02_14_111452_create_purchases_and_purchase_items_tables',5),(17,'2026_02_14_111454_add_admin_present_to_expenses_table',5),(18,'2026_02_14_112206_ensure_audit_logs_table_exists',6),(19,'2026_02_14_113205_add_walpo_fields_to_sales_and_items_table',7),(20,'2026_02_14_114312_add_credit_to_payment_method_enum',8),(21,'2026_02_14_114337_add_credit_to_payment_method_enum',8),(22,'2026_02_15_124048_add_deleted_at_to_customers_table',9),(23,'2026_02_15_130452_update_payment_methods_enum',10),(24,'2026_02_16_072634_update_users_and_audit_log_for_activity_tracking',11),(25,'2026_02_16_080512_add_purchase_and_transport_to_daily_summaries',12),(26,'2026_02_16_093801_create_system_settings_table',13);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `notification_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','danger') NOT NULL DEFAULT 'info',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',1,'auth_token','eef52b734fe769e212db781ff4c7c2c19686fe3aaca9e6692311308d1b833066','[\"*\"]',NULL,NULL,'2026-02-14 06:26:06','2026-02-14 06:26:06'),(2,'App\\Models\\User',1,'auth_token','d76deacdfc2a851a51af82adf29d1bbd51ddfc54f369580cf77cc5f62ba44851','[\"*\"]',NULL,NULL,'2026-02-14 06:39:45','2026-02-14 06:39:45'),(3,'App\\Models\\User',1,'auth_token','a3e7c077726fdd06ec95370b591a6f95e13108d1c49812c58e00dfe5e0c1fdc6','[\"*\"]',NULL,NULL,'2026-02-14 06:54:00','2026-02-14 06:54:00'),(4,'App\\Models\\User',1,'auth_token','e1bc3056af6a50943c9ad9ab5a6bcfb29100c316f7eded46d797ea624a1ad38f','[\"*\"]',NULL,NULL,'2026-02-14 06:58:10','2026-02-14 06:58:10'),(5,'App\\Models\\User',1,'auth_token','c42ffcb41c3a39823a9a2fc638e16e6df5caa7e7befd3e60fc468bd837ef1e3e','[\"*\"]',NULL,NULL,'2026-02-14 07:02:27','2026-02-14 07:02:27'),(6,'App\\Models\\User',1,'auth_token','a7cefa16a20f6829767de702a3d15550350b47734de3809a09b15d1ce980b689','[\"*\"]',NULL,NULL,'2026-02-14 07:06:57','2026-02-14 07:06:57'),(7,'App\\Models\\User',1,'auth_token','399e19527ebd3430a77d0648a47c6e38acc0038d6e52f7ae42e291b4aad63cba','[\"*\"]','2026-02-14 07:33:01',NULL,'2026-02-14 07:11:53','2026-02-14 07:33:01'),(8,'App\\Models\\User',2,'auth_token','fbd619d54933c3a6c4590fd99a6cb36a3567c666c40ac551b033f45d46bcfd13','[\"*\"]','2026-02-14 07:34:06',NULL,'2026-02-14 07:33:21','2026-02-14 07:34:06'),(9,'App\\Models\\User',1,'auth_token','40644b9d1a2de9aa7ce2b295e2fe21070db4668c2cb26a7d44a15c4ab592a30b','[\"*\"]','2026-02-14 08:20:28',NULL,'2026-02-14 07:34:35','2026-02-14 08:20:28'),(10,'App\\Models\\User',1,'auth_token','22a274c815fc03205b064dfd3e366683ec203ff183b5aa8a1f9b2a45d47ce926','[\"*\"]',NULL,NULL,'2026-02-14 08:20:32','2026-02-14 08:20:32'),(11,'App\\Models\\User',1,'auth_token','91f9f39a13bce9af8877a7cadab4a439649968933e7fe0146e668c5adcd30d4e','[\"*\"]',NULL,NULL,'2026-02-14 08:20:40','2026-02-14 08:20:40'),(12,'App\\Models\\User',1,'auth_token','13efdd13f5830a55ec3457444aff342ba97d476d568c9e2b22298601f2340cde','[\"*\"]','2026-02-14 08:23:16',NULL,'2026-02-14 08:23:16','2026-02-14 08:23:16'),(13,'App\\Models\\User',2,'auth_token','529b790f42b0f4882b3ef07d069608f33af0f71215234b2a1e7575b9bbd30e90','[\"*\"]','2026-02-14 08:24:01',NULL,'2026-02-14 08:23:25','2026-02-14 08:24:01'),(14,'App\\Models\\User',1,'auth_token','52b9bd57d617c82c27a30923edf95cd2044a01f20442ccf998f6d3f5c2ab19b5','[\"*\"]','2026-02-14 08:41:11',NULL,'2026-02-14 08:24:24','2026-02-14 08:41:11'),(15,'App\\Models\\User',2,'auth_token','16ef1572bdc11029e3cb8495b228204e355e95bf1bf1811bcb8383b8cceda621','[\"*\"]','2026-02-14 09:17:12',NULL,'2026-02-14 08:41:45','2026-02-14 09:17:12'),(16,'App\\Models\\User',1,'auth_token','71e73907da3ce59c36e309a4ec34a84da0d3c211f0eb4d0066bf1204c9e7d46e','[\"*\"]','2026-02-14 09:26:32',NULL,'2026-02-14 09:17:40','2026-02-14 09:26:32'),(17,'App\\Models\\User',1,'auth_token','75c2ea0847d7f8adbbae733b5ff1a333ecae77a676d0fc4844828128280b05d2','[\"*\"]','2026-02-15 05:46:17',NULL,'2026-02-15 04:01:19','2026-02-15 05:46:17'),(18,'App\\Models\\User',3,'auth_token','c32bc2d30f263291aa113c988ed94507aab67201e3b20afc1366f49d9cc035f6','[\"*\"]','2026-02-15 07:07:26',NULL,'2026-02-15 05:47:00','2026-02-15 07:07:26'),(19,'App\\Models\\User',2,'auth_token','778cd08258d1136469214148d5d8685d14d48a1efcdaeb3ac4d8223a0ea9a798','[\"*\"]','2026-02-15 07:52:44',NULL,'2026-02-15 07:07:48','2026-02-15 07:52:44'),(20,'App\\Models\\User',3,'auth_token','cc8f63cd36adf8f5fda9b753e9bb2d48a338120dff9bdef17929bc35dc43230c','[\"*\"]','2026-02-15 08:33:33',NULL,'2026-02-15 07:52:51','2026-02-15 08:33:33'),(21,'App\\Models\\User',3,'auth_token','23d5df098adb27ad98a731dd0ade500499108b3f3b8f6f538797861ca77dca85','[\"*\"]','2026-02-15 08:35:29',NULL,'2026-02-15 08:34:45','2026-02-15 08:35:29'),(22,'App\\Models\\User',3,'auth_token','158571aba26561c7ca2fd92c3de4935e65c1c5151d27e98da4589c7feec42dca','[\"*\"]','2026-02-15 08:36:55',NULL,'2026-02-15 08:35:54','2026-02-15 08:36:55'),(23,'App\\Models\\User',2,'auth_token','24a4b26c99f2cc5771acafe4656e988ce88eec610d01aa0c4313c4a7e14a64a6','[\"*\"]','2026-02-15 08:38:35',NULL,'2026-02-15 08:37:19','2026-02-15 08:38:35'),(24,'App\\Models\\User',3,'auth_token','be98f391be00c62692fdcf707101786884734c782233810303ac8e8c8cec3e7b','[\"*\"]','2026-02-15 08:38:51',NULL,'2026-02-15 08:38:50','2026-02-15 08:38:51'),(25,'App\\Models\\User',3,'auth_token','8ffe8a471b59e809fb4db0c12f8cd8b0d2da76f19c6eeb2c0f4759203dabc0ed','[\"*\"]','2026-02-15 08:41:40',NULL,'2026-02-15 08:38:59','2026-02-15 08:41:40'),(26,'App\\Models\\User',2,'auth_token','de33f2294573eb3df3944cbad2c77892c84c2795335424116a98acbb7cd17840','[\"*\"]','2026-02-15 08:45:28',NULL,'2026-02-15 08:45:27','2026-02-15 08:45:28'),(27,'App\\Models\\User',3,'auth_token','ba1c43caf0ff2df6a756a4c8cdc773262a192da68915c6b1ca73b7901b6cb4f6','[\"*\"]','2026-02-15 08:45:40',NULL,'2026-02-15 08:45:39','2026-02-15 08:45:40'),(28,'App\\Models\\User',2,'auth_token','a534e4638b6191f12b04fbe8d3197ce51cb27fa456be29b2a2d25c7452192275','[\"*\"]','2026-02-15 08:45:48',NULL,'2026-02-15 08:45:48','2026-02-15 08:45:48'),(29,'App\\Models\\User',3,'auth_token','2ddc491e493622333e2a69c1df917de132415df68bdbfa1b9f9ef6253e7feb6e','[\"*\"]','2026-02-15 08:46:21',NULL,'2026-02-15 08:45:59','2026-02-15 08:46:21'),(30,'App\\Models\\User',2,'auth_token','d3a7da80d4527fdda65d49ed51341ec4545d5df4a28042010f2e98ed3e039989','[\"*\"]','2026-02-15 08:46:31',NULL,'2026-02-15 08:46:26','2026-02-15 08:46:31'),(31,'App\\Models\\User',3,'auth_token','63e1a3ba06d3b677a20ce5446ae2c62b40d022b0f33cd8000704943673fe8117','[\"*\"]','2026-02-15 08:46:39',NULL,'2026-02-15 08:46:38','2026-02-15 08:46:39'),(32,'App\\Models\\User',2,'auth_token','d3123bc8d8e98f80ca08be7d16eac3556edad58f728e7b24c854d1bc83479fb5','[\"*\"]','2026-02-15 08:46:46',NULL,'2026-02-15 08:46:46','2026-02-15 08:46:46'),(33,'App\\Models\\User',2,'auth_token','b392b94847f19a206274f23159dd48e5070b0a841138626402e76fddb9341112','[\"*\"]','2026-02-15 08:56:47',NULL,'2026-02-15 08:56:46','2026-02-15 08:56:47'),(34,'App\\Models\\User',3,'auth_token','c7b114d857af3bd213c6aafc68d573899056419f6aff5df33a4868546a4a7ee2','[\"*\"]','2026-02-15 10:19:43',NULL,'2026-02-15 08:56:53','2026-02-15 10:19:43'),(35,'App\\Models\\User',2,'auth_token','976fa275e9ef0acbe0cfa122e2b665df52271b1325a7890fabbbb03dd18cbb5d','[\"*\"]','2026-02-15 10:20:43',NULL,'2026-02-15 10:19:50','2026-02-15 10:20:43'),(36,'App\\Models\\User',3,'auth_token','24270fa5f9675e8d773a4b8a91542d8791dd266a83ab8c23269c40de9fd3debb','[\"*\"]','2026-02-16 04:32:25',NULL,'2026-02-15 10:21:08','2026-02-16 04:32:25'),(37,'App\\Models\\User',3,'auth_token','a3e66e6360a15fe68c8cbb331e6724311f92dacfa51f19d5d415bd1886cdd885','[\"*\"]','2026-02-16 04:33:28',NULL,'2026-02-16 04:32:35','2026-02-16 04:33:28'),(38,'App\\Models\\User',3,'auth_token','a4dc5e0958dc75314af1f7a4cb8236951688a8cdb63c9abafbb2c9a30c6948d4','[\"*\"]','2026-02-16 05:55:01',NULL,'2026-02-16 04:33:39','2026-02-16 05:55:01'),(39,'App\\Models\\User',3,'auth_token','fa156e562fb90537c5558f8f4595b3f07012ffd8c5def5645b35f9091e6d8e4b','[\"*\"]','2026-02-16 06:28:23',NULL,'2026-02-16 05:55:24','2026-02-16 06:28:23'),(40,'App\\Models\\User',3,'auth_token','a5112bebbb2b6953f5735bc87e2b0c88b6e62e1de5a18c8683bb3e483929f4a0','[\"*\"]','2026-02-16 06:43:36',NULL,'2026-02-16 06:34:21','2026-02-16 06:43:36'),(41,'App\\Models\\User',3,'auth_token','49fab119428f0f50d85fa8b9f7311963060658cbe548ce3c6ac965a0a19c4442','[\"*\"]','2026-02-16 06:54:13',NULL,'2026-02-16 06:51:48','2026-02-16 06:54:13'),(42,'App\\Models\\User',3,'auth_token','995775a44fbe0e2578c636f7585892a1335aa10fd3e771fad78ec022b4cf91d5','[\"*\"]','2026-02-16 08:19:55',NULL,'2026-02-16 06:54:33','2026-02-16 08:19:55'),(43,'App\\Models\\User',2,'auth_token','959cd0bdf68308ffcab1d23ca9c3d6d6259af55d7a867c22ce2a8ee318ca9df4','[\"*\"]','2026-02-16 08:20:36',NULL,'2026-02-16 08:20:03','2026-02-16 08:20:36'),(44,'App\\Models\\User',3,'auth_token','3f27cdb97c6b255248b70d9d5f3271fbee97f2970ea700519f6d36db4b84d270','[\"*\"]','2026-02-16 08:32:28',NULL,'2026-02-16 08:20:46','2026-02-16 08:32:28'),(45,'App\\Models\\User',2,'auth_token','a56aecc7746c0e3ece90c0e00a1f5aaeb1d5308fecb2096bc15cc618e41735fe','[\"*\"]','2026-02-16 08:33:16',NULL,'2026-02-16 08:32:36','2026-02-16 08:33:16'),(46,'App\\Models\\User',3,'auth_token','d2d24c0cd8114553fde20107bdf1d7b456c84db5722b9b5b788dd1cd4a194d06','[\"*\"]','2026-02-16 08:55:52',NULL,'2026-02-16 08:36:36','2026-02-16 08:55:52');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `product_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) DEFAULT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `supplier_id` bigint(20) unsigned DEFAULT NULL,
  `cost_price` decimal(12,2) NOT NULL,
  `selling_price` decimal(12,2) NOT NULL,
  `wholesale_price` decimal(12,2) DEFAULT NULL,
  `current_stock` int(11) NOT NULL DEFAULT 0,
  `minimum_stock` int(11) NOT NULL DEFAULT 5,
  `maximum_stock` int(11) NOT NULL DEFAULT 100,
  `unit` varchar(20) NOT NULL DEFAULT 'piece',
  `location` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `products_product_code_unique` (`product_code`),
  UNIQUE KEY `products_barcode_unique` (`barcode`),
  KEY `products_supplier_id_foreign` (`supplier_id`),
  KEY `products_created_by_foreign` (`created_by`),
  CONSTRAINT `products_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `products_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'MAC001',NULL,'Macaroni Santa Lucia',NULL,'products/qm7MYxDhFBW1LupVWaB0E5bA5UtbTBiUEO1qNEq8.jpg','Cunto',NULL,0.40,0.60,NULL,98,5,100,'kg',NULL,NULL,1,1,'2026-02-14 06:25:04','2026-02-15 07:19:08'),(2,'SAL001',NULL,'Saliid Cadale 5L',NULL,NULL,'Cunto',NULL,6.50,8.50,NULL,41,5,100,'gacan',NULL,NULL,1,1,'2026-02-14 06:25:04','2026-02-14 09:23:52'),(3,'SON001',NULL,'Sonkor 50KG',NULL,NULL,'Cunto',NULL,28.00,32.00,NULL,19,5,100,'bac',NULL,NULL,1,1,'2026-02-14 06:25:04','2026-02-14 07:37:27'),(4,'BUR001',NULL,'Bur Libaax 50KG',NULL,NULL,'Cunto',NULL,24.50,28.00,NULL,14,5,100,'bac',NULL,NULL,1,1,'2026-02-14 06:25:04','2026-02-16 07:08:50'),(5,'BAS001',NULL,'Bariis Bunni 25KG',NULL,NULL,'Cunto',NULL,18.00,22.00,NULL,27,5,100,'bac',NULL,NULL,1,1,'2026-02-14 06:25:04','2026-02-15 07:20:59');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_items`
--

DROP TABLE IF EXISTS `purchase_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_items` (
  `purchase_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `total_price` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`purchase_item_id`),
  KEY `purchase_items_purchase_id_foreign` (`purchase_id`),
  KEY `purchase_items_product_id_foreign` (`product_id`),
  CONSTRAINT `purchase_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  CONSTRAINT `purchase_items_purchase_id_foreign` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`purchase_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_items`
--

LOCK TABLES `purchase_items` WRITE;
/*!40000 ALTER TABLE `purchase_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases` (
  `purchase_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_id` bigint(20) unsigned NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `transport_method` enum('Bajaj','Vekon','Car','Other') NOT NULL DEFAULT 'Other',
  `transport_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `purchase_date` date NOT NULL,
  `status` enum('pending','received','cancelled') NOT NULL DEFAULT 'received',
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`purchase_id`),
  KEY `purchases_supplier_id_foreign` (`supplier_id`),
  KEY `purchases_created_by_foreign` (`created_by`),
  CONSTRAINT `purchases_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `purchases_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_items`
--

DROP TABLE IF EXISTS `sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_items` (
  `sale_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `taken_quantity` int(11) NOT NULL DEFAULT 0,
  `unit_price` decimal(12,2) NOT NULL,
  `discount_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(12,2) NOT NULL,
  `cost_price` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sale_item_id`),
  KEY `sale_items_sale_id_foreign` (`sale_id`),
  KEY `sale_items_product_id_foreign` (`product_id`),
  CONSTRAINT `sale_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  CONSTRAINT `sale_items_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_items`
--

LOCK TABLES `sale_items` WRITE;
/*!40000 ALTER TABLE `sale_items` DISABLE KEYS */;
INSERT INTO `sale_items` VALUES (1,4,2,1,0,8.50,0.00,8.50,6.50,NULL,NULL),(2,5,1,1,0,0.60,0.00,0.60,0.40,NULL,NULL),(3,6,3,1,0,32.00,0.00,32.00,28.00,NULL,NULL),(4,7,2,1,0,8.50,0.00,8.50,6.50,NULL,NULL),(5,8,5,1,0,22.00,0.00,22.00,18.00,NULL,NULL),(6,9,1,1,0,0.60,0.00,0.60,0.40,NULL,NULL),(8,11,1,1,0,0.60,0.00,0.60,0.40,NULL,NULL),(9,12,3,1,0,32.00,0.00,32.00,28.00,NULL,NULL),(10,13,2,2,1,8.50,0.00,17.00,6.50,NULL,NULL),(11,13,1,2,0,0.60,0.00,1.20,0.40,NULL,NULL),(12,13,5,3,0,22.00,0.00,66.00,18.00,NULL,NULL),(13,14,1,1,0,0.60,0.00,0.60,0.40,NULL,NULL),(14,15,2,1,0,8.50,0.00,8.50,6.50,NULL,NULL),(15,16,2,1,0,8.50,0.00,8.50,6.50,NULL,NULL),(16,17,3,1,0,32.00,0.00,32.00,28.00,NULL,NULL),(17,18,5,1,0,22.00,0.00,22.00,18.00,NULL,NULL),(18,19,5,1,0,22.00,0.00,22.00,18.00,NULL,NULL),(19,20,1,1,0,0.60,0.00,0.60,0.40,NULL,NULL),(20,21,5,1,0,22.00,0.00,22.00,18.00,NULL,NULL),(21,22,3,1,0,32.00,0.00,32.00,28.00,NULL,NULL),(22,23,4,1,0,28.00,0.00,28.00,24.50,NULL,NULL),(23,24,4,1,0,28.00,0.00,28.00,24.50,NULL,NULL);
/*!40000 ALTER TABLE `sale_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `sale_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `cashier_id` bigint(20) unsigned NOT NULL,
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `subtotal` decimal(12,2) NOT NULL,
  `discount_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL DEFAULT 0.00,
  `balance_due` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) NOT NULL,
  `payment_status` enum('paid','partial','credit') NOT NULL DEFAULT 'paid',
  `is_walpo` tinyint(1) NOT NULL DEFAULT 0,
  `transaction_reference` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `sales_invoice_number_unique` (`invoice_number`),
  KEY `sales_customer_id_foreign` (`customer_id`),
  KEY `sales_cashier_id_foreign` (`cashier_id`),
  CONSTRAINT `sales_cashier_id_foreign` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `sales_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (4,'INV-6990503A26107',NULL,1,'2026-02-14 07:36:42',8.50,0.00,0.00,8.50,8.50,0.00,'cash','paid',0,NULL,NULL,'2026-02-14 07:36:42','2026-02-14 07:36:42'),(5,'INV-6990506075512',NULL,1,'2026-02-14 07:37:20',0.60,0.00,0.00,0.60,0.60,0.00,'cash','paid',0,NULL,NULL,'2026-02-14 07:37:20','2026-02-14 07:37:20'),(6,'INV-69905067DBECF',1,1,'2026-02-14 07:37:27',32.00,0.00,0.00,32.00,32.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-14 07:37:27','2026-02-14 07:37:27'),(7,'INV-6990508A4F353',NULL,1,'2026-02-14 07:38:02',8.50,0.00,0.00,8.50,8.50,0.00,'cash','paid',0,NULL,NULL,'2026-02-14 07:38:02','2026-02-14 07:38:02'),(8,'INV-699052468F91B',NULL,1,'2026-02-14 07:45:26',22.00,0.00,0.00,22.00,22.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-14 07:45:26','2026-02-14 07:45:26'),(9,'INV-699057E40E3B0',1,1,'2026-02-14 08:09:24',0.60,0.00,0.00,0.60,0.60,0.00,'shilin_somali','paid',0,NULL,NULL,'2026-02-14 08:09:24','2026-02-14 08:09:24'),(11,'WALPO-6990638FA5FD6',1,2,'2026-02-14 08:59:11',0.60,0.00,0.00,0.60,0.60,0.00,'credit','paid',1,NULL,NULL,'2026-02-14 08:59:11','2026-02-15 10:11:21'),(12,'WALPO-699063AD74341',1,2,'2026-02-14 08:59:41',32.00,0.00,0.00,32.00,32.00,0.00,'credit','paid',1,NULL,NULL,'2026-02-14 08:59:41','2026-02-15 10:14:50'),(13,'WALPO-699069189C24D',4,1,'2026-02-14 09:22:48',84.20,0.00,0.00,84.20,84.20,0.00,'credit','paid',1,NULL,NULL,'2026-02-14 09:22:48','2026-02-15 10:02:04'),(14,'WALPO-69917A8A4BC10',1,1,'2026-02-15 04:49:30',0.60,0.00,0.00,0.60,0.60,0.00,'credit','paid',1,NULL,NULL,'2026-02-15 04:49:30','2026-02-15 09:41:36'),(15,'WALPO-69917B04DC3BE',4,1,'2026-02-15 04:51:32',8.50,0.00,0.00,8.50,8.50,0.00,'credit','paid',1,NULL,NULL,'2026-02-15 04:51:32','2026-02-15 09:53:12'),(16,'WALPO-69917E05AAEBD',4,1,'2026-02-15 05:04:21',8.50,0.00,0.00,8.50,8.50,0.00,'credit','paid',1,NULL,NULL,'2026-02-15 05:04:21','2026-02-15 09:31:00'),(17,'WALPO-6991820FA6C02',2,1,'2026-02-15 05:21:35',32.00,0.00,0.00,32.00,32.00,0.00,'credit','paid',1,NULL,NULL,'2026-02-15 05:21:35','2026-02-15 09:43:09'),(18,'WALPO-69918E60386B3',2,3,'2026-02-15 06:14:08',22.00,0.00,0.00,22.00,22.00,0.00,'credit','paid',1,NULL,NULL,'2026-02-15 06:14:08','2026-02-15 09:44:02'),(19,'INV-69918F716445D',NULL,3,'2026-02-15 06:18:41',22.00,0.00,0.00,22.00,22.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-15 06:18:41','2026-02-15 06:18:41'),(20,'INV-69919D9C723CF',NULL,2,'2026-02-15 07:19:08',0.60,0.00,0.00,0.60,0.60,0.00,'cash','paid',0,NULL,NULL,'2026-02-15 07:19:08','2026-02-15 07:19:08'),(21,'INV-69919E0B97EB7',NULL,2,'2026-02-15 07:20:59',22.00,0.00,0.00,22.00,22.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-15 07:20:59','2026-02-15 07:20:59'),(22,'WALPO-6991A2F52F2B9',2,2,'2026-02-15 07:41:57',32.00,0.00,0.00,32.00,32.00,0.00,'credit','paid',1,NULL,NULL,'2026-02-15 07:41:57','2026-02-15 09:43:35'),(23,'WALPO-6991BFB9816AF',2,3,'2026-02-15 09:44:41',28.00,0.00,0.00,28.00,28.00,0.00,'credit','paid',1,NULL,NULL,'2026-02-15 09:44:41','2026-02-15 09:45:07'),(24,'INV-6992ECB25B9A3',NULL,3,'2026-02-16 07:08:50',28.00,0.00,0.00,28.00,28.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-16 07:08:50','2026-02-16 07:08:50');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0qXUNOnRGjhLBCbKbi1Nn8NwmaxzSPJJ4c9KbYG5',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZDNxeVJTNXM0RFc1ZGV4MjAwNEhRN2dPRmU2ZjZQVXBjc0loNE4zVCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771138811);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `supplier_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `tax_number` varchar(50) DEFAULT NULL,
  `payment_terms` varchar(50) DEFAULT NULL,
  `contract_start` date DEFAULT NULL,
  `contract_end` date DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(255) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(255) NOT NULL DEFAULT 'string',
  `description` text DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `system_settings_setting_key_unique` (`setting_key`),
  KEY `system_settings_updated_by_foreign` (`updated_by`),
  CONSTRAINT `system_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'store_name','So\'Mali Store','string','The official name of the store',3,'2026-02-16 10:06:28'),(2,'store_address','Main Street, Mogadishu, Somalia','string','Physical address of the store',3,'2026-02-16 10:06:28'),(3,'store_number','+252 683632095','string','Primary contact number',3,'2026-02-16 10:14:43'),(4,'store_logo','branding/CF9fciiN0BD7o0Qukdfng8a7ztLSDgiYpP6hFn3u.webp','image','Store logo image path',3,'2026-02-16 10:06:28'),(5,'tiktok_handle','@somali_store','string','TikTok username',3,'2026-02-16 10:06:28'),(6,'tiktok_show','true','boolean','Whether to show TikTok in printed documents',3,'2026-02-16 10:06:28'),(7,'facebook_handle','somali.store','string','Facebook page name/handle',3,'2026-02-16 10:06:28'),(8,'facebook_show','true','boolean','Whether to show Facebook in printed documents',3,'2026-02-16 10:06:28'),(9,'instagram_handle','somali_store','string','Instagram handle',3,'2026-02-16 10:06:28'),(10,'instagram_show','true','boolean','Whether to show Instagram in printed documents',3,'2026-02-16 10:06:28'),(11,'whatsapp_number','+252 683632095','string','WhatsApp contact number',3,'2026-02-16 10:14:57'),(12,'whatsapp_show','true','boolean','Whether to show WhatsApp in printed documents',3,'2026-02-16 10:06:28'),(13,'show_social_labels','true','boolean','Whether to show the name/label of social media handles next to icons',3,'2026-02-16 10:06:28');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `plain_password` varchar(255) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `role` enum('admin','cashier') NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` timestamp NULL DEFAULT NULL,
  `last_logout_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$12$yZg5tPEw8jUL8YabeNNDQuqV1QlvKFLE3Hnzo/swe4yrE4hQenMt.',NULL,'Admin Somali POS',NULL,NULL,'admin',1,0,NULL,NULL,'2026-02-14 06:25:03','2026-02-14 06:25:03'),(2,'maanka','$2y$12$rhMLuBlShTju6LZhf0Os8ORsFtl6vbx53g5wg52IOdywpfr4Ar0TC','maanka1','maanka abdulkadir','maanka@gmail.com','683632095','cashier',1,1,'2026-02-16 08:32:36',NULL,'2026-02-14 07:18:19','2026-02-16 08:32:36'),(3,'dabaay','$2y$12$P.zuYfizfebH4pTJWDLtbeOEwf7FLZPqL77n1vkYchPjI.7VzYnQK','dabaay12','Abdirahman Abdulkadir',NULL,NULL,'admin',1,1,'2026-02-16 08:36:36',NULL,'2026-02-15 04:14:34','2026-02-16 08:36:36');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-16 14:55:52

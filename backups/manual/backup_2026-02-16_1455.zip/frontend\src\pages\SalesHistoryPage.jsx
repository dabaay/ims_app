import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { Search, Printer, Receipt, Calendar, FileText, ChevronRight, User, Package } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Modal from '../components/Modal';

const SalesHistoryPage = () => {
    const { user } = useAuth();
    const isAdmin = user?.role === 'admin';
    const [sales, setSales] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [selectedSale, setSelectedSale] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [settings, setSettings] = useState({
        store_name: "So'Mali Store",
        store_address: "Main Street, Mogadishu",
        store_number: "Somali Government",
        store_logo: null,
        tiktok_handle: "@somali_store",
        tiktok_show: true,
        facebook_handle: "somali.store",
        facebook_show: true,
        instagram_handle: "somali_store",
        instagram_show: true,
        whatsapp_number: "+252 61XXXXXXX",
        whatsapp_show: true,
        show_social_labels: true
    });

    useEffect(() => {
        fetchSales();
        fetchSettings();
    }, []);

    const fetchSettings = async () => {
        try {
            const response = await api.get('/settings');
            setSettings(prev => ({ ...prev, ...response.data }));
        } catch (error) {
            console.error('Error fetching settings:', error);
        }
    };

    const fetchSales = async () => {
        try {
            const response = await api.get('/sales');
            setSales(response.data.data || response.data || []);
        } catch (error) {
            console.error('Error fetching sales:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleViewDetails = (sale) => {
        setSelectedSale(sale);
        setIsModalOpen(true);
    };

    const handlePrintAll = () => {
        if (filteredSales.length === 0) return;
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Diiwaanka Iibka - Print All</title>
                    <style>
                        body { font-family: sans-serif; padding: 20px; font-size: 12px; }
                        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f8f9fa; font-weight: bold; text-transform: uppercase; font-size: 10px; }
                        .header { text-align: center; margin-bottom: 20px; }
                        .total-summary { margin-top: 20px; text-align: right; font-weight: bold; font-size: 14px; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h2>${settings.store_name}</h2>
                        <p style="margin: 0;">${settings.store_address}</p>
                        <h3 style="margin-top: 15px;">Diiwaanka Iibka (Sales History)</h3>
                        <p>Taariikhda: ${new Date().toLocaleDateString()}</p>
                        ${search ? `<p>Natiijada Raadinta: "${search}"</p>` : ''}
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Invoice No</th>
                                <th>Macmiilka</th>
                                <th>Taariikhda</th>
                                <th>Guud</th>
                                <th>Bixiyay</th>
                                <th>Haray</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${(filteredSales || []).map(s => `
                                <tr>
                                    <td>${s.invoice_number || 'N/A'}</td>
                                    <td>${s.customer?.full_name || 'Macmiilka Guud'}</td>
                                    <td>${s.sale_date ? new Date(s.sale_date).toLocaleDateString() : 'N/A'}</td>
                                    <td>$${parseFloat(s.total_amount || 0).toFixed(2)}</td>
                                    <td>$${parseFloat(s.amount_paid || 0).toFixed(2)}</td>
                                    <td>$${parseFloat(s.balance_due || 0).toFixed(2)}</td>
                                    <td style="text-transform: capitalize;">${s.payment_status || 'N/A'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <div class="total-summary">
                        Wadarta Natiijada: $${filteredSales.reduce((sum, s) => sum + parseFloat(s.total_amount), 0).toFixed(2)}
                    </div>
                    <div style="margin-top: 30px; text-align: center; border-top: 2px solid #eee; padding-top: 15px;">
                        <p style="margin: 5px 0; font-weight: bold;">Thank you for your business</p>
                        <div style="display: flex; justify-content: center; gap: 15px; margin: 10px 0; font-size: 11px;">
                            ${settings.facebook_show ? `<span><strong>FB:</strong> ${settings.facebook_handle}</span>` : ''}
                            ${settings.instagram_show ? `<span><strong>IG:</strong> ${settings.instagram_handle}</span>` : ''}
                            ${settings.tiktok_show ? `<span><strong>TikTok:</strong> ${settings.tiktok_handle}</span>` : ''}
                            ${settings.whatsapp_show ? `<span><strong>WA:</strong> ${settings.whatsapp_number}</span>` : ''}
                        </div>
                        <p style="margin: 0; font-size: 10px; color: #666;">&copy; ${new Date().getFullYear()} ${settings.store_name}</p>
                    </div>
                    <script>window.print(); window.close();</script>
                </body>
            </html>
        `);
        printWindow.document.close();
    };

    const handlePrintReceipt = (sale) => {
        const printWindow = window.open('', '_blank');

        printWindow.document.write(`
            <html>
                <head>
                    <title>Riskidha Iibka - So'Mali Store</title>
                    <style>
                        body { font-family: 'Courier New', Courier, monospace; width: 80mm; padding: 10px; margin: 0; border: 1px solid #eee; }
                        .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 10px; }
                        .info { font-size: 12px; margin-bottom: 10px; }
                        table { width: 100%; border-collapse: collapse; font-size: 12px; }
                        .total-section { margin-top: 10px; border-top: 1px solid #000; padding-top: 5px; }
                        .footer { margin-top: 20px; text-align: center; font-size: 10px; border-top: 1px dashed #ccc; padding-top: 10px; }
                        .row { display: flex; justify-content: space-between; margin: 2px 0; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h2 style="margin: 0;">${settings.store_name}</h2>
                        <p style="margin: 5px 0; font-size: 11px;">${settings.store_address}</p>
                        <p style="margin: 0; font-size: 11px;">Tel: ${settings.store_number}</p>
                    </div>
                    <div class="info">
                        <div class="row"><span>No:</span> <span>${sale.invoice_number}</span></div>
                        <div class="row"><span>Taariikh:</span> <span>${new Date(sale.sale_date).toLocaleString()}</span></div>
                        <div class="row"><span>Macmiil:</span> <span>${sale.customer?.full_name || 'Macmiilka Guud'}</span></div>
                        <div class="row"><span>Cashier:</span> <span>${sale.cashier?.full_name || 'System'}</span></div>
                    </div>
                    <table style="border-bottom: 1px solid #000; margin-bottom: 5px;">
                        <thead>
                            <tr style="border-bottom: 1px solid #eee;">
                                <th style="text-align: left; padding: 5px 0;">Alaabta</th>
                                <th style="text-align: center;">Qty</th>
                                <th style="text-align: right;">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${(sale.items || []).map(item => `
                                <tr>
                                    <td style="padding: 5px 0;">${item.product?.name || 'Product'}<br/><small>$${parseFloat(item.unit_price || 0).toFixed(2)}</small></td>
                                    <td style="text-align: center;">${item.quantity || 0}</td>
                                    <td style="text-align: right;">$${((item.unit_price || 0) * (item.quantity || 0)).toFixed(2)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <div class="total-section">
                        <div class="row">
                            <span>Subtotal:</span>
                            <span>$${parseFloat(sale.subtotal).toFixed(2)}</span>
                        </div>
                        ${parseFloat(sale.discount_amount) > 0 ? `
                        <div class="row" style="color: #666;">
                            <span>Discount:</span>
                            <span>-$${parseFloat(sale.discount_amount).toFixed(2)}</span>
                        </div>
                        ` : ''}
                        <div class="row" style="font-size: 16px; font-weight: bold; margin-top: 5px; border-top: 1px double #000; padding-top: 3px;">
                            <span>TOTAL:</span>
                            <span>$${parseFloat(sale.total_amount).toFixed(2)}</span>
                        </div>
                        <div class="row" style="font-size: 12px; margin-top: 5px;">
                            <span>Paid:</span>
                            <span>$${parseFloat(sale.amount_paid || 0).toFixed(2)}</span>
                        </div>
                        <div class="row" style="font-size: 12px; color: ${parseFloat(sale.balance_due) > 0 ? 'red' : 'green'};">
                            <span>Balance Due:</span>
                            <span>$${parseFloat(sale.balance_due || 0).toFixed(2)}</span>
                        </div>
                    </div>
                    <div class="footer">
                        <p style="margin: 5px 0; font-weight: bold;">Ku soo dhawaada mar kale.</p>
                        <p style="margin: 0; font-size: 12px; font-weight: 800;">${settings.store_name}</p>
                        <div style="display: flex; justify-content: center; gap: 10px; margin-top: 5px; flex-wrap: wrap;">
                            ${settings.facebook_show ? `<span style="font-size: 8px;">FB: ${settings.facebook_handle}</span>` : ''}
                            ${settings.whatsapp_show ? `<span style="font-size: 8px;">WA: ${settings.whatsapp_number}</span>` : ''}
                        </div>
                    </div>
                    <script>window.print(); window.close();</script>
                </body>
            </html>
        `);
        printWindow.document.close();
    };

    const handlePrintA4 = (sale) => {
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Invoice #${sale.invoice_number}</title>
                    <style>
                        body { font-family: sans-serif; padding: 40px; color: #333; }
                        .header { display: flex; justify-content: space-between; border-bottom: 2px solid #3b82f6; padding-bottom: 20px; margin-bottom: 30px; }
                        .company-info h1 { margin: 0; color: #1e3a8a; }
                        .invoice-info { text-align: right; }
                        .details { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 40px; }
                        .details h3 { border-bottom: 1px solid #ddd; padding-bottom: 5px; color: #1e3a8a; }
                        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
                        th { background: #f8fafc; padding: 12px; text-align: left; border-bottom: 2px solid #ddd; }
                        td { padding: 12px; border-bottom: 1px solid #eee; }
                        .totals { width: 300px; margin-left: auto; }
                        .total-row { display: flex; justify-content: space-between; padding: 8px 0; }
                        .grand-total { border-top: 2px solid #1e3a8a; margin-top: 10px; font-weight: bold; font-size: 18px; color: #1e3a8a; }
                        .footer { margin-top: 50px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #eee; padding-top: 20px; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <div class="company-info">
                            <div style="display: flex; items-center; gap: 20px;">
                                ${settings.store_logo ? `<img src="http://localhost:8000/storage/${settings.store_logo}" style="width: 80px; height: 80px; object-fit: contain;" />` : ''}
                                <div>
                                    <h1>${settings.store_name}</h1>
                                    <p>${settings.store_address}</p>
                                    <p>Tel: ${settings.store_number}</p>
                                </div>
                            </div>
                        </div>
                        <div class="invoice-info">
                            <h2>INVOICE</h2>
                            <p><strong>No:</strong> ${sale.invoice_number}</p>
                            <p><strong>Date:</strong> ${new Date(sale.sale_date).toLocaleDateString()}</p>
                        </div>
                    </div>
                    <div class="details">
                        <div>
                            <h3>BILL TO:</h3>
                            <p><strong>Customer:</strong> ${sale.customer?.full_name || 'Macmiilka Guud'}</p>
                            <p><strong>Phone:</strong> ${sale.customer?.phone || '-'}</p>
                        </div>
                        <div>
                            <h3>TRANSACTION:</h3>
                            <p><strong>Cashier:</strong> ${sale.cashier?.full_name || 'System'}</p>
                            <p><strong>Payment Status:</strong> ${sale.payment_status.toUpperCase()}</p>
                        </div>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Alaabta (Product)</th>
                                <th style="text-align: center;">Qty</th>
                                <th style="text-align: right;">Price</th>
                                <th style="text-align: right;">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${(sale.items || []).map(item => `
                                <tr>
                                    <td>${item.product?.name || 'Product'}</td>
                                    <td style="text-align: center;">${item.quantity || 0}</td>
                                    <td style="text-align: right;">$${parseFloat(item.unit_price || 0).toFixed(2)}</td>
                                    <td style="text-align: right;">$${((item.unit_price || 0) * (item.quantity || 0)).toFixed(2)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <div class="totals">
                        <div class="total-row"><span>Subtotal:</span> <span>$${parseFloat(sale.subtotal).toFixed(2)}</span></div>
                        ${parseFloat(sale.discount_amount) > 0 ? `<div class="total-row"><span>Discount:</span> <span>-$${parseFloat(sale.discount_amount).toFixed(2)}</span></div>` : ''}
                        <div class="total-row grand-total"><span>TOTAL:</span> <span>$${parseFloat(sale.total_amount).toFixed(2)}</span></div>
                        <div class="total-row" style="color: #10b981; font-weight: bold;"><span>Amount Paid:</span> <span>$${parseFloat(sale.amount_paid).toFixed(2)}</span></div>
                        <div class="total-row" style="color: #ef4444; font-weight: bold;"><span>Balance Due:</span> <span>$${parseFloat(sale.balance_due).toFixed(2)}</span></div>
                    </div>
                    <div class="footer">
                        <p>Thank you for your business. We appreciate your loyalty!</p>
                        <div style="display: flex; justify-content: center; gap: 20px; margin: 10px 0;">
                            ${settings.facebook_show ? `<span>Facebook: ${settings.facebook_handle}</span>` : ''}
                            ${settings.instagram_show ? `<span>Instagram: ${settings.instagram_handle}</span>` : ''}
                            ${settings.tiktok_show ? `<span>TikTok: ${settings.tiktok_handle}</span>` : ''}
                            ${settings.whatsapp_show ? `<span>WhatsApp: ${settings.whatsapp_number}</span>` : ''}
                        </div>
                        <p>&copy; ${new Date().getFullYear()} ${settings.store_name} Management System</p>
                    </div>
                    <script>window.print(); window.close();</script>
                </body>
            </html>
        `);
        printWindow.document.close();
    };

    const filteredSales = (sales || []).filter(s => 
        (s.invoice_number || "").toLowerCase().includes(search.toLowerCase()) || 
        (s.customer?.full_name || "").toLowerCase().includes(search.toLowerCase())
    );

    const totals = filteredSales.reduce((acc, sale) => {
        acc.total += parseFloat(sale.total_amount || 0);
        acc.paid += parseFloat(sale.amount_paid || 0);
        acc.due += parseFloat(sale.balance_due || 0);
        return acc;
    }, { total: 0, paid: 0, due: 0 });

    return (
        <div className="max-w-7xl mx-auto space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-1">Diiwaanka Iibka (Sales History)</h1>
                    <p className="text-slate-400">Eeg iibkii hore oo soo saar riskidhada.</p>
                </div>
            </div>

            <div className="bg-secondary/40 border border-[#334155] rounded-3xl overflow-hidden backdrop-blur-md shadow-2xl">
                <div className="p-6 border-b border-[#334155] flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="relative max-w-md flex-1">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                        <input 
                            type="text" 
                            placeholder="Raadi Invoice No ama Macmiil..." 
                            className="w-full pl-12 pr-4 py-3 bg-primary/50 border border-[#334155] rounded-2xl text-white outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                    <button 
                        onClick={handlePrintAll}
                        disabled={filteredSales.length === 0}
                        className="flex items-center justify-center space-x-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-2xl font-bold transition-all border border-[#334155]"
                    >
                        <Printer size={20} />
                        <span>Print Results (${filteredSales.length})</span>
                    </button>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="bg-slate-800/50 text-slate-400 text-xs uppercase tracking-widest font-bold">
                                <th className="px-6 py-4">Invoice No</th>
                                <th className="px-6 py-4">Macmiilka</th>
                                <th className="px-6 py-4">Taariikhda</th>
                                <th className="px-6 py-4">Guud / Bixiyay / Haray</th>
                                <th className="px-6 py-4">Status</th>
                                <th className="px-6 py-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-[#334155]">
                            {loading ? (
                                <tr>
                                    <td colSpan="6" className="px-6 py-12 text-center text-slate-500">Xogta waa la soo rarayaa...</td>
                                </tr>
                            ) : filteredSales.length === 0 ? (
                                <tr>
                                    <td colSpan="6" className="px-6 py-12 text-center text-slate-500">Ma jiro iib la helay.</td>
                                </tr>
                            ) : filteredSales.map((sale) => (
                                <tr key={sale.sale_id} className="hover:bg-slate-800/30 transition-colors group">
                                    <td className="px-6 py-4 font-mono text-xs text-blue-400 font-bold">{sale.invoice_number}</td>
                                    <td className="px-6 py-4 text-white font-medium">{sale.customer?.full_name || 'Macmiilka Guud'}</td>
                                    <td className="px-6 py-4 text-slate-400 text-sm">{new Date(sale.sale_date).toLocaleDateString()}</td>
                                    <td className="px-6 py-4">
                                        <div className="text-white font-bold">${parseFloat(sale.total_amount).toFixed(2)}</div>
                                        <div className="flex items-center space-x-2 text-[10px] mb-1">
                                            <span className="text-emerald-400 font-bold">Paid: ${parseFloat(sale.amount_paid || 0).toFixed(2)}</span>
                                            <span className="text-amber-400 font-bold">Due: ${parseFloat(sale.balance_due || 0).toFixed(2)}</span>
                                        </div>
                                        {sale.debt?.payments?.length > 0 && (
                                            <div className="text-[9px] text-slate-500 italic">
                                                Last: {new Date(Math.max(...sale.debt.payments.map(p => new Date(p.payment_date)))).toLocaleDateString()}
                                            </div>
                                        )}
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${
                                            sale.payment_status === 'paid' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
                                        }`}>
                                            {sale.payment_status.toUpperCase()}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        {(isAdmin || Number(sale.cashier_id) === Number(user?.user_id)) ? (
                                            <div className="flex items-center justify-end space-x-2">
                                                <button 
                                                    onClick={() => handleViewDetails(sale)}
                                                    className="p-2 text-slate-400 hover:text-blue-400 transition-all"
                                                    title="View Details"
                                                >
                                                    <FileText size={18} />
                                                </button>
                                                <button 
                                                    onClick={() => handlePrintReceipt(sale)}
                                                    className="p-2 text-slate-400 hover:text-emerald-400 transition-all"
                                                    title="Print Receipt"
                                                >
                                                    <Receipt size={18} />
                                                </button>
                                                <button 
                                                    onClick={() => handlePrintA4(sale)}
                                                    className="p-2 text-slate-400 hover:text-blue-500 transition-all"
                                                    title="Print A4"
                                                >
                                                    <Printer size={18} />
                                                </button>
                                            </div>
                                        ) : (
                                            <span className="text-[10px] text-slate-600 font-bold uppercase italic">Restricted</span>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                        {filteredSales.length > 0 && (
                            <tfoot className="bg-slate-800/80 sticky bottom-0 backdrop-blur-md border-t-2 border-[#334155]">
                                <tr className="text-white font-black uppercase text-xs">
                                    <td colSpan="3" className="px-6 py-5 text-right text-slate-400 tracking-widest">
                                        Wadarta Natiijada (Grand Total):
                                    </td>
                                    <td className="px-6 py-5">
                                        <div className="text-sm font-black text-blue-400 mb-1">
                                            Guud: ${totals.total.toFixed(2)}
                                        </div>
                                        <div className="flex items-center space-x-3 text-[10px]">
                                            <span className="text-emerald-400">Bixiyay: ${totals.paid.toFixed(2)}</span>
                                            <span className="text-amber-400">Haray: ${totals.due.toFixed(2)}</span>
                                        </div>
                                    </td>
                                    <td colSpan="2"></td>
                                </tr>
                            </tfoot>
                        )}
                    </table>
                </div>
            </div>

            {/* Sale Details Modal */}
            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title="Faahfaahinta Iibka"
            >
                {selectedSale && (
                    <div className="space-y-6">
                        <div className="grid grid-cols-2 gap-4 bg-slate-800/30 p-4 rounded-2xl border border-[#334155]">
                            <div>
                                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Invoice Number</p>
                                <p className="text-white font-bold">{selectedSale.invoice_number}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Taariikhda</p>
                                <p className="text-white font-bold">{new Date(selectedSale.sale_date).toLocaleString()}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Macmiilka</p>
                                <p className="text-white font-bold">{selectedSale.customer?.full_name || 'Macmiilka Guud'}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Cashier</p>
                                <p className="text-white font-bold">{selectedSale.cashier?.full_name || 'System'}</p>
                            </div>
                        </div>

                        <div className="space-y-3">
                            <p className="text-xs text-slate-500 font-bold uppercase tracking-widest px-1">Alaabta la iibiyay</p>
                            <div className="bg-primary/30 rounded-2xl overflow-hidden border border-[#334155]">
                                <table className="w-full text-left text-sm">
                                    <thead className="bg-slate-800/50">
                                        <tr>
                                            <th className="px-4 py-2 text-slate-400">Alaabta</th>
                                            <th className="px-4 py-2 text-center text-slate-400">Qty</th>
                                            <th className="px-4 py-2 text-right text-slate-400">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-[#334155]">
                                        {(selectedSale.items || []).map((item, idx) => (
                                            <tr key={idx}>
                                                <td className="px-4 py-3 text-white">{item.product?.name || 'Alaab'}</td>
                                                <td className="px-4 py-3 text-center text-slate-400">{item.quantity}</td>
                                                <td className="px-4 py-3 text-right text-emerald-400 font-bold">${(item.unit_price * item.quantity).toFixed(2)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-emerald-600/10 p-4 rounded-2xl border border-emerald-500/20">
                                <span className="text-emerald-400 font-bold text-xs uppercase block mb-1">Total Paid</span>
                                <span className="text-xl font-black text-white">${parseFloat(selectedSale.amount_paid || 0).toFixed(2)}</span>
                            </div>
                            <div className="bg-amber-600/10 p-4 rounded-2xl border border-amber-500/20">
                                <span className="text-amber-400 font-bold text-xs uppercase block mb-1">Balance Due</span>
                                <span className="text-xl font-black text-white">${parseFloat(selectedSale.balance_due || 0).toFixed(2)}</span>
                            </div>
                        </div>

                        {selectedSale.debt?.payments?.length > 0 && (
                            <div className="space-y-3">
                                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest px-1">Payment History</p>
                                <div className="bg-primary/30 rounded-2xl overflow-hidden border border-[#334155]">
                                    <table className="w-full text-left text-sm">
                                        <thead className="bg-slate-800/50 text-[10px] uppercase font-black text-slate-500">
                                            <tr>
                                                <th className="px-4 py-2">Date</th>
                                                <th className="px-4 py-2">Method</th>
                                                <th className="px-4 py-2 text-right">Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-[#334155]">
                                            {selectedSale.debt.payments.map((p, idx) => (
                                                <tr key={idx}>
                                                    <td className="px-4 py-3 text-slate-400 text-xs">{new Date(p.payment_date).toLocaleDateString()}</td>
                                                    <td className="px-4 py-3 text-white font-medium capitalize">{p.payment_method}</td>
                                                    <td className="px-4 py-3 text-right text-emerald-400 font-bold">${parseFloat(p.amount_paid || p.amount || 0).toFixed(2)}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )}

                        <div className="flex justify-between items-center bg-blue-600/10 p-4 rounded-2xl border border-blue-500/20">
                            <span className="text-blue-400 font-bold">Wadarta Guud (Total)</span>
                            <span className="text-2xl font-black text-white">${parseFloat(selectedSale.total_amount).toFixed(2)}</span>
                        </div>

                        <div className="flex justify-end space-x-3">
                            <button 
                                onClick={() => setIsModalOpen(false)}
                                className="px-6 py-2 rounded-xl bg-slate-800 text-slate-400 font-bold hover:text-white transition-all"
                            >
                                xir
                            </button>
                            <div className="flex items-center space-x-2">
                                <button 
                                    onClick={() => handlePrintReceipt(selectedSale)}
                                    className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 transition-all flex items-center space-x-2"
                                >
                                    <Receipt size={18} />
                                    <span>Receipt</span>
                                </button>
                                <button 
                                    onClick={() => handlePrintA4(selectedSale)}
                                    className="px-4 py-2 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-500 transition-all flex items-center space-x-2"
                                >
                                    <Printer size={18} />
                                    <span>Printer (A4)</span>
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
};

export default SalesHistoryPage;

-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ims_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `table_name` varchar(255) DEFAULT NULL,
  `record_id` bigint(20) unsigned DEFAULT NULL,
  `old_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_data`)),
  `new_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_data`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `active_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `inactive_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 10:23:30','2026-02-16 10:23:30'),(2,3,'sale','sales',1,NULL,'{\"amount\":\"0.60\",\"description\":\"Iibka Invoice: INV-69931AB577889\",\"payment_method\":\"cash\",\"balance\":0.6}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 10:25:09','2026-02-16 10:25:09'),(3,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0',0.00,0.00,'2026-02-16 10:25:41','2026-02-16 10:25:41'),(4,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 03:40:57','2026-02-17 03:40:57'),(5,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 04:42:56','2026-02-17 04:42:56'),(6,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 06:26:01','2026-02-17 06:26:01'),(7,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 08:29:45','2026-02-17 08:29:45'),(8,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 08:48:10','2026-02-17 08:48:10'),(9,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 08:54:39','2026-02-17 08:54:39'),(10,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 09:27:29','2026-02-17 09:27:29'),(11,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 09:29:09','2026-02-17 09:29:09'),(12,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 10:14:45','2026-02-17 10:14:45'),(13,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 10:29:36','2026-02-17 10:29:36'),(14,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 10:30:25','2026-02-17 10:30:25'),(15,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 10:33:28','2026-02-17 10:33:28'),(16,3,'sale','sales',2,NULL,'{\"amount\":\"0.60\",\"description\":\"Iibka Invoice: INV-699472FC2A388\",\"payment_method\":\"cash\",\"balance\":1.2}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-17 10:54:04','2026-02-17 10:54:04'),(17,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 04:08:18','2026-02-18 04:08:18'),(18,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 04:25:07','2026-02-18 04:25:07'),(19,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 04:25:28','2026-02-18 04:25:28'),(20,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 04:25:48','2026-02-18 04:25:48'),(21,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 04:26:02','2026-02-18 04:26:02'),(22,3,'purchase','purchases',1,NULL,'{\"amount\":20,\"description\":\"Iibka Supplier (ID: 1)\",\"payment_method\":\"cash\",\"balance\":-18.8}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 04:39:18','2026-02-18 04:39:18'),(23,3,'transportation','purchases',1,NULL,'{\"amount\":\"2.00\",\"description\":\"Transportation: Vekon (Purch: 1)\",\"payment_method\":\"cash\",\"balance\":-20.8}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 04:39:18','2026-02-18 04:39:18'),(24,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 06:04:44','2026-02-18 06:04:44'),(25,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 06:15:30','2026-02-18 06:15:30'),(26,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 07:36:40','2026-02-18 07:36:40'),(27,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 07:37:19','2026-02-18 07:37:19'),(28,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 07:38:03','2026-02-18 07:38:03'),(29,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 07:39:10','2026-02-18 07:39:10'),(30,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 07:39:37','2026-02-18 07:39:37'),(31,2,'sale','sales',3,NULL,'{\"amount\":\"2.00\",\"description\":\"Iibka Invoice: INV-699598E9BE29D\",\"payment_method\":\"cash\",\"balance\":-18.8}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 07:48:09','2026-02-18 07:48:09'),(32,2,'sale','sales',4,NULL,'{\"amount\":\"2.00\",\"description\":\"Iibka Invoice: INV-69959A53A3305\",\"payment_method\":\"cash\",\"balance\":-16.8}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 07:54:11','2026-02-18 07:54:11'),(33,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 08:00:40','2026-02-18 08:00:40'),(34,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 09:00:53','2026-02-18 09:00:53'),(35,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 09:01:09','2026-02-18 09:01:09'),(36,3,'sale','sales',5,NULL,'{\"amount\":\"0.60\",\"description\":\"Iibka Invoice: INV-6995AE5C46B89\",\"payment_method\":\"cash\",\"balance\":-16.2}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-18 09:19:40','2026-02-18 09:19:40'),(37,3,'sale','sales',6,NULL,'{\"amount\":\"31.00\",\"description\":\"Iibka Invoice: INV-6996D19C61EA2\",\"payment_method\":\"cash\",\"balance\":14.8}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 06:02:20','2026-02-19 06:02:20'),(38,3,'sale','sales',7,NULL,'{\"amount\":\"240.20\",\"description\":\"Iibka Invoice: INV-6996D1D7C68A3\",\"payment_method\":\"evc_plus\",\"balance\":255}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 06:03:19','2026-02-19 06:03:19'),(39,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 07:10:55','2026-02-19 07:10:55'),(40,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 07:30:03','2026-02-19 07:30:03'),(41,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 08:10:34','2026-02-19 08:10:34'),(42,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 08:10:41','2026-02-19 08:10:41'),(43,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 08:15:46','2026-02-19 08:15:46'),(44,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 08:40:15','2026-02-19 08:40:15'),(45,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 08:47:55','2026-02-19 08:47:55'),(46,4,'sale','sales',8,NULL,'{\"amount\":\"1.00\",\"description\":\"Mobile App Order: MOB-6996E1881D804\",\"payment_method\":\"evc_plus\",\"balance\":256}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 09:17:49','2026-02-19 09:17:49'),(47,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 09:18:11','2026-02-19 09:18:11'),(48,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 09:20:10','2026-02-19 09:20:10'),(49,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 10:02:53','2026-02-19 10:02:53'),(50,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 10:07:08','2026-02-19 10:07:08'),(51,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-19 10:07:49','2026-02-19 10:07:49'),(52,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 04:10:48','2026-02-21 04:10:48'),(53,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 05:51:15','2026-02-21 05:51:15'),(54,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 05:56:02','2026-02-21 05:56:02'),(55,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 06:01:45','2026-02-21 06:01:45'),(56,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 06:13:22','2026-02-21 06:13:22'),(57,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 06:17:22','2026-02-21 06:17:22'),(58,3,'sale','sales',10,NULL,'{\"amount\":\"32.00\",\"description\":\"Mobile App Order: MOB-699970EB30D45\",\"payment_method\":\"cash\",\"balance\":288}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 06:58:20','2026-02-21 06:58:20'),(59,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 06:59:12','2026-02-21 06:59:12'),(60,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 07:01:37','2026-02-21 07:01:37'),(61,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 07:04:04','2026-02-21 07:04:04'),(62,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 07:05:09','2026-02-21 07:05:09'),(63,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 07:05:20','2026-02-21 07:05:20'),(64,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 07:08:16','2026-02-21 07:08:16'),(65,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 07:31:41','2026-02-21 07:31:41'),(66,4,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 08:08:04','2026-02-21 08:08:04'),(67,2,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 08:10:04','2026-02-21 08:10:04'),(68,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-21 08:10:24','2026-02-21 08:10:24'),(69,3,'login',NULL,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0.00,0.00,'2026-02-22 04:38:36','2026-02-22 04:38:36');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capital_transactions`
--

DROP TABLE IF EXISTS `capital_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capital_transactions` (
  `capital_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_date` date NOT NULL,
  `transaction_type` enum('investment','drawing') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `description` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`capital_id`),
  KEY `capital_transactions_created_by_foreign` (`created_by`),
  CONSTRAINT `capital_transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capital_transactions`
--

LOCK TABLES `capital_transactions` WRITE;
/*!40000 ALTER TABLE `capital_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `capital_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `message` text NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `is_from_customer` tinyint(1) NOT NULL DEFAULT 1,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chat_messages_user_id_foreign` (`user_id`),
  KEY `chat_messages_customer_id_foreign` (`customer_id`),
  CONSTRAINT `chat_messages_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customerapp` (`customer_id`) ON DELETE CASCADE,
  CONSTRAINT `chat_messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
INSERT INTO `chat_messages` VALUES (1,2,NULL,'hello',NULL,1,0,'2026-02-21 04:10:33','2026-02-21 04:10:33'),(2,2,NULL,'maxaa kaa caawiyaa walaal',NULL,1,0,'2026-02-21 04:11:02','2026-02-21 04:11:02'),(3,2,NULL,'apkka iima shaqeenaayo',NULL,1,0,'2026-02-21 04:35:48','2026-02-21 04:35:48'),(4,2,4,'cilada ku heesato maxaa waaye wll',NULL,0,1,'2026-02-21 04:36:07','2026-02-21 04:36:12'),(5,2,NULL,'imageka productska iima soo baxaayo cilada dhankeyga miyaa mise waa appka',NULL,1,0,'2026-02-21 04:36:45','2026-02-21 04:36:45'),(6,2,4,'walaal waa dhankeena mar dhowneh waan xalineenaa ee inoo dulqaado',NULL,0,1,'2026-02-21 04:37:16','2026-02-21 04:37:17'),(7,2,4,'[Image]','chat_images/g7DDb9BtqsgRSFs9U5U4iRi3h0FCmSLordRprVEd.png',0,1,'2026-02-21 04:37:27','2026-02-21 04:37:27'),(8,2,NULL,'waa yahay walaal',NULL,1,0,'2026-02-21 04:37:42','2026-02-21 04:37:42'),(9,2,4,'[Image]','chat_images/AyC4YiT34CPLVrIl90OarmAX0QdvB5ejC4rE9Gnm.webp',0,1,'2026-02-21 05:02:16','2026-02-21 05:02:18'),(10,2,NULL,'hi',NULL,1,0,'2026-02-21 05:36:16','2026-02-21 05:36:16'),(11,2,4,'soo dhawoow',NULL,0,1,'2026-02-21 05:36:38','2026-02-21 05:36:40'),(12,3,NULL,'walaal alaabta meeqo saac ayee igu soo gaareesaa',NULL,1,1,'2026-02-21 05:47:19','2026-02-21 08:08:30'),(13,3,NULL,'hello',NULL,1,1,'2026-02-21 08:08:27','2026-02-21 08:08:30'),(14,3,4,'soo dhawoow walaal',NULL,0,1,'2026-02-21 08:08:39','2026-02-21 08:08:40'),(15,3,NULL,'waa dhawahay waalaal',NULL,1,1,'2026-02-21 08:08:57','2026-02-21 08:08:58'),(16,3,NULL,'[Image]','chat_images/y9NlyCzNZxafe1wsMuI3BeOrY2384kxZx4O3nVNC.png',1,1,'2026-02-21 08:25:03','2026-02-21 08:25:14'),(17,3,3,'[Image]','chat_images/kwNwSQ1GNx4KDOCSsrALvZismEGEr42wpssdc9Wk.jpg',0,1,'2026-02-21 08:40:50','2026-02-21 08:40:55');
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_favorites`
--

DROP TABLE IF EXISTS `customer_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_favorites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_favorites_customer_id_product_id_unique` (`customer_id`,`product_id`),
  KEY `customer_favorites_product_id_foreign` (`product_id`),
  CONSTRAINT `customer_favorites_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customerapp` (`customer_id`) ON DELETE CASCADE,
  CONSTRAINT `customer_favorites_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_favorites`
--

LOCK TABLES `customer_favorites` WRITE;
/*!40000 ALTER TABLE `customer_favorites` DISABLE KEYS */;
INSERT INTO `customer_favorites` VALUES (2,2,6,'2026-02-19 07:11:49','2026-02-19 07:11:49');
/*!40000 ALTER TABLE `customer_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customerapp`
--

DROP TABLE IF EXISTS `customerapp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customerapp` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'active',
  `is_blocked` tinyint(1) NOT NULL DEFAULT 0,
  `registration_date` datetime NOT NULL,
  `current_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `chat_status` varchar(255) NOT NULL DEFAULT 'open',
  `needs_rating` tinyint(1) NOT NULL DEFAULT 0,
  `last_rating` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `customerapp_username_unique` (`username`),
  UNIQUE KEY `customerapp_phone_unique` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customerapp`
--

LOCK TABLES `customerapp` WRITE;
/*!40000 ALTER TABLE `customerapp` DISABLE KEYS */;
INSERT INTO `customerapp` VALUES (1,'abdulrahman','abdul','612334452','madiino','$2y$12$M3WGiaO6beWUFzov2EGoSuQ62Ya4NW2TSsnZq5y6B2Xs/pgo3ZWm6',NULL,'active',0,'2026-02-19 10:57:16',0.00,'open',0,NULL,NULL,'2026-02-19 09:29:33'),(2,'mohamed abdihakiin','quube','613334455','Wartanabada','$2y$12$jNtB36Z.fqcdMmofT/nqFer2H/8jkPP5Gkn0ZXGY9TYsUB0A9BWjS',NULL,'active',0,'2026-02-19 10:07:41',0.60,'open',0,NULL,'2026-02-19 07:07:41','2026-02-21 04:18:44'),(3,'Abdirahman Abdulkadir','Dabaay','627083069','Wadajir','$2y$12$709c3yCw51k7bQFHKwn9nu.vQl/K6J9SyNgFhTWezczhVRqpK0isW',NULL,'active',0,'2026-02-21 08:45:25',0.00,'open',0,NULL,'2026-02-21 05:45:25','2026-02-21 08:09:43');
/*!40000 ALTER TABLE `customerapp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `credit_limit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `current_balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_purchases` decimal(12,2) NOT NULL DEFAULT 0.00,
  `last_purchase_date` date DEFAULT NULL,
  `status` enum('active','blocked','inactive') NOT NULL DEFAULT 'active',
  `registered_by` bigint(20) unsigned DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `is_mobile_user` tinyint(1) NOT NULL DEFAULT 0,
  `profile_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `customers_phone_unique` (`phone`),
  UNIQUE KEY `customers_username_unique` (`username`),
  KEY `customers_registered_by_foreign` (`registered_by`),
  CONSTRAINT `customers_registered_by_foreign` FOREIGN KEY (`registered_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Cali Axmed Salaad',NULL,'0615112233','Xamar Weyne, Muqdisho',NULL,0.00,0.00,0.00,NULL,'active',NULL,'2026-02-16 13:19:20',NULL,NULL,0,NULL,'2026-02-16 10:19:20','2026-02-16 10:19:20',NULL),(2,'Faadumo Jaamac',NULL,'0615998877','Hodan, Muqdisho',NULL,0.00,0.00,0.00,NULL,'active',NULL,'2026-02-16 13:19:20',NULL,NULL,0,NULL,'2026-02-16 10:19:20','2026-02-16 10:19:20',NULL),(3,'maanka',NULL,'683632095',NULL,NULL,0.00,0.00,0.00,NULL,'active',NULL,'2026-02-16 13:19:20',NULL,NULL,0,NULL,'2026-02-16 10:19:20','2026-02-16 10:19:20',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_summaries`
--

DROP TABLE IF EXISTS `daily_summaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_summaries` (
  `summary_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `summary_date` date NOT NULL,
  `total_sales` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_cash_sales` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_evc_sales` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_shilin_sales` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_expenses` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_purchases` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_transportation` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_debt_collected` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_debt_created` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_profit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `transaction_count` int(11) NOT NULL DEFAULT 0,
  `customer_count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`summary_id`),
  UNIQUE KEY `daily_summaries_summary_date_unique` (`summary_date`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_summaries`
--

LOCK TABLES `daily_summaries` WRITE;
/*!40000 ALTER TABLE `daily_summaries` DISABLE KEYS */;
INSERT INTO `daily_summaries` VALUES (1,'2026-02-16',0.60,0.60,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.60,1,0,'2026-02-16 10:25:09','2026-02-16 10:25:09'),(2,'2026-02-17',0.60,0.60,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.60,1,0,'2026-02-17 10:54:04','2026-02-17 10:54:04'),(3,'2026-02-18',4.60,4.60,0.00,0.00,0.00,20.00,2.00,0.00,0.00,-17.40,3,0,'2026-02-18 04:39:18','2026-02-18 09:19:40'),(4,'2026-02-19',272.20,31.00,241.20,0.00,0.00,0.00,0.00,0.00,0.00,272.20,3,0,'2026-02-19 06:02:20','2026-02-19 09:17:49'),(5,'2026-02-21',32.00,32.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,32.00,1,0,'2026-02-21 06:58:20','2026-02-21 06:58:20');
/*!40000 ALTER TABLE `daily_summaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debt_payments`
--

DROP TABLE IF EXISTS `debt_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debt_payments` (
  `payment_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `debt_id` bigint(20) unsigned NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_method` varchar(50) NOT NULL,
  `received_by` bigint(20) unsigned NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `debt_payments_debt_id_foreign` (`debt_id`),
  KEY `debt_payments_received_by_foreign` (`received_by`),
  CONSTRAINT `debt_payments_debt_id_foreign` FOREIGN KEY (`debt_id`) REFERENCES `debts` (`debt_id`),
  CONSTRAINT `debt_payments_received_by_foreign` FOREIGN KEY (`received_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debt_payments`
--

LOCK TABLES `debt_payments` WRITE;
/*!40000 ALTER TABLE `debt_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `debt_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debts`
--

DROP TABLE IF EXISTS `debts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debts` (
  `debt_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `sale_id` bigint(20) unsigned NOT NULL,
  `original_amount` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('pending','partial','paid','overdue','written_off') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`debt_id`),
  KEY `debts_customer_id_foreign` (`customer_id`),
  KEY `debts_sale_id_foreign` (`sale_id`),
  CONSTRAINT `debts_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  CONSTRAINT `debts_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debts`
--

LOCK TABLES `debts` WRITE;
/*!40000 ALTER TABLE `debts` DISABLE KEYS */;
/*!40000 ALTER TABLE `debts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `expense_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `expense_number` varchar(255) NOT NULL,
  `expense_category` enum('rent','electricity','water','tax','salary','maintenance','transport','marketing','office','other') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `description` text NOT NULL,
  `cashier_note` text DEFAULT NULL,
  `expense_date` date NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `document_path` varchar(255) DEFAULT NULL,
  `requested_by` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `is_admin_present` tinyint(1) NOT NULL DEFAULT 0,
  `admin_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  UNIQUE KEY `expenses_expense_number_unique` (`expense_number`),
  KEY `expenses_requested_by_foreign` (`requested_by`),
  KEY `expenses_approved_by_foreign` (`approved_by`),
  CONSTRAINT `expenses_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `expenses_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_transactions`
--

DROP TABLE IF EXISTS `financial_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_transactions` (
  `transaction_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `transaction_type` varchar(255) NOT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `reference_table` varchar(255) DEFAULT NULL,
  `debit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(12,2) NOT NULL,
  `description` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `financial_transactions_created_by_foreign` (`created_by`),
  CONSTRAINT `financial_transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_transactions`
--

LOCK TABLES `financial_transactions` WRITE;
/*!40000 ALTER TABLE `financial_transactions` DISABLE KEYS */;
INSERT INTO `financial_transactions` VALUES (1,'2026-02-16 10:25:09','sale',1,'sales',0.00,0.60,0.60,'Iibka Invoice: INV-69931AB577889',3,'Payment via: Cash',NULL,NULL),(2,'2026-02-17 10:54:04','sale',2,'sales',0.00,0.60,1.20,'Iibka Invoice: INV-699472FC2A388',3,'Payment via: Cash',NULL,NULL),(3,'2026-02-18 04:39:18','purchase',1,'purchases',20.00,0.00,-18.80,'Iibka Supplier (ID: 1)',3,'Payment via: Cash',NULL,NULL),(4,'2026-02-18 04:39:18','transportation',1,'purchases',2.00,0.00,-20.80,'Transportation: Vekon (Purch: 1)',3,'Payment via: Cash',NULL,NULL),(5,'2026-02-18 07:48:09','sale',3,'sales',0.00,2.00,-18.80,'Iibka Invoice: INV-699598E9BE29D',2,'Payment via: Cash',NULL,NULL),(6,'2026-02-18 07:54:11','sale',4,'sales',0.00,2.00,-16.80,'Iibka Invoice: INV-69959A53A3305',2,'Payment via: Cash',NULL,NULL),(7,'2026-02-18 09:19:40','sale',5,'sales',0.00,0.60,-16.20,'Iibka Invoice: INV-6995AE5C46B89',3,'Payment via: Cash',NULL,NULL),(8,'2026-02-19 06:02:20','sale',6,'sales',0.00,31.00,14.80,'Iibka Invoice: INV-6996D19C61EA2',3,'Payment via: Cash',NULL,NULL),(9,'2026-02-19 06:03:19','sale',7,'sales',0.00,240.20,255.00,'Iibka Invoice: INV-6996D1D7C68A3',3,'Payment via: Evc plus',NULL,NULL),(10,'2026-02-19 09:17:49','sale',8,'sales',0.00,1.00,256.00,'Mobile App Order: MOB-6996E1881D804',4,'Payment via: Evc plus',NULL,NULL),(11,'2026-02-21 06:58:20','sale',10,'sales',0.00,32.00,288.00,'Mobile App Order: MOB-699970EB30D45',3,'Payment via: Cash',NULL,NULL);
/*!40000 ALTER TABLE `financial_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fixed_assets`
--

DROP TABLE IF EXISTS `fixed_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixed_assets` (
  `asset_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `asset_name` varchar(200) NOT NULL,
  `purchase_date` date NOT NULL,
  `purchase_cost` decimal(12,2) NOT NULL,
  `useful_life_years` int(11) NOT NULL,
  `depreciation_method` varchar(50) NOT NULL DEFAULT 'straight_line',
  `current_value` decimal(12,2) NOT NULL,
  `accumulated_depreciation` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','sold','disposed') NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixed_assets`
--

LOCK TABLES `fixed_assets` WRITE;
/*!40000 ALTER TABLE `fixed_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixed_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2026_02_14_083159_create_personal_access_tokens_table',1),(2,'2026_02_14_085710_create_users_table',1),(3,'2026_02_14_085711_create_customers_table',1),(4,'2026_02_14_085712_create_suppliers_table',1),(5,'2026_02_14_085713_create_products_table',1),(6,'2026_02_14_085714_create_sales_table',1),(7,'2026_02_14_085715_create_sale_items_table',1),(8,'2026_02_14_090648_create_cache_table',1),(9,'2026_02_14_090648_create_jobs_table',1),(10,'2026_02_14_090648_create_sessions_table',1),(11,'2026_02_14_102813_add_image_path_to_products_table',1),(12,'2026_02_14_102814_add_plain_password_to_users_table',1),(13,'2026_02_14_105043_create_accounting_and_expense_tables',1),(14,'2026_02_14_110521_add_notes_to_expenses_table',1),(15,'2026_02_14_111452_create_purchases_and_purchase_items_tables',1),(16,'2026_02_14_111454_add_admin_present_to_expenses_table',1),(17,'2026_02_14_112206_ensure_audit_logs_table_exists',1),(18,'2026_02_14_113205_add_walpo_fields_to_sales_and_items_table',1),(19,'2026_02_14_114312_add_credit_to_payment_method_enum',1),(20,'2026_02_14_114337_add_credit_to_payment_method_enum',1),(21,'2026_02_15_124048_add_deleted_at_to_customers_table',1),(22,'2026_02_15_130452_update_payment_methods_enum',1),(23,'2026_02_16_072634_update_users_and_audit_log_for_activity_tracking',1),(24,'2026_02_16_080512_add_purchase_and_transport_to_daily_summaries',1),(25,'2026_02_16_093801_create_system_settings_table',1),(26,'2026_02_16_122157_rename_tenant_admin_to_admin',1),(27,'2026_02_17_000000_create_financial_reporting_tables',2),(28,'2026_02_18_071555_add_permissions_to_users_table',3),(29,'2026_02_18_072726_add_document_path_to_purchases_table',4),(30,'2026_02_18_073614_add_product_name_to_purchase_items_table',5),(32,'2026_02_18_080752_add_unit_to_purchase_items_table',6),(33,'2026_02_19_000001_add_mobile_fields_to_customers_table',7),(34,'2026_02_19_000002_create_customer_favorites_table',7),(35,'2026_02_19_000003_create_product_ratings_table',7),(36,'2026_02_19_000004_create_chat_messages_table',7),(37,'2026_02_19_000005_make_cashier_id_nullable_on_sales_table',7),(38,'2026_02_19_000006_add_pending_cancelled_to_sales_payment_status',7),(39,'2026_02_19_000007_create_customer_app_table',8),(40,'2026_02_19_000008_update_mobile_persistence_constraints',9),(41,'2026_02_19_102631_add_app_manager_to_roles_enum',10),(42,'2026_02_19_102633_add_blocking_and_status_to_customer_app_table',10),(43,'2026_02_19_111433_force_add_app_manager_to_roles_enum',11),(44,'2026_02_19_113214_add_customer_info_to_sales_table',12),(45,'2026_02_19_150000_add_cancellation_fee_to_sales_table',13),(46,'2026_02_19_160000_add_delivery_to_sales_table',14),(47,'2026_02_19_000008_add_is_blocked_to_customer_app_table',15),(48,'2026_02_21_000001_add_chat_fields_to_customer_app_table',16),(49,'2026_02_21_092028_create_promotions_table',17),(50,'2026_02_21_093510_add_discount_fields_to_products_table',18),(51,'2026_02_21_093916_add_dates_to_promotions_table',19);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `notification_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','danger') NOT NULL DEFAULT 'info',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',3,'auth_token','6701fd9098e1f65db2bd3163239a4a0cf27164d13372d3183bff5fd1c4b97f8d','[\"*\"]','2026-02-16 10:25:35',NULL,'2026-02-16 10:23:30','2026-02-16 10:25:35'),(2,'App\\Models\\User',2,'auth_token','a7770851d20699b8dab8c50d3818a2f0b1862e1248975e857d8fbc17dd5a391f','[\"*\"]','2026-02-16 10:25:50',NULL,'2026-02-16 10:25:41','2026-02-16 10:25:50'),(3,'App\\Models\\User',2,'auth_token','3694151ca64dafee98f31fda971396a95a4f980076f00a103c80f5a40412f5af','[\"*\"]','2026-02-17 04:42:49',NULL,'2026-02-17 03:40:57','2026-02-17 04:42:49'),(4,'App\\Models\\User',3,'auth_token','823c9dbcaf0b18b5c8b89112f7a166f8e612a2406ad20b70fea3a0f4040f7de2','[\"*\"]','2026-02-17 06:13:07',NULL,'2026-02-17 04:42:56','2026-02-17 06:13:07'),(5,'App\\Models\\User',3,'auth_token','03d8d41623c1352a5130e12d8b6a4e993585a9e542340439ae9b6b438028d116','[\"*\"]','2026-02-17 07:15:27',NULL,'2026-02-17 06:26:01','2026-02-17 07:15:27'),(6,'App\\Models\\User',3,'auth_token','c3b40b85296c3d8f9ce05d3b5c2551f840692ad60999d6cd77418f58894f04c8','[\"*\"]','2026-02-17 08:48:01',NULL,'2026-02-17 08:29:45','2026-02-17 08:48:01'),(7,'App\\Models\\User',2,'auth_token','387322e0c6352bb890e49074dd86d72815cb75efc02a09e187c3f91693cc44f8','[\"*\"]','2026-02-17 08:48:18',NULL,'2026-02-17 08:48:10','2026-02-17 08:48:18'),(8,'App\\Models\\User',3,'auth_token','bdaead8862c637f9c3500eadd5dd1c46f7618d818c1f6fc5dd0b277fd05beec4','[\"*\"]','2026-02-17 09:27:22',NULL,'2026-02-17 08:54:39','2026-02-17 09:27:22'),(9,'App\\Models\\User',2,'auth_token','18ca32211db68fcdba11e3dcbc2326b58d4f84afb13d34f798a69c8035be4b3a','[\"*\"]','2026-02-17 09:27:30',NULL,'2026-02-17 09:27:29','2026-02-17 09:27:30'),(10,'App\\Models\\User',3,'auth_token','2d9ecfd3e7471cb2866a5953c253aab2ae9b1db34536abce7708c8d1731b3f59','[\"*\"]','2026-02-17 10:14:12',NULL,'2026-02-17 09:29:09','2026-02-17 10:14:12'),(11,'App\\Models\\User',2,'auth_token','0e22ca5cc26ef2e7be778014ba088f84f2710659cbd8b38030634bafa7c4c9b6','[\"*\"]','2026-02-17 10:29:32',NULL,'2026-02-17 10:14:45','2026-02-17 10:29:32'),(12,'App\\Models\\User',3,'auth_token','d8bfeaf7c11a9875e75e336e1c15b75c74c53822eb929a7e1ef5af0701f16732','[\"*\"]','2026-02-17 10:29:44',NULL,'2026-02-17 10:29:36','2026-02-17 10:29:44'),(13,'App\\Models\\User',2,'auth_token','afd90a61b93f86a322efe876b50588c36925277ffbe02b398b564cb90a4a6c82','[\"*\"]','2026-02-17 10:31:31',NULL,'2026-02-17 10:30:25','2026-02-17 10:31:31'),(14,'App\\Models\\User',3,'auth_token','6442912bbe22b68dfbb4ec0c5fb56e5548eb6eb043ca85d7e2eeecf115f13d60','[\"*\"]','2026-02-17 11:03:00',NULL,'2026-02-17 10:33:28','2026-02-17 11:03:00'),(15,'App\\Models\\User',3,'auth_token','b4e42cf4a34517aa87352de33038a11348f7d2d613c76fe7c37cedc253d219fd','[\"*\"]','2026-02-18 04:25:02',NULL,'2026-02-18 04:08:18','2026-02-18 04:25:02'),(16,'App\\Models\\User',2,'auth_token','e074550ce50d456102cf0f5731965dc648c5191a205388827e2c66e0e3ad7973','[\"*\"]','2026-02-18 04:25:10',NULL,'2026-02-18 04:25:07','2026-02-18 04:25:10'),(17,'App\\Models\\User',3,'auth_token','c52f340c8b07a5269e33a7481c44f238f2bb6772429d4417ba505668cd02c2ad','[\"*\"]','2026-02-18 04:25:41',NULL,'2026-02-18 04:25:28','2026-02-18 04:25:41'),(18,'App\\Models\\User',2,'auth_token','03e255fe9bc5d0060d2339409ebc6b56ec37729425dad5fa92e75d4f936b0b8a','[\"*\"]','2026-02-18 04:25:54',NULL,'2026-02-18 04:25:48','2026-02-18 04:25:54'),(19,'App\\Models\\User',3,'auth_token','b406ce3bc38a95963de40454c4eafb598c945e53903b532d9ec114d3c1045c3e','[\"*\"]','2026-02-18 06:04:31',NULL,'2026-02-18 04:26:02','2026-02-18 06:04:31'),(20,'App\\Models\\User',3,'auth_token','02238b8e7a60440f6c2d98db46e25cdc347ece18e70d26e689e39747fa4b79d1','[\"*\"]','2026-02-18 06:06:36',NULL,'2026-02-18 06:04:44','2026-02-18 06:06:36'),(21,'App\\Models\\User',3,'auth_token','71d3ba3388782bd7adc6806c4b3e2722802a089e106afcf08ac93774cdf804b6','[\"*\"]','2026-02-18 07:36:35',NULL,'2026-02-18 06:15:30','2026-02-18 07:36:35'),(22,'App\\Models\\User',2,'auth_token','3956fed14a3e09141cebffa20e4e1ebf8f9f51d9d5e850bf3f06914a03a24c60','[\"*\"]','2026-02-18 07:37:14',NULL,'2026-02-18 07:36:40','2026-02-18 07:37:14'),(23,'App\\Models\\User',3,'auth_token','d2ac2f4febecd00446f7bc88539ac24bc273251319396ba42dc28e090afe120f','[\"*\"]','2026-02-18 07:37:58',NULL,'2026-02-18 07:37:19','2026-02-18 07:37:58'),(24,'App\\Models\\User',2,'auth_token','2eb4ae08663e99017d6db82787284e7e457b0a3d7d9915e583c8b1a490777e29','[\"*\"]','2026-02-18 07:38:33',NULL,'2026-02-18 07:38:03','2026-02-18 07:38:33'),(25,'App\\Models\\User',3,'auth_token','83bb0e11f17acb03fdea5b71d055f9ff7dfceb8b61449af2014ce0be79383fb5','[\"*\"]','2026-02-18 07:39:32',NULL,'2026-02-18 07:39:10','2026-02-18 07:39:32'),(26,'App\\Models\\User',2,'auth_token','04233df60aa77a562732ff427e7f7a5cc2d06b2ab62ed8574047312b92cc1d9e','[\"*\"]','2026-02-18 08:00:29',NULL,'2026-02-18 07:39:37','2026-02-18 08:00:29'),(27,'App\\Models\\User',3,'auth_token','ea9446fa1220c722bcf9a25f1932ea2c14fb7265826be2bf815d28929fd662d4','[\"*\"]','2026-02-18 09:00:48',NULL,'2026-02-18 08:00:40','2026-02-18 09:00:48'),(28,'App\\Models\\User',2,'auth_token','5542adb07888430eb038a62ce5f0ab11ade07fe4cba25d1ca6cf203fa27b9c5f','[\"*\"]','2026-02-18 09:01:03',NULL,'2026-02-18 09:00:53','2026-02-18 09:01:03'),(29,'App\\Models\\User',3,'auth_token','cdc872da40cb06045979a3208042d55710a80d5e5ae609519aa882cd2fee3a42','[\"*\"]','2026-02-19 07:10:48',NULL,'2026-02-18 09:01:09','2026-02-19 07:10:48'),(31,'App\\Models\\User',2,'auth_token','83a867f707ea7e940c5425356f418e0fbf11b6349c8248dd98fa5aa7e71175a1','[\"*\"]','2026-02-19 07:11:08',NULL,'2026-02-19 07:10:55','2026-02-19 07:11:08'),(33,'App\\Models\\User',3,'auth_token','881ad1ac490c34907ca95c4b551042cf74a3dfc6a5c8e6f09fa47f8e3e95a602','[\"*\"]','2026-02-19 08:10:26',NULL,'2026-02-19 07:30:03','2026-02-19 08:10:26'),(34,'App\\Models\\User',2,'auth_token','bc746aefb5631ce62d2fa43e098f7f40e9141ba8d7b34588c295374936a569ed','[\"*\"]','2026-02-19 08:10:35',NULL,'2026-02-19 08:10:34','2026-02-19 08:10:35'),(35,'App\\Models\\User',3,'auth_token','3efcbc1680f765e8863778e5dafcef2a880675e3158dcd195d6972484584e4de','[\"*\"]','2026-02-19 08:15:37',NULL,'2026-02-19 08:10:41','2026-02-19 08:15:37'),(36,'App\\Models\\User',4,'auth_token','27da2ba5810e44ba9c318d93eacdf163eeb1d4707e8518da819e194a1ed76ad0','[\"*\"]','2026-02-19 08:35:56',NULL,'2026-02-19 08:15:46','2026-02-19 08:35:56'),(38,'App\\Models\\User',3,'auth_token','3f258d0a9196e8e594e3d6edb2fb725e8ab2cce47993c44de5a4ef1549efe5cb','[\"*\"]','2026-02-19 08:40:39',NULL,'2026-02-19 08:40:15','2026-02-19 08:40:39'),(39,'App\\Models\\User',4,'auth_token','e98942e69ac798e682891273ca9225e97c24f94722370d38e12645b708096326','[\"*\"]','2026-02-19 09:18:02',NULL,'2026-02-19 08:47:55','2026-02-19 09:18:02'),(41,'App\\Models\\User',2,'auth_token','2adfa28470f7a75a4d728b166393a19d716e2d090b089ef82a99df606b5d1826','[\"*\"]','2026-02-19 09:19:46',NULL,'2026-02-19 09:18:11','2026-02-19 09:19:46'),(42,'App\\Models\\User',4,'auth_token','bc347d3a0fdca84aaba90e6d2862bd2d89ee74e52408e76eeb135c244fa584a0','[\"*\"]','2026-02-19 10:02:39',NULL,'2026-02-19 09:20:10','2026-02-19 10:02:39'),(46,'App\\Models\\CustomerApp',2,'mobile_app','9b26efd15e1723a468407d73a71e85b4635317689cbc4af3f0232f96653d167f','[\"*\"]','2026-02-19 10:07:36',NULL,'2026-02-19 10:00:48','2026-02-19 10:07:36'),(47,'App\\Models\\User',2,'auth_token','1f2f483a249c3c746bf9f488e743062e8dfd286478466e8438af8ead042b6c15','[\"*\"]','2026-02-19 10:06:58',NULL,'2026-02-19 10:02:53','2026-02-19 10:06:58'),(48,'App\\Models\\User',3,'auth_token','0d380988c93b9926d3111384631d85b783acbb5b7a958d2664fdfb0a9dd25803','[\"*\"]','2026-02-19 10:07:43',NULL,'2026-02-19 10:07:08','2026-02-19 10:07:43'),(49,'App\\Models\\User',2,'auth_token','e5bdbed61667d0c1e49e2469bd90636286fd07b0293d24666f50fd56fdf9f9ee','[\"*\"]','2026-02-21 04:08:53',NULL,'2026-02-19 10:07:49','2026-02-21 04:08:53'),(50,'App\\Models\\CustomerApp',2,'mobile_app','49771cf3d9d4fc55e8844bf8d9700f44d26a1ef30cd9d0343e0c219b965f47c5','[\"*\"]','2026-02-21 04:51:55',NULL,'2026-02-21 04:10:15','2026-02-21 04:51:55'),(51,'App\\Models\\User',4,'auth_token','9b08e0a98c264695dbf61fda18d2e5426d66adbfa04b030828b1512d38a01eee','[\"*\"]','2026-02-21 05:51:02',NULL,'2026-02-21 04:10:48','2026-02-21 05:51:02'),(52,'App\\Models\\CustomerApp',2,'mobile_app','92738aea68ae3bea739051ad398b51970a8183538c3839ae5c59580a17a645e7','[\"*\"]','2026-02-21 05:08:25',NULL,'2026-02-21 04:53:42','2026-02-21 05:08:25'),(54,'App\\Models\\CustomerApp',3,'mobile_app','ca5e23eb4fe45ed719cca57294d41e9941d912bdea75920034216c3fab90cf24','[\"*\"]','2026-02-21 06:04:23',NULL,'2026-02-21 05:45:25','2026-02-21 06:04:23'),(55,'App\\Models\\User',3,'auth_token','ced76a64f47e9631e6e1bca693c489e8df49922c9d114742913e4181ac05f373','[\"*\"]','2026-02-21 05:55:55',NULL,'2026-02-21 05:51:15','2026-02-21 05:55:55'),(56,'App\\Models\\User',4,'auth_token','29e876b6074a9837fca1d2813e32b395bb17da2d6e39d1b3594e2f2870be8593','[\"*\"]','2026-02-21 06:01:37',NULL,'2026-02-21 05:56:02','2026-02-21 06:01:37'),(57,'App\\Models\\User',3,'auth_token','e790459fc1439395889d45cf64f234d5ef70ba8ab303d0a6e16b2d836d2a85da','[\"*\"]','2026-02-21 06:13:10',NULL,'2026-02-21 06:01:45','2026-02-21 06:13:10'),(59,'App\\Models\\CustomerApp',3,'mobile_app','a1eea700c25347d4d1320216f1fa14a9b23c02e033f370f0ce086b08b17bd907','[\"*\"]','2026-02-21 06:27:47',NULL,'2026-02-21 06:11:14','2026-02-21 06:27:47'),(60,'App\\Models\\User',4,'auth_token','952171acf33b0652d872f3a188caf876eab2c729232f532d09acbeff0a55bcff','[\"*\"]','2026-02-21 06:17:13',NULL,'2026-02-21 06:13:22','2026-02-21 06:17:13'),(61,'App\\Models\\User',3,'auth_token','8cea4ccda4ba6a15a746b0868db8c6c765c32705b9e875361f6c5902016d9735','[\"*\"]','2026-02-21 06:58:51',NULL,'2026-02-21 06:17:22','2026-02-21 06:58:51'),(62,'App\\Models\\CustomerApp',2,'mobile_app','e03606a2f4efc1718efe1aaa0521880ee8eb00639a149de6a90c8dc025c1423d','[\"*\"]','2026-02-21 06:51:28',NULL,'2026-02-21 06:30:40','2026-02-21 06:51:28'),(64,'App\\Models\\User',2,'auth_token','52703955ca233d6a547c820dc42e7834c151e8cfa943a0c5f8bc53ba4d028342','[\"*\"]','2026-02-21 07:01:24',NULL,'2026-02-21 06:59:12','2026-02-21 07:01:24'),(65,'App\\Models\\User',4,'auth_token','d3a4e195fdea02d8ff178d5d44c1551dc2d40fb71fd1b89e6329113c1283098e','[\"*\"]','2026-02-21 07:03:54',NULL,'2026-02-21 07:01:37','2026-02-21 07:03:54'),(66,'App\\Models\\User',3,'auth_token','4ba24b2eb4d5a9833375b6b166f2ea268a51e6d9fd74d2929f20efcf69717564','[\"*\"]','2026-02-21 07:04:51',NULL,'2026-02-21 07:04:04','2026-02-21 07:04:51'),(67,'App\\Models\\User',4,'auth_token','645757700c226e940522e901582c63b9abd75c4b8c7d6f85599d7330b3d46ee7','[\"*\"]','2026-02-21 07:05:14',NULL,'2026-02-21 07:05:09','2026-02-21 07:05:14'),(68,'App\\Models\\User',3,'auth_token','9befb9b43b1387f09e5fe0b855aebe5de2231ec02b9ad03b623d61f37d34fb5e','[\"*\"]','2026-02-21 07:07:44',NULL,'2026-02-21 07:05:20','2026-02-21 07:07:44'),(69,'App\\Models\\User',4,'auth_token','413558d43185aeb8bc5fcde4e156661227eebecc9c1a402a8174aabc755d61a7','[\"*\"]','2026-02-21 07:29:29',NULL,'2026-02-21 07:08:16','2026-02-21 07:29:29'),(70,'App\\Models\\User',3,'auth_token','30e940f81322613375e381565d3b44261144b19b230b6dbde8a2eb13b6f4c6d2','[\"*\"]','2026-02-21 08:06:05',NULL,'2026-02-21 07:31:41','2026-02-21 08:06:05'),(71,'App\\Models\\User',4,'auth_token','5686876f33f6a15a56facab303295ce5a378ab500bd43f59117d77ccf80ef985','[\"*\"]','2026-02-21 08:09:44',NULL,'2026-02-21 08:08:04','2026-02-21 08:09:44'),(72,'App\\Models\\CustomerApp',3,'mobile_app','f88f5c2bb191905ebcc0afbfd8e12f2f911187b5bbe707432f606b580204c712','[\"*\"]','2026-02-21 08:22:30',NULL,'2026-02-21 08:09:46','2026-02-21 08:22:30'),(73,'App\\Models\\User',2,'auth_token','634ab06e97a7c3f5e6d7fc62f7966595ffe3989b71a3c899343fd60eeaeda866','[\"*\"]','2026-02-21 08:10:18',NULL,'2026-02-21 08:10:04','2026-02-21 08:10:18'),(74,'App\\Models\\User',3,'auth_token','aea41eb2c074b11fc9e156eadc9a89030fb6380fa51b0baee36763e539978070','[\"*\"]','2026-02-22 04:29:45',NULL,'2026-02-21 08:10:24','2026-02-22 04:29:45'),(75,'App\\Models\\CustomerApp',3,'mobile_app','92d69deb248b626ae2a56fcc6f4429eccd752f19e550cf51ca6fd0313357a6a6','[\"*\"]','2026-02-21 08:52:42',NULL,'2026-02-21 08:24:16','2026-02-21 08:52:42'),(76,'App\\Models\\CustomerApp',3,'mobile_app','1ab5ef30c96f5135e40bed25b533ae0195804ab8452a62a24838bd5abf112149','[\"*\"]','2026-02-21 09:10:04',NULL,'2026-02-21 08:59:37','2026-02-21 09:10:04'),(77,'App\\Models\\CustomerApp',3,'mobile_app','9dd6f95a7b37e7e038d835f4f0b59b4daa2363618fc4a2ff664e19d82cdc7936','[\"*\"]','2026-02-22 04:36:08',NULL,'2026-02-22 04:26:27','2026-02-22 04:36:08'),(78,'App\\Models\\User',3,'auth_token','213d7bfee6c905859b16da3b919d69aa3c293afb5ddf404e275928171624e3cd','[\"*\"]','2026-02-22 05:54:57',NULL,'2026-02-22 04:38:35','2026-02-22 05:54:57'),(80,'App\\Models\\CustomerApp',3,'mobile_app','c40aa38aad28cf5420b33ed66849dea51d44c0ae0a22fa5744d82eb235df8d1c','[\"*\"]','2026-02-22 05:51:31',NULL,'2026-02-22 04:47:44','2026-02-22 05:51:31');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_ratings`
--

DROP TABLE IF EXISTS `product_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_ratings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_ratings_customer_id_product_id_unique` (`customer_id`,`product_id`),
  KEY `product_ratings_product_id_foreign` (`product_id`),
  CONSTRAINT `product_ratings_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customerapp` (`customer_id`) ON DELETE CASCADE,
  CONSTRAINT `product_ratings_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_ratings`
--

LOCK TABLES `product_ratings` WRITE;
/*!40000 ALTER TABLE `product_ratings` DISABLE KEYS */;
INSERT INTO `product_ratings` VALUES (1,2,3,5,'beelo waaye','2026-02-19 08:56:22','2026-02-19 08:56:22'),(2,1,3,3,'good','2026-02-19 09:12:58','2026-02-19 09:12:58');
/*!40000 ALTER TABLE `product_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `product_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) DEFAULT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `supplier_id` bigint(20) unsigned DEFAULT NULL,
  `cost_price` decimal(12,2) NOT NULL,
  `selling_price` decimal(12,2) NOT NULL,
  `discount_price` decimal(10,2) DEFAULT NULL,
  `discount_start_date` datetime DEFAULT NULL,
  `discount_end_date` datetime DEFAULT NULL,
  `wholesale_price` decimal(12,2) DEFAULT NULL,
  `current_stock` int(11) NOT NULL DEFAULT 0,
  `minimum_stock` int(11) NOT NULL DEFAULT 5,
  `maximum_stock` int(11) NOT NULL DEFAULT 100,
  `unit` varchar(20) NOT NULL DEFAULT 'piece',
  `location` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `products_product_code_unique` (`product_code`),
  UNIQUE KEY `products_barcode_unique` (`barcode`),
  KEY `products_supplier_id_foreign` (`supplier_id`),
  KEY `products_created_by_foreign` (`created_by`),
  CONSTRAINT `products_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `products_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'MAC001',NULL,'Macaroni Santa Lucia',NULL,'products/qm7MYxDhFBW1LupVWaB0E5bA5UtbTBiUEO1qNEq8.jpg','Cunto',NULL,0.40,0.60,0.50,'2026-02-21 15:01:00','2026-02-22 15:01:00',NULL,92,5,100,'kg',NULL,NULL,1,NULL,'2026-02-16 10:19:20','2026-02-21 09:01:51'),(2,'SAL001',NULL,'Saliid Cadale 5L',NULL,NULL,'Cunto',NULL,6.50,1.00,NULL,NULL,NULL,NULL,38,5,100,'gacan',NULL,NULL,1,NULL,'2026-02-16 10:19:20','2026-02-19 07:10:16'),(3,'SON001',NULL,'Sonkor 50KG',NULL,NULL,'Cunto',NULL,28.00,32.00,NULL,NULL,NULL,NULL,14,5,100,'bac',NULL,NULL,1,NULL,'2026-02-16 10:19:20','2026-02-21 05:46:35'),(4,'BUR001',NULL,'Bur Libaax 50KG',NULL,NULL,'Cunto',NULL,24.50,28.00,NULL,NULL,NULL,NULL,12,5,100,'bac',NULL,NULL,1,NULL,'2026-02-16 10:19:20','2026-02-19 06:03:19'),(5,'BAS001',NULL,'Bariis Bunni 25KG',NULL,NULL,'Cunto',NULL,18.00,22.00,19.00,'2026-02-21 14:10:00','2026-02-21 14:26:00',NULL,23,5,100,'bac',NULL,NULL,1,NULL,'2026-02-16 10:19:20','2026-02-21 08:23:21'),(6,'1847929233',NULL,'bariis',NULL,NULL,'Cunto',NULL,10.00,2.00,NULL,NULL,NULL,NULL,-2,5,100,'piece',NULL,NULL,1,NULL,'2026-02-18 07:39:29','2026-02-19 06:03:19');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions`
--

DROP TABLE IF EXISTS `promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions` (
  `promotion_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`promotion_id`),
  KEY `promotions_product_id_foreign` (`product_id`),
  CONSTRAINT `promotions_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions`
--

LOCK TABLES `promotions` WRITE;
/*!40000 ALTER TABLE `promotions` DISABLE KEYS */;
INSERT INTO `promotions` VALUES (1,'Dukaanka Xaafada','hello','promotions/7q1BlmMIl4trbcKZjsIEFf29D5w1bUYSi9DDj4wn.webp',1,NULL,NULL,1,'2026-02-21 06:26:36','2026-02-21 07:32:56'),(2,'Iqlaas Collection','Waxaan Kuu Heeynaa Dharka Iyo Kabaha Dumarka','promotions/Mk4VoagxTRYXllfafkXyGzzYESLIhQDCHUTie5GB.png',1,'2026-02-21 12:41:00','2026-02-28 12:41:00',NULL,'2026-02-21 06:41:48','2026-02-21 06:41:48'),(3,'Iqlaas','Dukaanka Dumarka','promotions/EukThnNgx6YB9j3ADrLCSPIHegDIygWbPQUSAQjf.png',1,'2026-02-21 13:02:00','2026-02-28 13:02:00',NULL,'2026-02-21 07:02:47','2026-02-21 07:02:47'),(4,'Xaawo Lul','Dukaanka Qudaarta','promotions/nEu8k1a9zueVIFG537IkGErESPDNactTH2WHRZN0.jpg',0,'2026-02-22 10:46:00','2026-02-22 10:48:00',NULL,'2026-02-22 04:47:03','2026-02-22 04:49:22');
/*!40000 ALTER TABLE `promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_items`
--

DROP TABLE IF EXISTS `purchase_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_items` (
  `purchase_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint(20) unsigned NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit` varchar(255) NOT NULL DEFAULT 'piece',
  `unit_price` decimal(12,2) NOT NULL,
  `total_price` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`purchase_item_id`),
  KEY `purchase_items_purchase_id_foreign` (`purchase_id`),
  KEY `purchase_items_product_id_foreign` (`product_id`),
  CONSTRAINT `purchase_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  CONSTRAINT `purchase_items_purchase_id_foreign` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`purchase_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_items`
--

LOCK TABLES `purchase_items` WRITE;
/*!40000 ALTER TABLE `purchase_items` DISABLE KEYS */;
INSERT INTO `purchase_items` VALUES (1,1,'bariis',NULL,2,'piece',10.00,20.00,'2026-02-18 04:39:18','2026-02-18 04:39:18');
/*!40000 ALTER TABLE `purchase_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases` (
  `purchase_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_id` bigint(20) unsigned NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `transport_method` enum('Bajaj','Vekon','Car','Other') NOT NULL DEFAULT 'Other',
  `transport_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `purchase_date` date NOT NULL,
  `status` enum('pending','received','cancelled') NOT NULL DEFAULT 'received',
  `notes` text DEFAULT NULL,
  `document_path` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`purchase_id`),
  KEY `purchases_supplier_id_foreign` (`supplier_id`),
  KEY `purchases_created_by_foreign` (`created_by`),
  CONSTRAINT `purchases_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `purchases_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (1,1,20.00,'Vekon',2.00,'2026-02-18','received',NULL,'purchases/RPP1cQLN6iOTS1bJz0B3mAJzhiSFWnramLKLpeZE.png',3,'2026-02-18 04:39:18','2026-02-18 04:39:18');
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_items`
--

DROP TABLE IF EXISTS `sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_items` (
  `sale_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `taken_quantity` int(11) NOT NULL DEFAULT 0,
  `unit_price` decimal(12,2) NOT NULL,
  `discount_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(12,2) NOT NULL,
  `cost_price` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sale_item_id`),
  KEY `sale_items_sale_id_foreign` (`sale_id`),
  KEY `sale_items_product_id_foreign` (`product_id`),
  CONSTRAINT `sale_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  CONSTRAINT `sale_items_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_items`
--

LOCK TABLES `sale_items` WRITE;
/*!40000 ALTER TABLE `sale_items` DISABLE KEYS */;
INSERT INTO `sale_items` VALUES (1,1,1,1,0,0.60,0.00,0.60,0.40,NULL,NULL),(2,2,1,1,0,0.60,0.00,0.60,0.40,NULL,NULL),(3,3,6,1,0,2.00,0.00,2.00,10.00,NULL,NULL),(4,4,6,1,0,2.00,0.00,2.00,10.00,NULL,NULL),(5,5,1,1,0,0.60,0.00,0.60,0.40,NULL,NULL),(6,6,3,1,0,32.00,0.00,32.00,28.00,NULL,NULL),(7,7,1,2,0,0.60,0.00,1.20,0.40,NULL,NULL),(8,7,2,2,0,1.00,0.00,2.00,6.50,NULL,NULL),(9,7,3,3,0,32.00,0.00,96.00,28.00,NULL,NULL),(10,7,4,2,0,28.00,0.00,56.00,24.50,NULL,NULL),(11,7,6,2,0,2.00,0.00,4.00,10.00,NULL,NULL),(12,7,5,4,0,22.00,0.00,88.00,18.00,NULL,NULL),(13,8,2,1,0,1.00,0.00,1.00,6.50,NULL,NULL),(14,9,1,1,0,0.60,0.00,0.60,0.40,NULL,NULL),(15,10,3,1,0,32.00,0.00,32.00,28.00,NULL,NULL);
/*!40000 ALTER TABLE `sale_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `sale_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `customer_app_id` bigint(20) unsigned DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_phone` varchar(255) DEFAULT NULL,
  `customer_address` text DEFAULT NULL,
  `delivery_type` enum('none','bajaj','vekon','plane') NOT NULL DEFAULT 'none',
  `delivery_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `cashier_id` bigint(20) unsigned DEFAULT NULL,
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `subtotal` decimal(12,2) NOT NULL,
  `discount_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL DEFAULT 0.00,
  `balance_due` decimal(12,2) NOT NULL DEFAULT 0.00,
  `cancellation_fee` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) NOT NULL,
  `payment_status` enum('paid','partial','credit','pending','cancelled') DEFAULT 'paid',
  `is_walpo` tinyint(1) NOT NULL DEFAULT 0,
  `transaction_reference` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `sales_invoice_number_unique` (`invoice_number`),
  KEY `sales_customer_id_foreign` (`customer_id`),
  KEY `sales_cashier_id_foreign` (`cashier_id`),
  KEY `sales_customer_app_id_foreign` (`customer_app_id`),
  CONSTRAINT `sales_cashier_id_foreign` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `sales_customer_app_id_foreign` FOREIGN KEY (`customer_app_id`) REFERENCES `customerapp` (`customer_id`) ON DELETE SET NULL,
  CONSTRAINT `sales_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'INV-69931AB577889',NULL,NULL,NULL,NULL,NULL,'none',0.00,3,'2026-02-16 10:25:09',0.60,0.00,0.00,0.60,0.60,0.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-16 10:25:09','2026-02-16 10:25:09'),(2,'INV-699472FC2A388',NULL,NULL,NULL,NULL,NULL,'none',0.00,3,'2026-02-17 10:54:04',0.60,0.00,0.00,0.60,0.60,0.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-17 10:54:04','2026-02-17 10:54:04'),(3,'INV-699598E9BE29D',NULL,NULL,NULL,NULL,NULL,'none',0.00,2,'2026-02-18 07:48:09',2.00,0.00,0.00,2.00,2.00,0.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-18 07:48:09','2026-02-18 07:48:09'),(4,'INV-69959A53A3305',NULL,NULL,NULL,NULL,NULL,'none',0.00,2,'2026-02-18 07:54:11',2.00,0.00,0.00,2.00,2.00,0.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-18 07:54:11','2026-02-18 07:54:11'),(5,'INV-6995AE5C46B89',NULL,NULL,NULL,NULL,NULL,'none',0.00,3,'2026-02-18 09:19:40',0.60,0.00,0.00,0.60,0.60,0.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-18 09:19:40','2026-02-18 09:19:40'),(6,'INV-6996D19C61EA2',NULL,NULL,NULL,NULL,NULL,'none',0.00,3,'2026-02-19 06:02:20',32.00,1.00,0.00,31.00,31.00,0.00,0.00,'cash','paid',0,NULL,NULL,'2026-02-19 06:02:20','2026-02-19 06:02:20'),(7,'INV-6996D1D7C68A3',NULL,NULL,NULL,NULL,NULL,'none',0.00,3,'2026-02-19 06:03:19',247.20,7.00,0.00,240.20,240.20,0.00,0.00,'evc_plus','paid',0,NULL,NULL,'2026-02-19 06:03:19','2026-02-19 06:03:19'),(8,'MOB-6996E1881D804',NULL,2,NULL,NULL,NULL,'vekon',2.00,NULL,'2026-02-19 07:10:16',1.00,0.00,0.00,3.00,1.00,0.00,0.00,'evc_plus','paid',0,NULL,'Delivery Address: wartanabada','2026-02-19 07:10:16','2026-02-19 10:03:18'),(9,'MOB-69995C548050D',NULL,2,'mohamed abdihakiin','613334455','Wartanabada','none',0.00,NULL,'2026-02-21 04:18:44',0.60,0.00,0.00,0.60,0.00,0.60,0.00,'evc_plus','pending',0,NULL,'Order placed via Mobile App.','2026-02-21 04:18:44','2026-02-21 04:18:44'),(10,'MOB-699970EB30D45',NULL,3,'Abdirahman Abdulkadir','627083069','Wadajir','vekon',1.00,NULL,'2026-02-21 05:46:35',32.00,0.00,0.00,33.00,32.00,0.00,0.00,'cash','paid',0,NULL,'Order placed via Mobile App.','2026-02-21 05:46:35','2026-02-21 06:59:54');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `supplier_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `tax_number` varchar(50) DEFAULT NULL,
  `payment_terms` varchar(50) DEFAULT NULL,
  `contract_start` date DEFAULT NULL,
  `contract_end` date DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'dabaay','abdul',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'active',NULL,'2026-02-18 04:33:36','2026-02-18 04:33:36');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `setting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(255) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(255) NOT NULL DEFAULT 'string',
  `description` text DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `system_settings_setting_key_unique` (`setting_key`),
  KEY `system_settings_updated_by_foreign` (`updated_by`),
  CONSTRAINT `system_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'store_name','MAANKA SHOB','string','The official name of the store',3,'2026-02-21 12:00:55'),(2,'store_address','Main Street, Mogadishu, Somalia','string','Physical address of the store',3,'2026-02-17 07:43:18'),(3,'store_number','+252 683632095','string','Primary contact number',3,'2026-02-17 07:43:18'),(4,'store_logo','branding/CF9fciiN0BD7o0Qukdfng8a7ztLSDgiYpP6hFn3u.webp','image','Store logo image path',3,'2026-02-21 11:57:25'),(5,'tiktok_handle','@somali_store','string','TikTok username',3,'2026-02-17 07:43:18'),(6,'tiktok_show','true','boolean','Whether to show TikTok in printed documents',3,'2026-02-17 07:43:18'),(7,'facebook_handle','somali.store','string','Facebook page name/handle',3,'2026-02-17 07:43:18'),(8,'facebook_show','true','boolean','Whether to show Facebook in printed documents',3,'2026-02-17 07:43:18'),(9,'instagram_handle','somali_store','string','Instagram handle',3,'2026-02-17 07:43:18'),(10,'instagram_show','true','boolean','Whether to show Instagram in printed documents',3,'2026-02-17 07:43:18'),(11,'whatsapp_number','+252 683632095','string','WhatsApp contact number',3,'2026-02-17 07:43:18'),(12,'whatsapp_show','true','boolean','Whether to show WhatsApp in printed documents',3,'2026-02-17 07:43:18'),(13,'show_social_labels','true','boolean','Whether to show the name/label of social media handles next to icons',3,'2026-02-17 07:43:18'),(14,'app_version','1.0.0','string','Current published version of the mobile customer app',3,'2026-02-21 12:00:55'),(15,'app_download_url',NULL,'string','URL where customers can download the latest APK',3,'2026-02-21 12:00:55');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `plain_password` varchar(255) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `role` enum('admin','cashier','app_manager') NOT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` timestamp NULL DEFAULT NULL,
  `last_logout_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$12$yZg5tPEw8jUL8YabeNNDQuqV1QlvKFLE3Hnzo/swe4yrE4hQenMt.',NULL,'Admin Somali POS',NULL,NULL,'admin',NULL,1,0,NULL,NULL,'2026-02-16 10:19:20','2026-02-16 10:19:20'),(2,'maanka','$2y$12$W.jLnP/I0IhsVEUAJ5Cp/urDyEzZeXRsxvo9ORTSL9BH1NnOzQdYC','maanka1','maanka abdulkadir','maanka@gmail.com','683632095','cashier','{\"modules\":{\"pos\":true,\"customers\":true,\"sales_history\":true,\"expenses\":true,\"walpo\":true,\"reports\":true},\"actions\":{\"record\":true,\"edit\":true}}',1,1,'2026-02-21 08:10:04',NULL,'2026-02-16 10:19:20','2026-02-21 08:10:04'),(3,'dabaay','$2y$12$P.zuYfizfebH4pTJWDLtbeOEwf7FLZPqL77n1vkYchPjI.7VzYnQK','dabaay12','Abdirahman Abdulkadir',NULL,NULL,'admin',NULL,1,1,'2026-02-22 04:38:35',NULL,'2026-02-16 10:19:20','2026-02-22 04:38:35'),(4,'aniza','$2y$12$Mttksj/PPlK.gIEV4JGNo.XnP9.nGswu5wsIAgON5X1VaysmKqTqa','aniza1','aniza abdul',NULL,NULL,'app_manager','{\"modules\":{\"mobile_management\":true,\"users\":true},\"actions\":{\"record\":true,\"edit\":true,\"manage_users\":true}}',1,1,'2026-02-21 08:08:04',NULL,'2026-02-19 08:15:36','2026-02-21 08:08:04');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-22 11:54:58

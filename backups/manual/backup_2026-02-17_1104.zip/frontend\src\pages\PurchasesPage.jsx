import React, { useState, useEffect, useCallback } from 'react';
import api from '../api/axios';
import { 
    Truck, 
    Plus, 
    Search, 
    Calendar, 
    DollarSign, 
    Package, 
    Trash2, 
    Save, 
    X, 
    History,
    ChevronRight,
    ArrowRight,
    MapPin,
    AlertCircle
} from 'lucide-react';
import Modal from '../components/Modal';

const PurchasesPage = () => {
    const [purchases, setPurchases] = useState([]);
    const [products, setProducts] = useState([]);
    const [suppliers, setSuppliers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    
    // Modal state
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [formLoading, setFormLoading] = useState(false);
    const [purchaseForm, setPurchaseForm] = useState({
        supplier_id: '',
        purchase_date: new Date().toISOString().split('T')[0],
        transport_method: 'Bajaj',
        transport_cost: 0,
        status: 'received',
        notes: '',
        items: []
    });

    const fetchPurchases = useCallback(async () => {
        try {
            const response = await api.get('/purchases');
            setPurchases(response.data || []);
        } catch (error) {
            console.error('Error fetching purchases:', error);
        }
    }, []);

    const fetchDropdowns = useCallback(async () => {
        try {
            const [prodRes, suppRes] = await Promise.all([
                api.get('/products'),
                api.get('/suppliers')
            ]);
            setProducts(prodRes.data.data || prodRes.data || []);
            setSuppliers(suppRes.data.data || suppRes.data || []);
        } catch (error) {
            console.error('Error fetching dropdowns:', error);
        }
    }, []);

    useEffect(() => {
        const init = async () => {
            setLoading(true);
            await Promise.all([fetchPurchases(), fetchDropdowns()]);
            setLoading(false);
        };
        init();
    }, [fetchPurchases, fetchDropdowns]);

    const handleAddItem = () => {
        setPurchaseForm({
            ...purchaseForm,
            items: [...purchaseForm.items, { product_id: '', quantity: 1, unit_price: 0 }]
        });
    };

    const handleRemoveItem = (index) => {
        const newItems = [...purchaseForm.items];
        newItems.splice(index, 1);
        setPurchaseForm({ ...purchaseForm, items: newItems });
    };

    const handleItemChange = (index, field, value) => {
        const newItems = [...purchaseForm.items];
        newItems[index][field] = value;
        
        // If product changed, try to find default price (optional, but good for UX)
        if (field === 'product_id') {
            const prod = products.find(p => p.product_id === parseInt(value));
            if (prod) {
                // We might use wholesale_price if available, but for now we'll just keep it manual
            }
        }
        
        setPurchaseForm({ ...purchaseForm, items: newItems });
    };

    const calculateSubtotal = () => {
        return purchaseForm.items.reduce((sum, item) => sum + (parseFloat(item.unit_price) * parseInt(item.quantity) || 0), 0);
    };

    const calculateTotal = () => {
        return calculateSubtotal() + parseFloat(purchaseForm.transport_cost || 0);
    };

    const handleSave = async (e) => {
        e.preventDefault();
        if (purchaseForm.items.length === 0) {
            alert('Fadlan ku dar ugu yaraan hal sheey.');
            return;
        }

        setFormLoading(true);
        try {
            await api.post('/purchases', purchaseForm);
            setIsModalOpen(false);
            fetchPurchases();
            setPurchaseForm({
                supplier_id: '',
                purchase_date: new Date().toISOString().split('T')[0],
                transport_method: 'Bajaj',
                transport_cost: 0,
                status: 'received',
                notes: '',
                items: []
            });
        } catch (error) {
            alert('Khalad ayaa dhacay: ' + (error.response?.data?.message || 'Hubi xogta'));
        } finally {
            setFormLoading(false);
        }
    };

    const filteredPurchases = purchases.filter(p => 
        p.supplier?.company_name.toLowerCase().includes(search.toLowerCase()) ||
        p.purchase_id.toString().includes(search)
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-1">Iibka Supplier (Purchases)</h1>
                    <p className="text-slate-400">Diiwaangeli alaabta aad ka soo iibsatay suppliers-ka.</p>
                </div>
                <button 
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center space-x-2 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20"
                >
                    <Plus size={20} />
                    <span>Iib Cusub (New Purchase)</span>
                </button>
            </div>

            <div className="bg-secondary/40 border border-[#334155] rounded-3xl overflow-hidden backdrop-blur-md shadow-2xl">
                <div className="p-6 border-b border-[#334155]">
                    <div className="relative max-w-md">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                        <input 
                            type="text" 
                            placeholder="Raadi supplier ama ID..." 
                            className="w-full pl-12 pr-4 py-3 bg-primary/50 border border-[#334155] rounded-2xl text-white outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="bg-slate-800/50 text-slate-400 text-xs uppercase tracking-widest font-bold">
                                <th className="px-6 py-4">Purchase ID</th>
                                <th className="px-6 py-4">Supplier</th>
                                <th className="px-6 py-4">Taariikhda</th>
                                <th className="px-6 py-4">Transport</th>
                                <th className="px-6 py-4 text-right">Cadadka</th>
                                <th className="px-6 py-4">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-[#334155]">
                            {loading ? (
                                <tr>
                                    <td colSpan="6" className="px-6 py-12 text-center text-slate-500">Xogta waa la soo rarayaa...</td>
                                </tr>
                            ) : filteredPurchases.length === 0 ? (
                                <tr>
                                    <td colSpan="6" className="px-6 py-12 text-center text-slate-500">Ma jiraan iib la helay.</td>
                                </tr>
                            ) : filteredPurchases.map((p) => (
                                <tr key={p.purchase_id} className="hover:bg-slate-800/30 transition-colors group">
                                    <td className="px-6 py-4 font-mono text-xs text-blue-400 font-bold">#P-{p.purchase_id}</td>
                                    <td className="px-6 py-4 text-white font-medium">{p.supplier?.company_name}</td>
                                    <td className="px-6 py-4 text-slate-400 text-sm">{new Date(p.purchase_date).toLocaleDateString()}</td>
                                    <td className="px-6 py-4">
                                        <div className="flex flex-col">
                                            <span className="text-xs text-slate-300 font-bold">{p.transport_method}</span>
                                            <span className="text-[10px] text-slate-500">${parseFloat(p.transport_cost).toFixed(2)}</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-right font-black text-white">${parseFloat(p.total_amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${
                                            p.status === 'received' ? 'bg-emerald-500/10 text-emerald-400' : 
                                            p.status === 'pending' ? 'bg-amber-500/10 text-amber-400' : 
                                            'bg-rose-500/10 text-rose-400'
                                        }`}>
                                            {p.status.toUpperCase()}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                        {filteredPurchases.length > 0 && (
                            <tfoot className="bg-slate-800/80 backdrop-blur-md sticky bottom-0 border-t-2 border-[#334155] z-10">
                                <tr>
                                    <td colSpan="4" className="px-6 py-5 text-right text-slate-400 text-xs font-black uppercase tracking-widest">
                                        Wadarta Iibka (Total Purchases):
                                    </td>
                                    <td className="px-6 py-5 text-right text-white text-sm font-black whitespace-nowrap">
                                        ${filteredPurchases.reduce((sum, p) => sum + parseFloat(p.total_amount || 0), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                    </td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        )}
                    </table>
                </div>
            </div>

            {/* Purchase Modal */}
            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title="Diiwaangeli Iib Cusub"
                maxWidth="max-w-4xl"
            >
                <form onSubmit={handleSave} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div className="space-y-2">
                            <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">Supplier</label>
                            <select 
                                required
                                className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                                value={purchaseForm.supplier_id}
                                onChange={(e) => setPurchaseForm({...purchaseForm, supplier_id: e.target.value})}
                            >
                                <option value="">Dooro Supplier</option>
                                {suppliers.map(s => (
                                    <option key={s.supplier_id} value={s.supplier_id}>{s.company_name}</option>
                                ))}
                            </select>
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">Taariikhda</label>
                            <input 
                                required
                                type="date" 
                                className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                                value={purchaseForm.purchase_date}
                                onChange={(e) => setPurchaseForm({...purchaseForm, purchase_date: e.target.value})}
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">Status</label>
                            <select 
                                required
                                className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                                value={purchaseForm.status}
                                onChange={(e) => setPurchaseForm({...purchaseForm, status: e.target.value})}
                            >
                                <option value="received">Received (Alaabta waad heshay)</option>
                                <option value="pending">Pending (Weli ma helin)</option>
                            </select>
                        </div>
                    </div>

                    <div className="p-5 bg-slate-800/30 rounded-2xl border border-[#334155] space-y-4">
                        <div className="flex items-center justify-between mb-2">
                            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-widest">Alaabta la soo iibsaday</h3>
                            <button 
                                type="button" 
                                onClick={handleAddItem}
                                className="px-3 py-1.5 bg-blue-600/10 text-blue-400 rounded-lg text-xs font-bold hover:bg-blue-600 hover:text-white transition-all flex items-center space-x-2"
                            >
                                <Plus size={14} />
                                <span>Ku dar line</span>
                            </button>
                        </div>

                        <div className="space-y-3">
                            {purchaseForm.items.map((item, index) => (
                                <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end bg-primary/30 p-3 rounded-xl border border-[#334155]">
                                    <div className="space-y-2 md:col-span-2">
                                        <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest pl-1">Alaabta (Product)</label>
                                        <select 
                                            required
                                            className="w-full bg-slate-800 border border-[#334155] rounded-lg px-3 py-2 text-white text-sm outline-none"
                                            value={item.product_id}
                                            onChange={(e) => handleItemChange(index, 'product_id', e.target.value)}
                                        >
                                            <option value="">Dooro Alaab</option>
                                            {products.map(p => (
                                                <option key={p.product_id} value={p.product_id}>{p.name} (Stock: {p.current_stock})</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest pl-1">Quantity</label>
                                        <input 
                                            required
                                            type="number" 
                                            min="1"
                                            className="w-full bg-slate-800 border border-[#334155] rounded-lg px-3 py-2 text-white text-sm outline-none"
                                            value={item.quantity}
                                            onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                                        />
                                    </div>
                                    <div className="space-y-2 relative">
                                        <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest pl-1">Unit Price ($)</label>
                                        <div className="flex items-center space-x-2">
                                            <input 
                                                required
                                                type="number" 
                                                step="0.01"
                                                min="0"
                                                className="w-full bg-slate-800 border border-[#334155] rounded-lg px-3 py-2 text-white text-sm outline-none"
                                                value={item.unit_price}
                                                onChange={(e) => handleItemChange(index, 'unit_price', e.target.value)}
                                            />
                                            <button 
                                                type="button" 
                                                onClick={() => handleRemoveItem(index)}
                                                className="p-2 text-slate-500 hover:text-rose-400 transition-all"
                                            >
                                                <Trash2 size={16} />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            {purchaseForm.items.length === 0 && (
                                <div className="text-center py-8 bg-primary/20 rounded-xl border border-dashed border-[#334155] text-slate-500 text-sm italic">
                                    Wax alaab ah weli kuma aadan darin iibka.
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-widest">Gaadiidka (Transportation)</h3>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest pl-1">Method</label>
                                    <select 
                                        className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white text-sm outline-none"
                                        value={purchaseForm.transport_method}
                                        onChange={(e) => setPurchaseForm({...purchaseForm, transport_method: e.target.value})}
                                    >
                                        <option value="Bajaj">Bajaj</option>
                                        <option value="Vekon">Vekon</option>
                                        <option value="Car">Car (Baabuur)</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest pl-1">Cost ($)</label>
                                    <input 
                                        type="number" 
                                        step="0.01"
                                        className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white text-sm outline-none"
                                        value={purchaseForm.transport_cost}
                                        onChange={(e) => setPurchaseForm({...purchaseForm, transport_cost: e.target.value})}
                                    />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest pl-1">Notes</label>
                                <textarea 
                                    className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white text-sm outline-none h-20"
                                    value={purchaseForm.notes}
                                    onChange={(e) => setPurchaseForm({...purchaseForm, notes: e.target.value})}
                                    placeholder="Fariin dheeraad ah..."
                                ></textarea>
                            </div>
                        </div>

                        <div className="bg-blue-600/5 p-6 rounded-3xl border border-blue-500/10 space-y-4">
                            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-widest">Summary (Wadarta)</h3>
                            <div className="space-y-2 border-b border-[#334155] pb-4">
                                <div className="flex justify-between text-slate-400">
                                    <span>Subtotal:</span>
                                    <span>${calculateSubtotal().toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between text-slate-400">
                                    <span>Transport:</span>
                                    <span>${parseFloat(purchaseForm.transport_cost || 0).toFixed(2)}</span>
                                </div>
                            </div>
                            <div className="flex justify-between items-center pt-2">
                                <span className="text-xl font-bold text-white uppercase tracking-tighter italic">Total Amount</span>
                                <span className="text-3xl font-black text-blue-400">${calculateTotal().toFixed(2)}</span>
                            </div>
                            
                            <button 
                                type="submit"
                                disabled={formLoading}
                                className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-lg shadow-lg shadow-blue-500/20 transition-all flex items-center justify-center space-x-2 mt-4"
                            >
                                {formLoading ? <AlertCircle className="animate-spin" size={24} /> : <Save size={24} />}
                                <span>{formLoading ? 'Waa la keydinayaa...' : 'Keydi Iibka (Save Purchase)'}</span>
                            </button>
                        </div>
                    </div>
                </form>
            </Modal>
        </div>
    );
};

export default PurchasesPage;

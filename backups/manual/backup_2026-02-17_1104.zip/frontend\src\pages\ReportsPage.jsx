```
import React, { useState, useEffect, useCallback } from 'react';
import { useLanguage } from '../context/useLanguage';
import { useSettings } from '../context/SettingsContextDef';
import api from '../api/axios';
import { 
    Download, 
    ArrowUpRight,
    ArrowDownRight,
    Loader2,
    DollarSign,
    Package,
    History,
    CreditCard,
    TrendingUp,
    BarChart3,
    ShoppingCart as ShopIcon,
    Users,
    FileText,
    ChevronRight,
    LayoutDashboard,
    Wallet,
    PieChart as PieIcon,
    AlertCircle,
    Printer
} from 'lucide-react';
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer,
    PieChart,
    Pie,
    Cell,
    LineChart,
    Line,
    AreaChart,
    Area,
    ComposedChart
} from 'recharts';
import ChartCard from '../components/ChartCard';

const ReportCard = ({ title, value, subValue, trend, icon, color }) => {
    const Icon = icon;
    const colorClasses = {
        blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
        emerald: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
        amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
        rose: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
        indigo: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
    };
    
    return (
        <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm hover:border-blue-500/30 transition-all duration-300 group">
            <div className="flex justify-between items-start mb-4">
                <div className={`p-3 rounded-xl border ${colorClasses[color] || 'bg-slate-500/10 text-slate-400 border-slate-500/20'}`}>
                    <Icon size={24} />
                </div>
                {trend !== undefined && trend !== null && (
                    <span className={`flex items-center text-xs font-bold px-2 py-1 rounded-lg ${trend > 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                        {trend > 0 ? <ArrowUpRight size={14} className="mr-1" /> : <ArrowDownRight size={14} className="mr-1" />}
                        {Math.abs(trend)}%
                    </span>
                )}
            </div>
            <div>
                <p className="text-slate-400 text-sm font-medium mb-1">{title}</p>
                <h4 className="text-2xl font-bold text-white mb-1 group-hover:text-blue-400 transition-colors">{value}</h4>
                <p className="text-xs text-slate-500 flex items-center">
                    {subValue}
                </p>
            </div>
        </div>
    );
};

const ReportsPage = () => {
    const { t } = useLanguage();
    const { settings } = useSettings();
    const [stats, setStats] = useState(null);
    const [activeTab, setActiveTab] = useState('dashboard');
    const [startDate, setStartDate] = useState(new Date(new Date().setDate(new Date().getDate() - 30)).toISOString().split('T')[0]);
    const [endDate, setEndDate] = new Date().toISOString().split('T')[0]);
    const [analytics, setAnalytics] = useState({
        dashboard: null,
        products: null,
        customers: null,
        walpo: null,
        expenses: null,
        comprehensive: null
    });
    const [loading, setLoading] = useState(true);

    const fetchAllData = useCallback(async () => {
        try {
            setLoading(true);
            const params = { start_date: startDate, end_date: endDate };
            const [
                statsRes, 
                dashboardAn, 
                productsAn, 
                customersAn, 
                walpoAn, 
                expensesAn,
                comprehensiveAn
            ] = await Promise.all([
                api.get('/stats', { params }),
                api.get('/analytics/dashboard', { params }),
                api.get('/analytics/products', { params }),
                api.get('/analytics/customers', { params }),
                api.get('/analytics/walpo', { params }),
                api.get('/analytics/expenses', { params }),
                api.get('/analytics/comprehensive', { params })
            ]);

            setStats(statsRes.data);
            setAnalytics({
                dashboard: dashboardAn.data,
                products: productsAn.data,
                customers: customersAn.data,
                walpo: walpoAn.data,
                expenses: expensesAn.data,
                comprehensive: comprehensiveAn.data
            });
        } catch (error) {
            console.error('Error fetching reporting data:', error);
        } finally {
            setLoading(false);
        }
    }, [startDate, endDate]);

    const formatPrintValue = (val, isCurrency = false) => {
        if (!val || val == 0) return '';
        if (isCurrency) {
            return `$${parseFloat(val).toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
        }
        return val;
    };

    // fetchSettings is no longer needed here as settings are provided by context
    // const fetchSettings = useCallback(async () => {
    //     try {
    //         const response = await api.get('/settings');
    //         setSettings(prev => ({ ...prev, ...response.data }));
    //     } catch (error) {
    //         console.error('Error fetching settings:', error);
    //     }
    // }, []);

    useEffect(() => {
        fetchAllData();
        // fetchSettings(); // No longer needed
    }, [fetchAllData]); // Removed fetchSettings from dependencies

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-full space-y-4">
            <Loader2 className="animate-spin text-blue-500" size={48} />
            <p className="text-slate-400 font-medium animate-pulse">Soo rarista warbixinada...</p>
        </div>
    );

    const tabs = [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'sales', label: 'Iibka (Sales)', icon: TrendingUp },
        { id: 'inventory', label: 'Kaydka (Stock)', icon: Package },
        { id: 'financials', label: 'Lacagaha (Finance)', icon: Wallet },
        { id: 'customers', label: 'Daymaha (Debt)', icon: Users },
    ];

    const renderContent = () => {
        switch (activeTab) {
            case 'dashboard':
                return (
                    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            <ReportCard title="Dakhliga Guud" value={`$${(stats?.system_overview?.total_revenue || 0).toLocaleString()}`} subValue="Total Revenue" trend={12.5} icon={TrendingUp} color="blue" />
                            <ReportCard title="Macaamiisha" value={stats?.summary?.total_customers || 0} subValue="Active Customers" trend={8.2} icon={Users} color="emerald" />
                            <ReportCard title="Iibka Maanta" value={stats?.summary?.today_sales || 0} subValue="Today's Sales" trend={null} icon={ShopIcon} color="amber" />
                            <ReportCard title="Alaab Gabaabsi" value={stats?.summary?.low_stock_count || 0} subValue="Low Stock Alert" trend={null} icon={AlertCircle} color="rose" />
                        </div>
                        <div id="dashboard-section" className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <ChartCard title="Revenue Trend" subtitle="Daily income performance">
                                <AreaChart data={analytics.dashboard?.salesTrend || []}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} />
                                    <YAxis stroke="#94a3b8" fontSize={12} tickFormatter={(val) => `$${val}`} />
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }} />
                                    <Area type="monotone" dataKey="total" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
                                    <defs>
                                        <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                </AreaChart>
                            </ChartCard>
                            <ChartCard title="Payment Distribution" subtitle="Sales by payment source">
                                <PieChart>
                                    <Pie data={analytics.dashboard?.paymentMethods || []} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={8} dataKey="value">
                                        {analytics.dashboard?.paymentMethods?.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'][index % 4]} stroke="none" />
                                        ))}
                                    </Pie>
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }} />
                                    <Legend verticalAlign="bottom" height={36}/>
                                </PieChart>
                            </ChartCard>
                        </div>
                    </div>
                );
            case 'sales':
                return (
                    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
                        <ChartCard title="Product Category Revenue" subtitle="Income distribution by category">
                            <BarChart data={analytics.products?.revenueByCategory || []}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                                <YAxis stroke="#94a3b8" fontSize={12} tickFormatter={(val) => `$${val}`} />
                                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }} />
                                <Bar dataKey="value" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                            </BarChart>
                        </ChartCard>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm">
                                <h3 className="text-white font-bold mb-6 flex items-center"><TrendingUp className="text-blue-400 mr-2" size={20} /> Alaabta ugu iibka badan</h3>
                                <div className="space-y-4">
                                    {(analytics.comprehensive?.mostPurchased || []).map((p, i) => (
                                        <div key={i} className="flex justify-between items-center p-3 rounded-xl bg-white/5 border border-white/5 hover:border-blue-500/30 transition-all">
                                            <div>
                                                <p className="text-white font-bold text-sm">{p.name}</p>
                                                <p className="text-xs text-slate-500">{p.freq} separate orders</p>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-blue-400 font-bold">{p.total_qty}</p>
                                                <p className="text-[10px] text-slate-500 uppercase">Units Sold</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm">
                                <h3 className="text-white font-bold mb-6 flex items-center"><DollarSign className="text-emerald-400 mr-2" size={20} /> Alaabta ugu qaalisan</h3>
                                <div className="space-y-4">
                                    {(analytics.comprehensive?.mostExpensive || []).map((p, i) => (
                                        <div key={i} className="flex justify-between items-center p-3 rounded-xl bg-white/5 border border-white/5 hover:border-emerald-500/30 transition-all">
                                            <span className="text-white font-medium text-sm">{p.name}</span>
                                            <span className="text-emerald-400 font-bold">${parseFloat(p.selling_price || 0).toFixed(2)}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                );
            case 'inventory':
                return (
                    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <ChartCard title="Stock by Category" subtitle="Total units breakdown" className="lg:col-span-1">
                                <PieChart>
                                    <Pie data={analytics.products?.stockByCategory || []} cx="50%" cy="50%" innerRadius={40} outerRadius={70} paddingAngle={5} dataKey="value">
                                        {analytics.products?.stockByCategory?.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6'][index % 4]} stroke="none" />
                                        ))}
                                    </Pie>
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }} />
                                    <Legend />
                                </PieChart>
                            </ChartCard>
                            <div className="lg:col-span-2 bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm overflow-hidden">
                                <h3 className="text-white font-bold mb-6 flex items-center"><AlertCircle className="text-amber-400 mr-2" size={20} /> Alaabta Aan La Iibsan (Stagnant Stock)</h3>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left">
                                        <thead>
                                            <tr className="text-xs text-slate-500 uppercase border-b border-[#334155]">
                                                <th className="pb-4 font-semibold">Alaabta</th>
                                                <th className="pb-4 font-semibold">Stock</th>
                                                <th className="pb-4 font-semibold">Price</th>
                                                <th className="pb-4 font-semibold">Added Date</th>
                                            </tr>
                                        </thead>
                                        <tbody className="text-sm">
                                            {(analytics.comprehensive?.stagnantStock || []).slice(0, 10).map((p, i) => (
                                                <tr key={i} className="border-b border-[#334155]/20 hover:bg-white/5 transition-colors group">
                                                    <td className="py-4 text-white font-medium">{p.name}</td>
                                                    <td className="py-4 text-slate-400">{p.current_stock || 0}</td>
                                                    <td className="py-4 text-emerald-400 font-bold">${parseFloat(p.selling_price || 0).toFixed(2)}</td>
                                                    <td className="py-4 text-slate-500">{p.created_at ? new Date(p.created_at).toLocaleDateString() : 'N/A'}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                );
            case 'financials':
                return (
                    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
                        <div id="financials-section" className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <ChartCard title="Cash Flow Analysis" subtitle="Money In (Sales) vs Money Out (Expenses)">
                                <BarChart data={analytics.comprehensive?.financialFlow || []}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                                    <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
                                    <YAxis stroke="#94a3b8" fontSize={12} tickFormatter={(val) => `$${val}`} />
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }} />
                                    <Legend />
                                    <Bar dataKey="in" fill="#10b981" name="Money In (Dakhli)" radius={[4, 4, 0, 0]} />
                                    <Bar dataKey="out" fill="#f43f5e" name="Money Out (Kharash)" radius={[4, 4, 0, 0]} />
                                </BarChart>
                            </ChartCard>
                            <ChartCard title="Monthly Expense Burn" subtitle="Spending trend over 6 months">
                                <AreaChart data={analytics.expenses?.monthlyBurn || []}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                                    <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
                                    <YAxis stroke="#94a3b8" fontSize={12} />
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }} />
                                    <Area type="monotone" dataKey="total" stroke="#f43f5e" strokeWidth={3} fillOpacity={1} fill="url(#colorBurn)" />
                                    <defs>
                                        <linearGradient id="colorBurn" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                </AreaChart>
                            </ChartCard>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <ChartCard title="Expense Breakdown" subtitle="Spending by category">
                                <PieChart>
                                    <Pie data={analytics.expenses?.categoryBreakdown || []} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                                        {analytics.expenses?.categoryBreakdown?.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={['#f43f5e', '#ec4899', '#f97316', '#8b5cf6'][index % 4]} stroke="none" />
                                        ))}
                                    </Pie>
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }} />
                                    <Legend />
                                </PieChart>
                            </ChartCard>
                            <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm">
                                <h3 className="text-white font-bold mb-6 flex items-center"><History className="text-purple-400 mr-2" size={20} /> Lacag bixinta alaab-qeybiyeyaasha</h3>
                                <div className="space-y-4">
                                    {(analytics.comprehensive?.supplierVolume || []).map((s, i) => (
                                        <div key={i} className="flex justify-between items-center p-3 rounded-xl bg-white/5 border border-white/5">
                                            <span className="text-slate-300 font-medium">{s.name}</span>
                                            <span className="text-white font-bold">${parseFloat(s.value || 0).toLocaleString()}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                );
            case 'customers':
                return (
                    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <ChartCard title="Credit vs Recovery" subtitle="Credit history (last 30 days)">
                                <ComposedChart data={analytics.walpo || []}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} />
                                    <YAxis stroke="#94a3b8" fontSize={12} />
                                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px' }} />
                                    <Bar dataKey="issued" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Credit Issued" />
                                    <Line type="monotone" dataKey="recovered" stroke="#10b981" strokeWidth={3} name="Recovery" />
                                    <Legend />
                                </ComposedChart>
                            </ChartCard>
                            <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm">
                                <h3 className="text-white font-bold mb-6 flex items-center"><History className="text-rose-400 mr-2" size={20} /> Deymaha La Masaxay (Written-off)</h3>
                                <table className="w-full text-left">
                                    <thead>
                                        <tr className="text-xs text-slate-500 uppercase">
                                            <th className="pb-4">Macmiilka</th>
                                            <th className="pb-4">Amount</th>
                                            <th className="pb-4">Date</th>
                                        </tr>
                                    </thead>
                                    <tbody className="text-sm">
                                        {(analytics.comprehensive?.writtenOff || []).map((d, i) => (
                                            <tr key={i} className="border-t border-[#334155]/20 group">
                                                <td className="py-4 text-white">{d.full_name}</td>
                                                <td className="py-4 text-rose-400 font-bold">${parseFloat(d.remaining_amount || 0).toFixed(2)}</td>
                                                <td className="py-4 text-slate-500">{d.date ? new Date(d.date).toLocaleDateString() : 'N/A'}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 pb-20">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-secondary/20 p-8 rounded-3xl border border-[#334155] backdrop-blur-md relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                <div className="relative z-10">
                    <h1 className="text-4xl font-extrabold text-white mb-2 tracking-tight">Xarunta <span className="text-blue-500">Warbixinada</span></h1>
                    <p className="text-slate-400 text-lg">Indha-indhaynta guud ee ganacsiga iyo dakhliga.</p>
                </div>
                <div className="relative z-10 flex flex-wrap md:flex-row md:items-end gap-4">
                    <div className="space-y-2">
                        <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">Start Date</label>
                        <input 
                            type="date" 
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                            className="bg-primary/50 border border-[#334155] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 text-sm"
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">End Date</label>
                        <input 
                            type="date" 
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                            className="bg-primary/50 border border-[#334155] rounded-xl px-4 py-2.5 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 text-sm"
                        />
                    </div>
                    <button 
                        onClick={fetchAllData}
                        className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-sm font-bold transition-all border border-[#334155] shadow-lg"
                    >
                        Search
                    </button>
                    <button 
                        onClick={() => window.print()} 
                        className="flex items-center space-x-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-bold transition-all shadow-xl shadow-blue-500/20 active:scale-95 group"
                    >
                        <Printer size={20} className="group-hover:translate-y-0.5 transition-transform" />
                        <span>Print Report</span>
                    </button>
                </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex items-center space-x-2 bg-secondary/30 p-2 rounded-2xl border border-[#334155] w-fit overflow-x-auto no-scrollbar max-w-full">
                {tabs.map((tab) => {
                    const Icon = tab.icon;
                    const isActive = activeTab === tab.id;
                    return (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`flex items-center space-x-3 px-6 py-3.5 rounded-xl text-sm font-bold transition-all duration-300 whitespace-nowrap ${
                                isActive 
                                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20 scale-105' 
                                : 'text-slate-400 hover:text-white hover:bg-white/5'
                            }`}
                        >
                            <Icon size={20} className={isActive ? 'animate-pulse' : ''} />
                            <span>{tab.label}</span>
                        </button>
                    );
                })}
            </div>

            {/* Tab Content */}
            <div className="relative">
                {renderContent()}
            </div>

            {/* Footer Status */}
            <div className="flex items-center justify-between text-[11px] text-slate-500 bg-secondary/20 px-6 py-3 rounded-xl border border-[#334155]/30 print:hidden">
                <div className="flex items-center">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full mr-2 animate-pulse"></div>
                    Database system synchronized
                </div>
                <div>Last updated: {new Date().toLocaleTimeString()}</div>
            </div>

            {/* Branded Print Header & Template */}
            <div className="hidden print:block absolute top-0 left-0 right-0 bg-white min-h-screen text-slate-900">
                <style dangerouslySetInnerHTML={{ __html: `
                    @media print {
                        body { background: white !important; color: black !important; margin: 0; padding: 0; }
                        .print-page { 
                            page-break-after: always; 
                            padding: 40px; 
                            min-height: 100vh;
                            display: flex;
                            flex-direction: column;
                        }
                        .print-footer {
                            margin-top: auto;
                            padding-top: 20px;
                            border-t: 1px solid #e2e8f0;
                        }
                        .recharts-cartesian-grid-vertical line, .recharts-cartesian-grid-horizontal line { stroke: #e2e8f0 !important; }
                        .recharts-text { fill: #475569 !important; font-weight: bold !important; }
                        canvas { filter: grayscale(0) !important; }
                    }
                `}} />

                {/* --- PAGE 1: SUMMARY & OBSERVATIONS --- */}
                <div className="print-page border-b-8 border-slate-900">
                    <div className="flex justify-between items-start border-b-4 border-slate-950 pb-6 mb-8">
                        <div className="flex items-center space-x-6">
                            {settings.store_logo && (
                                <img 
                                    src={`http://localhost:8000/storage/${settings.store_logo}`} 
                                    alt="Logo" 
                                    className="w-24 h-24 object-contain"
                                />
                            )}
                            <div>
                                <h1 className="text-5xl font-black text-slate-950 uppercase tracking-tighter">{settings.store_name}</h1>
                                <p className="text-blue-600 font-black uppercase tracking-[0.2em] text-[10px] mt-2">Official Business Report</p>
                            </div>
                        </div>
                        <div className="text-right text-xs text-slate-700 font-bold leading-relaxed">
                            <p>{settings.store_address}</p>
                            <p>{settings.store_number}</p>
                            <span className="text-blue-400">{settings.store_name}</span>
                        </div>
                    </div>

                    <div className="grid grid-cols-3 gap-6 mb-10">
                        <div className="col-span-1 bg-slate-50 p-5 rounded-2xl border-2 border-slate-100">
                            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Report Period</h3>
                            <div className="space-y-1">
                                <p className="text-[10px] text-slate-400 font-bold uppercase">From: <span className="text-slate-900">{startDate || 'N/A'}</span></p>
                                <p className="text-[10px] text-slate-400 font-bold uppercase">To: <span className="text-slate-900">{endDate || 'N/A'}</span></p>
                            </div>
                        </div>
                        <div className="col-span-2 bg-slate-50 p-5 rounded-2xl border-2 border-slate-100 flex justify-around">
                            <div className="text-center">
                                <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Total Revenue</p>
                                <p className="text-2xl font-black text-emerald-600">{formatPrintValue(stats?.system_overview?.total_revenue, true)}</p>
                            </div>
                            <div className="text-center">
                                <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Today's Sales</p>
                                <p className="text-2xl font-black text-slate-900">{formatPrintValue(stats?.summary?.today_sales)}</p>
                            </div>
                            <div className="text-center">
                                <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Active Customers</p>
                                <p className="text-2xl font-black text-blue-600">{formatPrintValue(stats?.summary?.total_customers)}</p>
                            </div>
                            <div className="text-center">
                                <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Alaab Gabaabsi</p>
                                <p className="text-2xl font-black text-rose-600">{formatPrintValue(stats?.summary?.low_stock_count)}</p>
                            </div>
                        </div>
                    </div>

                    <section className="mb-10">
                        <h2 className="text-lg font-black text-slate-950 border-l-8 border-blue-600 pl-4 mb-6 uppercase tracking-tight">Business Observations</h2>
                        <div className="grid grid-cols-2 gap-x-12 gap-y-6">
                            {[
                                { label: 'Total Money In (Revenue + Recovery)', val: analytics.comprehensive?.financialFlow?.[(analytics.comprehensive?.financialFlow?.length || 0) - 1]?.in },
                                { label: 'Total Money Out (Exp + Purchases)', val: analytics.comprehensive?.financialFlow?.[(analytics.comprehensive?.financialFlow?.length || 0) - 1]?.out },
                                { label: 'Net Business Profit', val: analytics.comprehensive?.financialFlow?.[(analytics.comprehensive?.financialFlow?.length || 0) - 1]?.profit, highlight: 'text-blue-600' },
                                { label: 'Top Product (Quantity)', val: analytics.comprehensive?.mostPurchased?.[0]?.name, isString: true }
                            ].map((item, i) => (
                                <div key={i} className="flex justify-between items-center py-3 border-b border-slate-100">
                                    <span className="text-sm font-bold text-slate-600">{item.label}</span>
                                    <span className={`text-sm font-black ${item.highlight || 'text-slate-950'}`}>
                                        {item.isString ? (item.val || 'N/A') : formatPrintValue(item.val, true)}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </section>

                    <div className="print-footer pt-6 border-t border-slate-100 flex justify-between items-center text-[9px] text-slate-400 font-black uppercase tracking-[0.3em]">
                        <p>Page 1 - {settings.store_name}</p>
                        <p>Timestamp: {new Date().toLocaleString()}</p>
                    </div>
                </div>

                {/* --- PAGE 2: SOURCE ANALYSIS & CHARTS --- */}
                <div className="print-page">
                    <div className="flex justify-between items-start border-b-2 border-slate-200 pb-4 mb-8">
                        <h2 className="text-xl font-black text-slate-950 uppercase">Financial Analysis</h2>
                        <span className="text-[10px] font-bold text-slate-400">Official Departmental Report</span>
                    </div>

                    <section className="mb-12">
                        <h2 className="text-md font-black text-slate-950 border-l-4 border-emerald-600 pl-3 mb-6 uppercase">Income Source Breakdown</h2>
                        <div className="grid grid-cols-3 gap-6">
                            {[
                                { label: 'POS Cash Income', val: analytics.comprehensive?.posIncome?.cash, color: 'text-emerald-600' },
                                { label: 'EVC+ Plus Digital', val: analytics.comprehensive?.posIncome?.evc, color: 'text-blue-600' },
                                { label: 'Shilin Somali', val: analytics.comprehensive?.posIncome?.shilin, color: 'text-amber-600' }
                            ].map((item, i) => (
                                <div key={i} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-center">
                                    <p className="text-[9px] text-slate-400 font-bold uppercase mb-2">{item.label}</p>
                                    <p className={`text-xl font-black ${item.color}`}>{formatPrintValue(item.val, true)}</p>
                                </div>
                            ))}
                        </div>
                    </section>

                    <section className="mb-12">
                        <h2 className="text-md font-black text-slate-950 border-l-4 border-rose-600 pl-3 mb-6 uppercase">Expense Analysis</h2>
                        <div className="grid grid-cols-3 gap-6">
                            {[
                                { label: 'Total Operating Expenses', val: analytics.expenses?.categoryBreakdown?.reduce((acc, curr) => acc + curr.value, 0) || 0, color: 'text-rose-600' },
                                { label: 'Supplier Payments', val: analytics.comprehensive?.supplierVolume?.reduce((acc, curr) => acc + curr.value, 0) || 0, color: 'text-purple-600' },
                                { label: 'Written-off Debts', val: analytics.comprehensive?.writtenOff?.reduce((acc, curr) => acc + curr.remaining_amount, 0) || 0, color: 'text-slate-600' }
                            ].map((item, i) => (
                                <div key={i} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-center">
                                    <p className="text-[9px] text-slate-400 font-bold uppercase mb-2">{item.label}</p>
                                    <p className={`text-xl font-black ${item.color}`}>{formatPrintValue(item.val, true)}</p>
                                </div>
                            ))}
                        </div>
                    </section>

                    <div className="print-footer mt-auto pt-6 border-t border-slate-100 flex justify-between items-center text-[9px] text-slate-400 font-black uppercase tracking-[0.3em]">
                        <div className="flex items-center space-x-4">
                            <span>Page 2 - {settings.store_name}</span>
                        </div>
                        <div className="flex items-center space-x-6">
                            {settings.facebook_show && <span>FB: {settings.facebook_handle}</span>}
                            {settings.whatsapp_show && <span>WA: {settings.whatsapp_number}</span>}
                            {settings.tiktok_show && <span>TK: {settings.tiktok_handle}</span>}
                        </div>
                    </div>
                </div>

                {/* --- PAGE 3: PERFORMANCE VISUALS (HORIZONTAL CHARTS) --- */}
                <div className="print-page">
                    <div className="flex justify-between items-start border-b-2 border-slate-200 pb-4 mb-8">
                        <h2 className="text-xl font-black text-slate-950 uppercase">Performance Metrics</h2>
                        <span className="text-[10px] font-bold text-slate-400">Visual Data Representation</span>
                    </div>

                    <div className="flex flex-row gap-4 h-[400px] mb-12">
                        <div className="flex-1 bg-slate-50 p-6 rounded-3xl border border-slate-100">
                            <h3 className="text-xs font-black text-slate-900 mb-6 flex items-center">
                                <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                                Top Revenue Categories
                            </h3>
                            <ResponsiveContainer width="100%" height="80%">
                                <BarChart data={analytics.products?.revenueByCategory || []}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                    <XAxis dataKey="name" fontSize={8} fontWeight="bold" />
                                    <YAxis fontSize={8} fontWeight="bold" tickFormatter={(v) => `$${v}`} />
                                    <Bar dataKey="value" fill="#2563eb" radius={[4, 4, 0, 0]} />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>

                        <div className="flex-1 bg-slate-50 p-6 rounded-3xl border border-slate-100">
                            <h3 className="text-xs font-black text-slate-900 mb-6 flex items-center">
                                <span className="w-2 h-2 bg-emerald-600 rounded-full mr-2"></span>
                                Stock Distribution
                            </h3>
                            <ResponsiveContainer width="100%" height="80%">
                                <PieChart>
                                    <Pie 
                                        data={analytics.products?.stockByCategory || []} 
                                        cx="50%" cy="50%" 
                                        innerRadius={30} outerRadius={50} 
                                        paddingAngle={5} 
                                        dataKey="value"
                                    >
                                        {analytics.products?.stockByCategory?.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6'][index % 4]} stroke="none" />
                                        ))}
                                    </Pie>
                                    <Legend iconSize={10} fontSize={8} />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    <section>
                        <h2 className="text-md font-black text-slate-950 border-l-4 border-amber-600 pl-3 mb-6 uppercase">Stagnant Inventory Items</h2>
                        <table className="w-full text-left">
                            <thead className="bg-slate-100">
                                <tr className="text-[8px] text-slate-500 uppercase">
                                    <th className="p-3">Product Name</th>
                                    <th className="p-3">Current Stock</th>
                                    <th className="p-3">Unit Price</th>
                                    <th className="p-3">Stock Value</th>
                                </tr>
                            </thead>
                            <tbody className="text-[10px] font-bold">
                                {(analytics.comprehensive?.stagnantStock || []).slice(0, 15).map((p, i) => (
                                    <tr key={i} className="border-b border-slate-50">
                                        <td className="p-3 text-slate-900">{p.name || 'Product'}</td>
                                        <td className="p-3 text-slate-500">{formatPrintValue(p.current_stock) ? `${p.current_stock} units` : ''}</td>
                                        <td className="p-3 text-slate-900 font-black">{formatPrintValue(p.selling_price, true)}</td>
                                        <td className="p-3 text-emerald-600 font-extrabold">{formatPrintValue((parseFloat(p.selling_price || 0) * (p.current_stock || 0)), true)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </section>

                    <div className="print-footer mt-auto pt-6 border-t border-slate-100">
                        <div className="flex justify-center gap-6 mb-3 text-[10px] font-bold text-slate-600">
                            {settings.facebook_show && <span><strong>FB:</strong> {settings.facebook_handle}</span>}
                            {settings.instagram_show && <span><strong>IG:</strong> {settings.instagram_handle}</span>}
                            {settings.tiktok_show && <span><strong>TikTok:</strong> {settings.tiktok_handle}</span>}
                            {settings.whatsapp_show && <span><strong>WA:</strong> {settings.whatsapp_number}</span>}
                        </div>
                        <div className="flex justify-between items-center text-[9px] text-slate-400 font-black uppercase tracking-[0.3em]">
                            <p>Page 3 - So'Mali POS System</p>
                            <p>Official Internal Document - Confidential</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ReportsPage;

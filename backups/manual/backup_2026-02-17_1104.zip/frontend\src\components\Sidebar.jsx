import React, { useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { 
    LayoutDashboard, 
    Package, 
    Users, 
    ShoppingCart, 
    TrendingUp, 
    Settings,
    CreditCard,
    Truck,
    ChevronRight,
    Search,
    UserPlus,
    FileBarChart,
    History
} from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { AuthContext } from '../context/AuthContext';
import { useLanguage } from '../context/useLanguage';
import { useSettings } from '../context/SettingsContextDef';

function cn(...inputs) {
  return twMerge(clsx(inputs));
}

const Sidebar = () => {
    const { user } = useContext(AuthContext);
    const { t } = useLanguage();
    const { settings } = useSettings();

    const menuItems = [
        { key: 'dashboard', icon: LayoutDashboard, path: '/', roles: ['admin', 'cashier'] },
        { key: 'products', icon: Package, path: '/products', roles: ['admin'] },
        { key: 'customers', icon: Users, path: '/customers', roles: ['admin', 'cashier'] },
        { key: 'pos', icon: ShoppingCart, path: '/pos', roles: ['admin', 'cashier'] },
        { key: 'sales_history', icon: History, path: '/sales-history', roles: ['admin', 'cashier'] },
        { key: 'expenses', icon: CreditCard, path: '/expenses', roles: ['admin', 'cashier'] },
        { key: 'suppliers', icon: Truck, path: '/suppliers', roles: ['admin'] },
        { key: 'accounting', icon: FileBarChart, path: '/accounting', roles: ['admin'] },
        { key: 'purchases', icon: Truck, path: '/purchases', roles: ['admin'] },
        { key: 'walpo', icon: CreditCard, path: '/walpo', roles: ['admin', 'cashier'] },
        { key: 'reports', icon: TrendingUp, path: '/reports', roles: ['admin', 'cashier'] },
        { key: 'users', icon: UserPlus, path: '/users', roles: ['admin'] },
        { key: 'logs', icon: History, path: '/logs', roles: ['admin'] },
        { key: 'settings', icon: Settings, path: '/settings', roles: ['admin'] },
    ];

    const filteredMenuItems = menuItems.filter(item => 
        item.roles.includes(user?.role || 'cashier')
    );

    return (
        <div className="w-72 h-screen sticky top-0 bg-secondary/50 border-r border-[#334155] flex flex-col p-6 backdrop-blur-xl">
            <div className="flex items-center space-x-3 mb-12 px-2">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-600/20">
                    <TrendingUp size={24} className="text-white" />
                </div>
                <div>
                    <span className="text-xl font-bold tracking-tight text-white block">{settings.store_name}</span>
                    <span className="text-[10px] text-blue-400 font-bold uppercase tracking-widest">{user?.role}</span>
                </div>
            </div>

            <nav className="flex-1 space-y-2 overflow-y-auto pr-2 custom-scrollbar">
                {filteredMenuItems.map((item) => (
                    <NavLink
                        key={item.path}
                        to={item.path}
                        className={({ isActive }) => cn(
                            "flex items-center justify-between px-4 py-3 rounded-xl group",
                            isActive 
                                ? "bg-blue-600/10 text-blue-400 border border-blue-500/20 shadow-inner" 
                                : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                        )}
                    >
                        <div className="flex items-center space-x-3">
                            <item.icon size={20} />
                            <span className="font-medium">{t(item.key)}</span>
                        </div>
                        <ChevronRight size={16} className="opacity-0 group-hover:opacity-100" />
                    </NavLink>
                ))}
            </nav>

            <div className="mt-auto p-4 bg-slate-800/30 rounded-2xl border border-[#334155]">
                <p className="text-xs text-slate-500 font-bold uppercase mb-2">{settings.store_name}</p>
                <div className="flex items-center justify-between">
                    <NavLink to="/profile" className="flex items-center space-x-3 group flex-1">
                        <div className="w-10 h-10 rounded-full bg-blue-600/10 flex items-center justify-center text-blue-400 font-bold border border-blue-500/20 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                            {user?.full_name?.[0] || 'A'}
                        </div>
                        <div>
                            <p className="text-sm text-white font-bold group-hover:text-blue-400 transition-colors">{user?.full_name || user?.username}</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{user?.role}</p>
                        </div>
                    </NavLink>
                    <button 
                        onClick={() => {
                        localStorage.removeItem('token');
                        window.location.href = '/login';
                    }}
                    className="flex p-2 bg-slate-800 hover:bg-rose-500/10 hover:text-rose-400 text-slate-400 rounded-lg transition-all border border-[#334155]"
                    title={t('logout')}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-log-out"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
                </button>
            </div>
        </div>
        </div>
    );
};

export default Sidebar;

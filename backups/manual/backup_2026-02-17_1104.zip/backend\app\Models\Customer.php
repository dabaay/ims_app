<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends Model
{
    use SoftDeletes;
    protected $primaryKey = 'customer_id';

    protected $fillable = [
        'full_name',
        'phone',
        'address',
        'id_number',
        'credit_limit',
        'current_balance',
        'total_purchases',
        'last_purchase_date',
        'status',
        'registered_by',
        'notes',
    ];

    protected $casts = [
        'credit_limit' => 'decimal:2',
        'current_balance' => 'decimal:2',
        'total_purchases' => 'decimal:2',
        'last_purchase_date' => 'date',
        'registration_date' => 'datetime',
    ];

    public function registrar()
    {
        return $this->belongsTo(User::class, 'registered_by', 'user_id');
    }

    public function sales()
    {
        return $this->hasMany(Sale::class, 'customer_id', 'customer_id');
    }

    public function debts()
    {
        return $this->hasMany(Debt::class, 'customer_id', 'customer_id');
    }
}


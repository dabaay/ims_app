import React, { useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { 
    LayoutDashboard, 
    Package, 
    Users, 
    ShoppingCart, 
    TrendingUp, 
    Settings,
    CreditCard,
    Truck,
    ChevronRight,
    Search,
    UserPlus,
    FileBarChart,
    History
} from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { AuthContext } from '../context/AuthContext';

function cn(...inputs) {
  return twMerge(clsx(inputs));
}

const Sidebar = () => {
    const { user } = useContext(AuthContext);

    const menuItems = [
        { name: 'Dashboard', icon: LayoutDashboard, path: '/', roles: ['admin', 'cashier'] },
        { name: 'Alaabada', icon: Package, path: '/products', roles: ['admin', 'cashier'] },
        { name: 'Macaamiisha', icon: Users, path: '/customers', roles: ['admin', 'cashier'] },
        { name: 'Iibka (POS)', icon: ShoppingCart, path: '/pos', roles: ['admin', 'cashier'] },
        { name: 'Diiwaanka Iibka', icon: History, path: '/sales-history', roles: ['admin', 'cashier'] },
        { name: 'Kharashaadka', icon: CreditCard, path: '/expenses', roles: ['admin', 'cashier'] },
        { name: 'Suppliers', icon: Truck, path: '/suppliers', roles: ['admin'] },
        { name: 'Accounting', icon: FileBarChart, path: '/accounting', roles: ['admin'] },
        { name: 'Purchases (Stock)', icon: Truck, path: '/purchases', roles: ['admin'] },
        { name: 'Walpo (DEEN)', icon: CreditCard, path: '/walpo', roles: ['admin', 'cashier'] },
        { name: 'Warbixinada', icon: TrendingUp, path: '/reports', roles: ['admin', 'cashier'] },
        { name: 'Isticmaalayaasha', icon: UserPlus, path: '/users', roles: ['admin'] },
        { name: 'System Logs', icon: History, path: '/logs', roles: ['admin'] },
        { name: 'Settings', icon: Settings, path: '/settings', roles: ['admin'] },
    ];

    const filteredMenuItems = menuItems.filter(item => 
        item.roles.includes(user?.role || 'cashier')
    );

    return (
        <div className="w-72 h-screen sticky top-0 bg-secondary/50 border-r border-[#334155] flex flex-col p-6 backdrop-blur-xl">
            <div className="flex items-center space-x-3 mb-12 px-2">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-600/20">
                    <TrendingUp size={24} className="text-white" />
                </div>
                <div>
                    <span className="text-xl font-bold tracking-tight text-white block">So'Mali Store</span>
                    <span className="text-[10px] text-blue-400 font-bold uppercase tracking-widest">{user?.role}</span>
                </div>
            </div>

            <nav className="flex-1 space-y-2 overflow-y-auto pr-2 custom-scrollbar">
                {filteredMenuItems.map((item) => (
                    <NavLink
                        key={item.path}
                        to={item.path}
                        className={({ isActive }) => cn(
                            "flex items-center justify-between px-4 py-3 rounded-xl group",
                            isActive 
                                ? "bg-blue-600/10 text-blue-400 border border-blue-500/20 shadow-inner" 
                                : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                        )}
                    >
                        <div className="flex items-center space-x-3">
                            <item.icon size={20} />
                            <span className="font-medium">{item.name}</span>
                        </div>
                        <ChevronRight size={16} className="opacity-0 group-hover:opacity-100" />
                    </NavLink>
                ))}
            </nav>

            <div className="mt-auto p-4 bg-slate-800/30 rounded-2xl border border-[#334155]">
                <p className="text-xs text-slate-500 font-bold uppercase mb-2">Logged in as: Admin Somali Store</p>
                <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-blue-600/10 flex items-center justify-center text-blue-400 font-bold border border-blue-500/20">
                        {user?.full_name?.[0] || 'A'}
                    </div>
                    <div>
                        <p className="text-sm text-white font-bold">{user?.full_name || user?.username}</p>
                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{user?.role}</p>
                    </div>
                </div>
                <NavLink 
                    to="/login"
                    onClick={() => {
                        localStorage.removeItem('token');
                        window.location.href = '/login';
                    }}
                    className="w-full flex items-center justify-center space-x-2 py-2 bg-slate-800 hover:bg-rose-500/10 hover:text-rose-400 text-slate-400 rounded-lg text-xs font-bold transition-all border border-[#334155]"
                >
                    <span>Sign out to Login Page</span>
                </NavLink>
            </div>
        </div>
    );
};

export default Sidebar;

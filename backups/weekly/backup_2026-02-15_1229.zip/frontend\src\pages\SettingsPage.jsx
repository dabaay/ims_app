import React, { useState } from 'react';
import api from '../api/axios';
import Modal from '../components/Modal';
import { 
    Settings as SettingsIcon, 
    User, 
    Bell, 
    Shield, 
    Database, 
    Globe, 
    HardDrive,
    Save,
    CreditCard,
    ChevronRight,
    Loader2,
    Lock,
    Eye,
    EyeOff
} from 'lucide-react';

const SettingsSection = ({ title, description, children }) => (
    <div className="bg-secondary/40 border border-[#334155] p-8 rounded-3xl backdrop-blur-sm space-y-6 shadow-xl">
        <div>
            <h2 className="text-xl font-bold text-white mb-2">{title}</h2>
            <p className="text-slate-400 text-sm">{description}</p>
        </div>
        <div className="space-y-4">
            {children}
        </div>
    </div>
);

const Toggle = ({ label, enabled, onChange }) => (
    <div className="flex items-center justify-between py-2">
        <span className="text-slate-300 font-medium">{label}</span>
        <button 
            onClick={() => onChange(!enabled)}
            className={`w-12 h-6 rounded-full transition-colors relative ${enabled ? 'bg-blue-600' : 'bg-slate-700'}`}
        >
            <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${enabled ? 'translate-x-6' : ''}`}></div>
        </button>
    </div>
);

const SettingsPage = () => {
    const [notifications, setNotifications] = useState(true);
    const [lowStockAlert, setLowStockAlert] = useState(true);
    const [saving, setSaving] = useState(false);
    const [saved, setSaved] = useState(false);

    // Password change state
    const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
    const [passwordData, setPasswordData] = useState({
        current_password: '',
        new_password: '',
        confirm_password: ''
    });
    const [passLoading, setPassLoading] = useState(false);
    const [passError, setPassError] = useState('');
    const [passSuccess, setPassSuccess] = useState('');

    const handleSave = () => {
        setSaving(true);
        setTimeout(() => {
            setSaving(false);
            setSaved(true);
            setTimeout(() => setSaved(false), 3000);
        }, 1000);
    };

    const handlePasswordChange = async (e) => {
        e.preventDefault();
        setPassError('');
        setPassSuccess('');

        if (passwordData.new_password !== passwordData.confirm_password) {
            setPassError('Password-ada cusub isuma midna.');
            return;
        }

        setPassLoading(true);
        try {
            await api.post('/change-password', {
                current_password: passwordData.current_password,
                new_password: passwordData.new_password
            });
            setPassSuccess('Password-ka waa la bedelay!');
            setPasswordData({ current_password: '', new_password: '', confirm_password: '' });
            setTimeout(() => setIsPasswordModalOpen(false), 2000);
        } catch (error) {
            setPassError(error.response?.data?.message || 'Khalad ayaa dhacay.');
        } finally {
            setPassLoading(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
            {/* ... title section ... */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-1">Dookhyada (Settings)</h1>
                    <p className="text-slate-400">Habaynta nidaamka iyo xogta dukaanka.</p>
                </div>
                <button 
                    onClick={handleSave}
                    disabled={saving}
                    className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-bold transition-all shadow-lg ${
                        saved ? 'bg-emerald-600' : 'bg-blue-600 hover:bg-blue-500'
                    } text-white shadow-blue-500/20`}
                >
                    {saving ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                    <span>{saved ? 'Waa la keydiyay!' : 'Keydi Isbedelka'}</span>
                </button>
            </div>

            <div className="grid grid-cols-1 gap-8">
                {/* General Settings */}
                <SettingsSection 
                    title="Habaynta Guud" 
                    description="Xogta dukaanka iyo luuqadda nidaamka."
                >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">Magaca Dukaanka</label>
                            <input 
                                type="text" 
                                defaultValue="So'Mali Store"
                                className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">Currency Code</label>
                            <input 
                                type="text" 
                                defaultValue="USD ($)"
                                className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                            />
                        </div>
                    </div>
                </SettingsSection>

                {/* Notifications */}
                <SettingsSection 
                    title="Wargelinta (Notifications)" 
                    description="Xakamee sida nidaamku kuu ogeysiinayo xogta."
                >
                    <Toggle label="Wargelinta Desktop-ka" enabled={notifications} onChange={setNotifications} />
                    <Toggle label="Ogeysiiska Alaabta Gabaabsi ah" enabled={lowStockAlert} onChange={setLowStockAlert} />
                </SettingsSection>

                {/* Security & System */}
                <SettingsSection 
                    title="Amniga & System-ka" 
                    description="Habaynta keydka xogta iyo xisaabaadka gaarka ah."
                >
                    <div className="space-y-4">
                        <button 
                            onClick={() => setIsPasswordModalOpen(true)}
                            className="w-full flex items-center justify-between p-4 bg-slate-800/30 border border-[#334155] rounded-2xl hover:bg-slate-800/50 transition-all group"
                        >
                            <div className="flex items-center space-x-4">
                                <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                                    <Shield size={20} />
                                </div>
                                <div className="text-left">
                                    <span className="block text-white font-bold">Bedel Password-ka</span>
                                    <span className="text-xs text-slate-500">Cusboonaysii amniga xisaabtaada</span>
                                </div>
                            </div>
                            <ChevronRight size={18} className="text-slate-500" />
                        </button>
                    </div>
                </SettingsSection>
            </div>

            {/* Password Modal */}
            <Modal
                isOpen={isPasswordModalOpen}
                onClose={() => setIsPasswordModalOpen(false)}
                title="Bedel Password-ka"
            >
                <form onSubmit={handlePasswordChange} className="space-y-5">
                    {passError && <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm rounded-xl">{passError}</div>}
                    {passSuccess && <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm rounded-xl">{passSuccess}</div>}
                    
                    <div className="space-y-2">
                        <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">Password-ka Hadda</label>
                        <input 
                            required
                            type="password" 
                            className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                            value={passwordData.current_password}
                            onChange={(e) => setPasswordData({...passwordData, current_password: e.target.value})}
                        />
                    </div>
                    
                    <div className="space-y-2">
                        <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">Password-ka Cusub</label>
                        <input 
                            required
                            type="password" 
                            className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                            value={passwordData.new_password}
                            onChange={(e) => setPasswordData({...passwordData, new_password: e.target.value})}
                        />
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs text-slate-500 font-bold uppercase tracking-widest pl-1">Xaqiiji Password-ka</label>
                        <input 
                            required
                            type="password" 
                            className="w-full bg-primary/50 border border-[#334155] rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                            value={passwordData.confirm_password}
                            onChange={(e) => setPasswordData({...passwordData, confirm_password: e.target.value})}
                        />
                    </div>

                    <div className="flex justify-end pt-4">
                        <button 
                            type="submit" 
                            disabled={passLoading}
                            className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20"
                        >
                            {passLoading ? 'Waa la keydinayaa...' : 'Bedel Password'}
                        </button>
                    </div>
                </form>
            </Modal>
        </div>
    );
};

export default SettingsPage;

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Customer;
use Illuminate\Support\Facades\Auth;

class CustomerController extends Controller
{
    public function index()
    {
        $customers = Customer::paginate(50);
        return response()->json($customers);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'full_name' => 'required|max:200',
            'phone' => 'required|max:20',
            'address' => 'nullable',
            'id_number' => 'nullable|max:50',
            'credit_limit' => 'nullable|numeric',
            'notes' => 'nullable',
        ]);

        $validated['registered_by'] = Auth::id();
        $validated['registration_date'] = now();

        $customer = Customer::create($validated);
        return response()->json($customer, 201);
    }

    public function show(Customer $customer)
    {
        return response()->json($customer->load(['registrar']));
    }

    public function update(Request $request, Customer $customer)
    {
        $validated = $request->validate([
            'full_name' => 'sometimes|required|max:200',
            'phone' => 'sometimes|required|max:20',
            'credit_limit' => 'sometimes|required|numeric',
            'status' => 'sometimes|required',
        ]);

        // Prevent setting status to inactive if balance > 0
        if (isset($validated['status']) && $validated['status'] === 'inactive' && $customer->current_balance > 0) {
            return response()->json([
                'message' => 'Lama xiri karo macmiil DEEN lagu leeyahay (Cannot deactivate customer with outstanding debt).'
            ], 422);
        }

        $customer->update($validated);
        return response()->json($customer);
    }

    public function destroy(Customer $customer)
    {
        $customer->delete();
        return response()->json(null, 204);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentLog extends Model
{
    protected $primaryKey = 'log_id';

    public $timestamps = false;

    protected $fillable = [
        'gateway',
        'transaction_type',
        'request_data',
        'response_data',
        'status',
        'reference',
        'amount',
        'phone_number',
    ];

    protected $casts = [
        'request_data' => 'array',
        'response_data' => 'array',
        'amount' => 'decimal:2',
        'created_at' => 'datetime',
    ];
}

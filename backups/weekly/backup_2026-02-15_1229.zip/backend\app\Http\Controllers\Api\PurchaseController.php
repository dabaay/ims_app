<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Purchase;
use App\Models\PurchaseItem;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Traits\FinancialRecorder;

class PurchaseController extends Controller
{
    use FinancialRecorder;

    public function index()
    {
        $purchases = Purchase::with(['supplier', 'creator', 'items.product'])->orderBy('created_at', 'desc')->get();
        return response()->json($purchases);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'supplier_id' => 'required|exists:suppliers,supplier_id',
            'purchase_date' => 'required|date',
            'transport_method' => 'required|in:Bajaj,Vekon,Car,Other',
            'transport_cost' => 'required|numeric|min:0',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,product_id',
            'items.*.quantity' => 'required|integer|min:1',
            'items.*.unit_price' => 'required|numeric|min:0',
            'status' => 'required|in:pending,received,cancelled',
            'notes' => 'nullable|string',
        ]);

        return DB::transaction(function () use ($validated) {
            $totalAmount = 0;
            foreach ($validated['items'] as $item) {
                $totalAmount += $item['quantity'] * $item['unit_price'];
            }

            $purchase = Purchase::create([
                'supplier_id' => $validated['supplier_id'],
                'total_amount' => $totalAmount,
                'transport_method' => $validated['transport_method'],
                'transport_cost' => $validated['transport_cost'],
                'purchase_date' => $validated['purchase_date'],
                'status' => $validated['status'],
                'notes' => $validated['notes'],
                'created_by' => Auth::id(),
            ]);

            foreach ($validated['items'] as $itemData) {
                $totalPrice = $itemData['quantity'] * $itemData['unit_price'];
                
                PurchaseItem::create([
                    'purchase_id' => $purchase->purchase_id,
                    'product_id' => $itemData['product_id'],
                    'quantity' => $itemData['quantity'],
                    'unit_price' => $itemData['unit_price'],
                    'total_price' => $totalPrice,
                ]);

                // Update product stock if status is received
                if ($purchase->status === 'received') {
                    $product = Product::find($itemData['product_id']);
                    $product->current_stock += $itemData['quantity'];
                    $product->save();
                }
            }

            // Record transaction in accounting
            $this->recordTransaction(
                'purchase', 
                $totalAmount + $purchase->transport_cost, 
                "Iibka Supplier (ID: {$purchase->purchase_id}) - Gaadiid: {$purchase->transport_method}", 
                $purchase->purchase_id, 
                'purchases',
                'cash' // Defaulting to cash for now
            );

            return response()->json($purchase->load('items.product'), 201);
        });
    }

    public function show(Purchase $purchase)
    {
        return response()->json($purchase->load(['supplier', 'creator', 'items.product']));
    }
}

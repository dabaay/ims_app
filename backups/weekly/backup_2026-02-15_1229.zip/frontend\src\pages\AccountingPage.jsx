import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { Wallet, ArrowUpCircle, ArrowDownCircle, ScrollText, Calendar, Search, Download, FileText, Filter } from 'lucide-react';

const AccountingPage = () => {
    const [transactions, setTransactions] = useState([]);
    const [summaries, setSummaries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('ledger');
    const [search, setSearch] = useState('');

    const fetchData = React.useCallback(async () => {
        setLoading(true);
        try {
            if (activeTab === 'ledger') {
                const response = await api.get('/accounting/transactions');
                setTransactions(response.data.data || response.data || []);
            } else {
                const response = await api.get('/accounting/daily-summaries');
                setSummaries(response.data.data || response.data || []);
            }
        } catch (error) {
            console.error('Error fetching accounting data:', error);
        } finally {
            setLoading(false);
        }
    }, [activeTab]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const filteredTransactions = transactions.filter(t => 
        t.description?.toLowerCase().includes(search.toLowerCase()) || 
        t.transaction_type.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-1">Xisaabaadka (Accounting)</h1>
                    <p className="text-slate-400">Ledger-ka guud iyo warbixinada dakhliga.</p>
                </div>
                <div className="flex bg-slate-800/50 p-1 rounded-xl border border-[#334155]">
                    <button 
                        onClick={() => setActiveTab('ledger')}
                        className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${
                            activeTab === 'ledger' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                        }`}
                    >
                        Ledger-ka Guud
                    </button>
                    <button 
                        onClick={() => setActiveTab('summaries')}
                        className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${
                            activeTab === 'summaries' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                        }`}
                    >
                        Daily Summaries
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm">
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Income (Sales)</p>
                    <h3 className="text-2xl font-black text-emerald-400">
                        ${summaries.reduce((sum, s) => sum + parseFloat(s.total_sales), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </h3>
                    <div className="mt-4 pt-4 border-t border-[#334155] space-y-1">
                        <div className="flex justify-between text-[10px] text-slate-400">
                            <span>Cash:</span> <span>${summaries.reduce((sum, s) => sum + parseFloat(s.total_cash_sales || 0), 0).toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-400">
                            <span>EVC:</span> <span>${summaries.reduce((sum, s) => sum + parseFloat(s.total_evc_sales || 0), 0).toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-400">
                            <span>Shilin:</span> <span>${summaries.reduce((sum, s) => sum + parseFloat(s.total_shilin_sales || 0), 0).toFixed(2)}</span>
                        </div>
                    </div>
                </div>
                <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm shadow-lg shadow-rose-500/5">
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Expenses</p>
                    <h3 className="text-2xl font-black text-rose-400">
                        ${summaries.reduce((sum, s) => sum + parseFloat(s.total_expenses), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </h3>
                </div>
                <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm shadow-lg shadow-blue-500/5">
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Debt Collected</p>
                    <h3 className="text-2xl font-black text-blue-400">
                        ${summaries.reduce((sum, s) => sum + parseFloat(s.total_debt_collected || 0), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </h3>
                </div>
                <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm shadow-lg shadow-white/5">
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">Net Profit</p>
                    <h3 className="text-2xl font-black text-white">
                        ${summaries.reduce((sum, s) => sum + parseFloat(s.total_profit), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </h3>
                </div>
            </div>

            <div className="bg-secondary/40 border border-[#334155] rounded-3xl overflow-hidden backdrop-blur-md shadow-2xl">
                <div className="p-6 border-b border-[#334155] flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                        <input 
                            type="text" 
                            placeholder="Raadi dhaqdhaqaaq..." 
                            className="w-full pl-12 pr-4 py-3 bg-primary/50 border border-[#334155] rounded-2xl text-white outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                    <div className="flex items-center gap-3">
                        <button className="p-3 bg-slate-800 text-slate-400 border border-[#334155] rounded-xl hover:text-white transition-all">
                            <Filter size={20} />
                        </button>
                        <button className="flex items-center space-x-2 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20">
                            <Download size={20} />
                            <span>Export Data</span>
                        </button>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    {activeTab === 'ledger' ? (
                        <table className="w-full text-left">
                            <thead>
                                <tr className="bg-slate-800/50 text-slate-400 text-xs uppercase tracking-widest font-bold">
                                    <th className="px-6 py-4">Taariikhda</th>
                                    <th className="px-6 py-4">Nooca</th>
                                    <th className="px-6 py-4">Description</th>
                                    <th className="px-6 py-4 text-right">Debit (-)</th>
                                    <th className="px-6 py-4 text-right">Credit (+)</th>
                                    <th className="px-6 py-4 text-right">Balance</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-[#334155]">
                                {loading ? (
                                    <tr><td colSpan="6" className="px-6 py-12 text-center text-slate-500">Xogta waa la soo rarayaa...</td></tr>
                                ) : filteredTransactions.length === 0 ? (
                                    <tr><td colSpan="6" className="px-6 py-12 text-center text-slate-500">Ma jiraan wax dhaqdhaqaaq ah.</td></tr>
                                ) : filteredTransactions.map((t) => (
                                    <tr key={t.transaction_id} className="hover:bg-slate-800/30 transition-colors">
                                        <td className="px-6 py-4 text-xs text-slate-400 font-mono">
                                            {new Date(t.transaction_date).toLocaleString()}
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase ${
                                                t.transaction_type === 'sale' ? 'bg-emerald-500/10 text-emerald-400' :
                                                t.transaction_type === 'expense' ? 'bg-rose-500/10 text-rose-400' :
                                                'bg-blue-500/10 text-blue-400'
                                            }`}>
                                                {t.transaction_type}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-sm text-white">{t.description}</td>
                                        <td className="px-6 py-4 text-right font-bold text-rose-400">
                                            {t.debit > 0 ? `-$${t.debit}` : '-'}
                                        </td>
                                        <td className="px-6 py-4 text-right font-bold text-emerald-400">
                                            {t.credit > 0 ? `+$${t.credit}` : '-'}
                                        </td>
                                        <td className="px-6 py-4 text-right font-black text-white">
                                            ${t.balance}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <table className="w-full text-left">
                            <thead>
                                <tr className="bg-slate-800/50 text-slate-400 text-xs uppercase tracking-widest font-bold">
                                    <th className="px-6 py-4">Date</th>
                                    <th className="px-6 py-4 text-right">Income (Sales)</th>
                                    <th className="px-6 py-4 text-right">Expenses</th>
                                    <th className="px-6 py-4 text-right">Debt Collected</th>
                                    <th className="px-6 py-4 text-right">Debt Created</th>
                                    <th className="px-6 py-4 text-right">Net Profit</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-[#334155]">
                                {loading ? (
                                    <tr><td colSpan="6" className="px-6 py-12 text-center text-slate-500">Xogta waa la soo rarayaa...</td></tr>
                                ) : summaries.length === 0 ? (
                                    <tr><td colSpan="6" className="px-6 py-12 text-center text-slate-500">Ma jiraan xog kooban.</td></tr>
                                ) : summaries.map((s) => (
                                    <tr key={s.summary_id} className="hover:bg-slate-800/30 transition-colors">
                                        <td className="px-6 py-4 text-white font-bold">{s.summary_date}</td>
                                        <td className="px-6 py-4 text-right text-emerald-400 font-bold">${s.total_sales}</td>
                                        <td className="px-6 py-4 text-right text-rose-400 font-bold">${s.total_expenses}</td>
                                        <td className="px-6 py-4 text-right text-blue-400 font-bold">${s.total_debt_collected}</td>
                                        <td className="px-6 py-4 text-right text-amber-400">${s.total_debt_created}</td>
                                        <td className="px-6 py-4 text-right text-white font-black">${s.total_profit}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AccountingPage;

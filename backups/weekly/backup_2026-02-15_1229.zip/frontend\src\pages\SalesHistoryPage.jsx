import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import { AuthContext } from '../context/AuthContext';
import { Search, Printer, Calendar, FileText, ChevronRight, User, Package } from 'lucide-react';
import Modal from '../components/Modal';

const SalesHistoryPage = () => {
    // const { user } = useContext(AuthContext);
    const [sales, setSales] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [selectedSale, setSelectedSale] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        fetchSales();
    }, []);

    const fetchSales = async () => {
        try {
            const response = await api.get('/sales');
            setSales(response.data.data || response.data || []);
        } catch (error) {
            console.error('Error fetching sales:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleViewDetails = (sale) => {
        setSelectedSale(sale);
        setIsModalOpen(true);
    };

    const handlePrint = (sale) => {
        const printWindow = window.open('', '_blank');
        const itemsHtml = sale.items.map(item => `
            <tr>
                <td style="padding: 8px 0; border-bottom: 1px dashed #eee;">${item.product?.name || 'Product'} x${item.quantity}</td>
                <td style="padding: 8px 0; border-bottom: 1px dashed #eee; text-align: right;">$${(item.unit_price * item.quantity).toFixed(2)}</td>
            </tr>
        `).join('');

        printWindow.document.write(`
            <html>
                <head>
                    <title>Riskidha Iibka - Somali Store</title>
                    <style>
                        body { font-family: 'Courier New', Courier, monospace; width: 80mm; padding: 10px; margin: 0; }
                        .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 10px; }
                        .info { font-size: 12px; margin-bottom: 10px; }
                        table { width: 100%; border-collapse: collapse; font-size: 12px; }
                        .total { margin-top: 10px; border-top: 2px solid #000; padding-top: 5px; font-weight: bold; }
                        .footer { margin-top: 20px; text-align: center; font-size: 10px; }
                        @media print { .no-print { display: none; } }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h2 style="margin: 0;">SOMALI POS</h2>
                        <p style="margin: 5px 0; font-size: 11px;">Mogadishu, Somalia</p>
                        <p style="margin: 0; font-size: 11px;">Tel: +252 61XXXXXXX</p>
                    </div>
                    <div class="info">
                        <p>No: ${sale.invoice_number}</p>
                        <p>Taariikh: ${new Date(sale.sale_date).toLocaleString()}</p>
                        <p>Macmiil: ${sale.customer?.full_name || 'Macmiilka Guud'}</p>
                        <p>Macmiil: ${sale.customer?.full_name || 'Macmiilka Guud'}</p>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th style="text-align: left;">Alaabta</th>
                                <th style="text-align: right;">Qiimaha</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${itemsHtml}
                        </tbody>
                    </table>
                    <div class="total">
                        <div style="display: flex; justify-content: space-between;">
                            <span>Subtotal:</span>
                            <span>$${parseFloat(sale.subtotal).toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Discount:</span>
                            <span>$${parseFloat(sale.discount_amount).toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 16px; margin-top: 5px;">
                            <span>TOTAL:</span>
                            <span>$${parseFloat(sale.total_amount).toFixed(2)}</span>
                        </div>
                    </div>
                    <div class="footer">
                        <p>Waad ku mahadsantahay iibsashadaada!</p>
                        <p>Fadlan soo celinta alaabta waa 24 saac gudahood.</p>
                    </div>
                    <script>window.print(); window.close();</script>
                </body>
            </html>
        `);
        printWindow.document.close();
    };

    const filteredSales = sales.filter(s => 
        s.invoice_number.toLowerCase().includes(search.toLowerCase()) || 
        s.customer?.full_name?.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-1">Diiwaanka Iibka (Sales History)</h1>
                    <p className="text-slate-400">Eeg iibkii hore oo soo saar riskidhada.</p>
                </div>
            </div>

            <div className="bg-secondary/40 border border-[#334155] rounded-3xl overflow-hidden backdrop-blur-md shadow-2xl">
                <div className="p-6 border-b border-[#334155]">
                    <div className="relative max-w-md">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                        <input 
                            type="text" 
                            placeholder="Raadi Invoice No ama Macmiil..." 
                            className="w-full pl-12 pr-4 py-3 bg-primary/50 border border-[#334155] rounded-2xl text-white outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="bg-slate-800/50 text-slate-400 text-xs uppercase tracking-widest font-bold">
                                <th className="px-6 py-4">Invoice No</th>
                                <th className="px-6 py-4">Macmiilka</th>
                                <th className="px-6 py-4">Taariikhda</th>
                                <th className="px-6 py-4">Wadarta</th>
                                <th className="px-6 py-4">Status</th>
                                <th className="px-6 py-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-[#334155]">
                            {loading ? (
                                <tr>
                                    <td colSpan="6" className="px-6 py-12 text-center text-slate-500">Xogta waa la soo rarayaa...</td>
                                </tr>
                            ) : filteredSales.length === 0 ? (
                                <tr>
                                    <td colSpan="6" className="px-6 py-12 text-center text-slate-500">Ma jiro iib la helay.</td>
                                </tr>
                            ) : filteredSales.map((sale) => (
                                <tr key={sale.sale_id} className="hover:bg-slate-800/30 transition-colors group">
                                    <td className="px-6 py-4 font-mono text-xs text-blue-400 font-bold">{sale.invoice_number}</td>
                                    <td className="px-6 py-4 text-white font-medium">{sale.customer?.full_name || 'Macmiilka Guud'}</td>
                                    <td className="px-6 py-4 text-slate-400 text-sm">{new Date(sale.sale_date).toLocaleDateString()}</td>
                                    <td className="px-6 py-4 font-black text-white">${parseFloat(sale.total_amount).toFixed(2)}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${
                                            sale.payment_status === 'paid' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
                                        }`}>
                                            {sale.payment_status.toUpperCase()}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex items-center justify-end space-x-2">
                                            <button 
                                                onClick={() => handleViewDetails(sale)}
                                                className="p-2 text-slate-400 hover:text-blue-400 transition-all"
                                                title="View Details"
                                            >
                                                <FileText size={18} />
                                            </button>
                                            <button 
                                                onClick={() => handlePrint(sale)}
                                                className="p-2 text-slate-400 hover:text-emerald-400 transition-all"
                                                title="Print Receipt"
                                            >
                                                <Printer size={18} />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Sale Details Modal */}
            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title="Faahfaahinta Iibka"
            >
                {selectedSale && (
                    <div className="space-y-6">
                        <div className="grid grid-cols-2 gap-4 bg-slate-800/30 p-4 rounded-2xl border border-[#334155]">
                            <div>
                                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Invoice Number</p>
                                <p className="text-white font-bold">{selectedSale.invoice_number}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Taariikhda</p>
                                <p className="text-white font-bold">{new Date(selectedSale.sale_date).toLocaleString()}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Macmiilka</p>
                                <p className="text-white font-bold">{selectedSale.customer?.full_name || 'Macmiilka Guud'}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Cashier</p>
                                <p className="text-white font-bold">{selectedSale.cashier?.full_name || 'System'}</p>
                            </div>
                        </div>

                        <div className="space-y-3">
                            <p className="text-xs text-slate-500 font-bold uppercase tracking-widest px-1">Alaabta la iibiyay</p>
                            <div className="bg-primary/30 rounded-2xl overflow-hidden border border-[#334155]">
                                <table className="w-full text-left text-sm">
                                    <thead className="bg-slate-800/50">
                                        <tr>
                                            <th className="px-4 py-2 text-slate-400">Alaabta</th>
                                            <th className="px-4 py-2 text-center text-slate-400">Qty</th>
                                            <th className="px-4 py-2 text-right text-slate-400">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-[#334155]">
                                        {selectedSale.items.map((item, idx) => (
                                            <tr key={idx}>
                                                <td className="px-4 py-3 text-white">{item.product?.name || 'Alaab'}</td>
                                                <td className="px-4 py-3 text-center text-slate-400">{item.quantity}</td>
                                                <td className="px-4 py-3 text-right text-emerald-400 font-bold">${(item.unit_price * item.quantity).toFixed(2)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="flex justify-between items-center bg-blue-600/10 p-4 rounded-2xl border border-blue-500/20">
                            <span className="text-blue-400 font-bold">Wadarta Guud (Total)</span>
                            <span className="text-2xl font-black text-white">$${parseFloat(selectedSale.total_amount).toFixed(2)}</span>
                        </div>

                        <div className="flex justify-end space-x-3">
                            <button 
                                onClick={() => setIsModalOpen(false)}
                                className="px-6 py-2 rounded-xl bg-slate-800 text-slate-400 font-bold hover:text-white transition-all"
                            >
                                xir
                            </button>
                            <button 
                                onClick={() => handlePrint(selectedSale)}
                                className="px-6 py-2 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-500 transition-all flex items-center space-x-2"
                            >
                                <Printer size={18} />
                                <span>Print Receipt</span>
                            </button>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
};

export default SalesHistoryPage;

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthProvider';
import { useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Sidebar from './components/Sidebar';
import ProductList from './pages/ProductList';
import CustomerList from './pages/CustomerList';
import PosPage from './pages/PosPage';
import Dashboard from './pages/Dashboard';
import ReportsPage from './pages/ReportsPage';
import SettingsPage from './pages/SettingsPage';
import ExpensesPage from './pages/ExpensesPage';
import SuppliersPage from './pages/SuppliersPage';
import UsersPage from './pages/UsersPage';
import AccountingPage from './pages/AccountingPage';
import LogsPage from './pages/LogsPage';
import SalesHistoryPage from './pages/SalesHistoryPage';
import PurchasesPage from './pages/PurchasesPage';
import WalpoPage from './pages/WalpoPage';

const ProtectedRoute = ({ children }) => {
    const { user, loading } = useAuth();
    if (loading) return <div className="min-h-screen bg-primary flex items-center justify-center text-white">Xogta waa la soo rarayaa...</div>;
    if (!user) return <Navigate to="/login" />;
    return children;
};

const Layout = ({ children }) => {
    const { user } = useAuth();
    
    return (
        <div className="flex bg-primary min-h-screen">
            <Sidebar />
            <main className="flex-1 overflow-auto">
                <header className="h-16 border-b border-[#334155] flex items-center justify-end px-8 bg-secondary/30 backdrop-blur-md sticky top-0 z-10">
                    <div className="flex items-center space-x-4">
                        <div className="text-right">
                            <p className="text-sm font-bold text-white leading-none mb-1">{user?.full_name || user?.username}</p>
                            <p className="text-[10px] text-blue-400 font-bold uppercase tracking-wider">{user?.role}</p>
                        </div>
                        <div className="w-10 h-10 rounded-full bg-linear-to-tr from-blue-600 to-indigo-600 border border-blue-400/30 flex items-center justify-center font-bold text-sm text-white shadow-lg shadow-blue-500/20">
                            {user?.full_name?.split(' ').map(n => n[0]).join('').toUpperCase() || user?.username?.[0].toUpperCase()}
                        </div>
                    </div>
                </header>
                <div className="p-8">
                    {children}
                </div>
            </main>
        </div>
    );
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={
            <ProtectedRoute>
              <Layout><Dashboard /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/products" element={
            <ProtectedRoute>
              <Layout><ProductList /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/customers" element={
            <ProtectedRoute>
              <Layout><CustomerList /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/pos" element={
            <ProtectedRoute>
              <Layout><PosPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/reports" element={
            <ProtectedRoute>
              <Layout><ReportsPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/settings" element={
            <ProtectedRoute>
              <Layout><SettingsPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/expenses" element={
            <ProtectedRoute>
              <Layout><ExpensesPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/suppliers" element={
            <ProtectedRoute>
              <Layout><SuppliersPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/users" element={
            <ProtectedRoute>
              <Layout><UsersPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/accounting" element={
            <ProtectedRoute>
              <Layout><AccountingPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/logs" element={
            <ProtectedRoute>
              <Layout><LogsPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/sales-history" element={
            <ProtectedRoute>
              <Layout><SalesHistoryPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/purchases" element={
            <ProtectedRoute>
              <Layout><PurchasesPage /></Layout>
            </ProtectedRoute>
          } />
          <Route path="/walpo" element={
            <ProtectedRoute>
              <Layout><WalpoPage /></Layout>
            </ProtectedRoute>
          } />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;

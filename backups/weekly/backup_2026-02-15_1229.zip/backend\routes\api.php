<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\SupplierController;
use App\Http\Controllers\Api\LogController;
use App\Http\Controllers\Api\AccountingController;
use App\Http\Controllers\Api\NotificationController;

Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', [AuthController::class, 'me']);

    Route::apiResource('products', \App\Http\Controllers\Api\ProductController::class);
    Route::apiResource('customers', \App\Http\Controllers\Api\CustomerController::class);
    Route::apiResource('sales', \App\Http\Controllers\Api\SaleController::class);
    Route::apiResource('users', UserController::class);
    Route::apiResource('suppliers', SupplierController::class);
    Route::apiResource('expenses', \App\Http\Controllers\Api\ExpenseController::class);
    Route::apiResource('purchases', \App\Http\Controllers\Api\PurchaseController::class);
    Route::post('/change-password', [AuthController::class, 'changePassword']);
    Route::post('/suppliers/{supplier}/upload-document', [SupplierController::class, 'uploadDocument']);
    
    // Logs
    Route::get('/logs/audit', [LogController::class, 'auditLogs']);
    Route::get('/logs/backups', [LogController::class, 'backupLogs']);
    Route::get('/logs/payments', [LogController::class, 'paymentLogs']);
    
    // Accounting
    Route::get('/accounting/transactions', [AccountingController::class, 'transactions']);
    Route::get('/accounting/daily-summaries', [AccountingController::class, 'dailySummaries']);
    Route::get('/accounting/debts', [AccountingController::class, 'debts']);
    Route::get('/accounting/debt-payments', [AccountingController::class, 'debtPayments']);
    Route::post('/accounting/debt-payments', [AccountingController::class, 'storeDebtPayment']);
    
    // Notifications
    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::put('/notifications/{notification}/read', [NotificationController::class, 'markAsRead']);
    Route::delete('/notifications/{notification}', [NotificationController::class, 'destroy']);
    
    
    Route::get('/stats', [\App\Http\Controllers\Api\DashboardController::class, 'stats']);

    // Walpo (Credit Sales) routes
    Route::get('/walpo', [\App\Http\Controllers\Api\WalpoController::class, 'index']);
    Route::post('/walpo', [\App\Http\Controllers\Api\WalpoController::class, 'store']);
    Route::get('/walpo/customer/{customerId}', [\App\Http\Controllers\Api\WalpoController::class, 'getCustomerHistory']);
    Route::get('/walpo/{sale}', [\App\Http\Controllers\Api\WalpoController::class, 'show']);
    Route::post('/walpo/{sale}/delivery', [\App\Http\Controllers\Api\WalpoController::class, 'updateDelivery']);

    // Backups
    Route::get('/backups', [\App\Http\Controllers\Api\BackupController::class, 'index']);
    Route::get('/backups/download/{folder}/{filename}', [\App\Http\Controllers\Api\BackupController::class, 'download'])->name('backups.download');
    Route::post('/backups/run', [\App\Http\Controllers\Api\BackupController::class, 'runBackup']);
});

import React from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import { 
    TrendingUp, 
    Users, 
    AlertTriangle, 
    DollarSign, 
    ArrowUpRight, 
    ArrowDownRight,
    BarChart3,
    Activity
} from 'lucide-react';

const StatCard = (props) => {
    const { label, value, trend, color, icon: Icon } = props;
    const colorClasses = {
        blue: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
        emerald: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
        rose: 'text-rose-400 bg-rose-500/10 border-rose-500/20',
        amber: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
    };

    return (
        <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl hover:border-slate-500/50 transition-all group relative overflow-hidden backdrop-blur-sm">
            <div className={`absolute top-0 right-0 p-3 rounded-bl-2xl ${colorClasses[color]} opacity-20 group-hover:opacity-100 transition-opacity`}>
                <Icon size={24} />
            </div>
            <p className="text-slate-400 text-sm font-medium mb-1">{label}</p>
            <div className="flex items-end justify-between">
                <div>
                    <h4 className="text-3xl font-bold text-white tracking-tight mb-2">{value}</h4>
                    <div className="flex items-center space-x-1">
                        {trend.startsWith('+') ? (
                            <ArrowUpRight size={14} className="text-emerald-400" />
                        ) : (
                            <ArrowDownRight size={14} className="text-rose-400" />
                        )}
                        <span className={`text-xs font-bold ${trend.startsWith('+') ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {trend} <span className="text-slate-500 font-normal">tan iyo shalay</span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    );
};

const Dashboard = () => {
    const { user } = useAuth();
    const [stats, setStats] = React.useState(null);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        const fetchStats = async () => {
            try {
                const response = await api.get('/stats');
                setStats(response.data);
            } catch (error) {
                console.error('Labaad raridda stats-ka way fashilantay', error);
            } finally {
                setLoading(false);
            }
        };
        fetchStats();
    }, []);

    if (loading) return <div className="text-white">Xogta waa la soo rarayaa...</div>;

    const summaryStats = [
        { label: 'Maanta Iibkeeda', value: `$${stats?.summary?.today_sales?.toLocaleString() || '0.00'}`, trend: stats?.summary?.today_sales > stats?.summary?.yesterday_sales ? '+10%' : '-5%', color: 'blue', icon: DollarSign },
        { label: 'Macmiil Cusub', value: stats?.summary?.new_customers?.toString() || '0', trend: '+100%', color: 'emerald', icon: Users },
        { label: 'Alaab Gabaabsi ah', value: stats?.summary?.low_stock_count?.toString() || '0', trend: 'Warning', color: 'rose', icon: AlertTriangle },
        { label: 'Wadarta Macaamiisha', value: stats?.summary?.total_customers?.toString() || '0', trend: 'Total', color: 'amber', icon: TrendingUp },
    ];

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Dashboardka Guud</h1>
                    <p className="text-slate-400 text-lg">Soo dhawaaw mudane <span className="text-blue-400 font-bold">{user?.full_name}</span>, halkan ka kaga bogasho xogta maanta.</p>
                </div>
                <div className="flex items-center space-x-3 bg-secondary/50 p-1.5 rounded-xl border border-[#334155]">
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold shadow-lg shadow-blue-500/20">Maanta</button>
                    <button className="px-4 py-2 text-slate-400 hover:text-white rounded-lg text-sm font-bold transition-colors">Toddobaadkan</button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {summaryStats.map((stat, i) => (
                    <StatCard key={i} {...stat} />
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Recent Activity */}
                <div className="lg:col-span-2 bg-secondary/40 border border-[#334155] rounded-3xl p-8 backdrop-blur-sm">
                    <div className="flex items-center justify-between mb-8">
                        <div className="flex items-center space-x-3">
                            <Activity className="text-blue-400" />
                            <h2 className="text-xl font-bold text-white">Dhaqdhaqaaqii U Danbeeyay</h2>
                        </div>
                        <button className="text-sm font-bold text-blue-400 hover:underline">Eeg Dhammaan</button>
                    </div>
                    
                    <div className="space-y-6">
                        {stats?.recent_activity?.length > 0 ? stats.recent_activity.map((item, i) => (
                            <div key={i} className="flex items-center justify-between group">
                                <div className="flex items-center space-x-4">
                                    <div className="w-10 h-10 rounded-xl bg-slate-800 border border-[#334155] flex items-center justify-center font-bold text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-all">
                                        {item.customer?.full_name?.[0] || 'G'}
                                    </div>
                                    <div>
                                        <p className="text-white font-bold text-sm">
                                            {item.customer?.full_name || 'Walk-in Customer'} <span className="text-slate-500 font-normal">Iibsaday</span> {item.invoice_number}
                                        </p>
                                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{new Date(item.sale_date).toLocaleString()}</p>
                                    </div>
                                </div>
                                <span className="text-sm font-black text-emerald-400">
                                    +${item.total_amount}
                                </span>
                            </div>
                        )) : (
                            <p className="text-slate-500 text-sm">Ma jiraan wax dhaqdhaqaaq ah maanta.</p>
                        )}
                    </div>
                </div>

                {/* Top Products */}
                <div className="bg-secondary/40 border border-[#334155] rounded-3xl p-8 backdrop-blur-sm">
                    <div className="flex items-center space-x-3 mb-8">
                        <BarChart3 className="text-emerald-400" />
                        <h2 className="text-xl font-bold text-white">Alaabta Loogu Iibka Badanyahay</h2>
                    </div>
                    
                    <div className="space-y-6">
                        {stats?.top_products?.length > 0 ? stats.top_products.map((product, i) => (
                            <div key={i} className="space-y-2">
                                <div className="flex justify-between text-sm">
                                    <span className="text-white font-medium">{product.name}</span>
                                    <span className="text-slate-400">{product.current_stock} {product.unit} (Stock)</span>
                                </div>
                                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                    <div 
                                        className="h-full bg-emerald-500 rounded-full" 
                                        style={{ width: `${(product.current_stock / 100) * 100}%` }}
                                    ></div>
                                </div>
                            </div>
                        )) : (
                            <p className="text-slate-500 text-sm">Ma jiraan wax alaab ah oo la hayo.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;

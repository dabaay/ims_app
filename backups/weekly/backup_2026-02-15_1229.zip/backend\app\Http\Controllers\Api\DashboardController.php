<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Sale;
use App\Models\Customer;
use App\Models\Product;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function stats()
    {
        $today = Carbon::today();
        
        $todaySales = Sale::whereDate('sale_date', $today)->sum('total_amount');
        $yesterdaySales = Sale::whereDate('sale_date', Carbon::yesterday())->sum('total_amount');
        
        $newCustomers = Customer::whereDate('created_at', $today)->count();
        $totalCustomers = Customer::count();
        
        $lowStockCount = Product::where('current_stock', '<=', \DB::raw('minimum_stock'))->count();
        
        $recentSales = Sale::with('customer')->latest()->take(5)->get();
        
        $topProducts = Product::orderBy('current_stock', 'desc')->take(5)->get(); // Mocking top products by stock for now

        return response()->json([
            'summary' => [
                'today_sales' => $todaySales,
                'yesterday_sales' => $yesterdaySales,
                'new_customers' => $newCustomers,
                'total_customers' => $totalCustomers,
                'low_stock_count' => $lowStockCount,
            ],
            'recent_activity' => $recentSales,
            'top_products' => $topProducts,
        ]);
    }
}

import React, { useState, useEffect, useContext } from 'react';
import api from '../api/axios';
import { AuthContext } from '../context/AuthContext';
import { 
    BarChart3, 
    TrendingUp, 
    Users, 
    ShoppingCart as ShopIcon, 
    Download, 
    Calendar,
    ChevronDown,
    ArrowUpRight,
    ArrowDownRight,
    FileText,
    PieChart,
    Loader2
} from 'lucide-react';

const ReportCard = (props) => {
    const { title, value, subValue, trend, icon: Icon, color } = props;
    const colorClasses = {
        blue: 'bg-blue-500/10 text-blue-400',
        emerald: 'bg-emerald-500/10 text-emerald-400',
        amber: 'bg-amber-500/10 text-amber-400',
        indigo: 'bg-indigo-500/10 text-indigo-400',
    };
    
    return (
        <div className="bg-secondary/40 border border-[#334155] p-6 rounded-2xl backdrop-blur-sm">
            <div className="flex justify-between items-start mb-4">
                <div className={`p-3 rounded-xl ${colorClasses[color] || 'bg-slate-500/10 text-slate-400'}`}>
                    <Icon size={24} />
                </div>
            {trend !== undefined && (
                <span className={`flex items-center text-xs font-bold ${trend > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {trend > 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                    {Math.abs(trend)}%
                </span>
            )}
        </div>
        <p className="text-slate-400 text-sm font-medium mb-1">{title}</p>
        <h4 className="text-2xl font-bold text-white mb-1">{value}</h4>
            <p className="text-xs text-slate-500">{subValue}</p>
        </div>
    );
};

const ReportsPage = () => {
    const { user } = useContext(AuthContext);
    const isAdmin = user?.role === 'admin';
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchStats();
    }, []);

    const fetchStats = async () => {
        try {
            const response = await api.get('/stats');
            setStats(response.data);
        } catch (error) {
            console.error('Error fetching stats:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return (
        <div className="flex items-center justify-center h-full">
            <Loader2 className="animate-spin text-blue-500" size={40} />
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-1">Warbixinada (Reports)</h1>
                    <p className="text-slate-400">Xogta guud ee iibka iyo dhaqdhaqaaqa ganacsiga.</p>
                </div>
                {isAdmin && (
                    <div className="flex items-center gap-3">
                        <button 
                            onClick={() => {
                                if (!stats) return;
                                const csvContent = [
                                    ['Report', 'Value'],
                                    ['Total Revenue', stats.summary?.total_revenue || 0],
                                    ['Total Customers', stats.summary?.total_customers || 0],
                                    ['Today Sales', stats.summary?.today_sales || 0],
                                    ['Low Stock Count', stats.summary?.low_stock_count || 0]
                                ].map(e => e.join(",")).join("\n");
                                const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                                const url = URL.createObjectURL(blob);
                                const link = document.createElement("a");
                                link.setAttribute("href", url);
                                link.setAttribute("download", "report_stats.csv");
                                link.click();
                            }}
                            className="flex items-center space-x-2 px-4 py-2 bg-slate-800 text-slate-300 rounded-xl font-bold border border-[#334155] hover:bg-slate-700 transition-all text-sm"
                        >
                            <Download size={18} />
                            <span>Download Excel (CSV)</span>
                        </button>
                        <button 
                            onClick={() => window.print()}
                            className="flex items-center space-x-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-blue-500/20"
                        >
                            <FileText size={18} />
                            <span>Download PDF (Print)</span>
                        </button>
                    </div>
                )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {isAdmin && (
                    <ReportCard 
                        title="Dakhliga Guud" 
                        value={`$${stats?.summary?.total_revenue?.toLocaleString() || '0.00'}`} 
                        subValue="Total Revenue" 
                        trend={15} 
                        icon={TrendingUp} 
                        color="blue" 
                    />
                )}
                <ReportCard 
                    title="Macaamiilka" 
                    value={stats?.summary?.total_customers?.toString() || '0'} 
                    subValue="Active Customers" 
                    trend={8} 
                    icon={Users} 
                    color="emerald" 
                />
                {isAdmin && (
                    <ReportCard 
                        title="Dalabyada (Orders)" 
                        value={stats?.summary?.today_sales?.toString() || '0'} 
                        subValue="Today's Sales" 
                        trend={null} 
                        icon={ShopIcon} 
                        color="amber" 
                    />
                )}
                <ReportCard 
                    title="Alaab Gabaabsi" 
                    value={stats?.summary?.low_stock_count?.toString() || '0'} 
                    subValue="Low Stock Alert" 
                    trend={null} 
                    icon={BarChart3} 
                    color="indigo" 
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {isAdmin && (
                    <div className="bg-secondary/40 border border-[#334155] rounded-3xl p-8 min-h-[400px] flex flex-col backdrop-blur-sm shadow-xl">
                        <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center space-x-3">
                                <PieChart className="text-blue-400" />
                                <h2 className="text-xl font-bold text-white">Shaxda Dakhliga</h2>
                            </div>
                        </div>
                        <div className="flex-1 flex flex-col items-center justify-center space-y-4">
                            <div className="w-48 h-48 rounded-full border-8 border-blue-600 border-t-emerald-400 border-r-amber-400 animate-[spin_3s_linear_infinite]"></div>
                            <p className="text-slate-400 font-medium italic">Shaxda iibka ayaa halkan ka muuqanaysa...</p>
                        </div>
                    </div>
                )}

                <div className={`bg-secondary/40 border border-[#334155] rounded-3xl p-8 backdrop-blur-sm shadow-xl ${!isAdmin ? 'lg:col-span-2' : ''}`}>
                    <h2 className="text-xl font-bold text-white mb-8">Warbixinada Muhiimka ah</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {[
                            { name: 'Xiritaanka Khasnadda', desc: 'Daily Cashier Close', icon: FileText, adminOnly: true },
                            { name: 'Liiska Alaabta Dhamaadka ah', desc: 'Low Stock Alert', icon: ShopIcon, adminOnly: false },
                            { name: 'Warbixinta Macaamiisha', desc: 'Customer Debt Report', icon: Users, adminOnly: false },
                            { name: 'Khasaaraha & Macaashka', desc: 'P&L Statement', icon: TrendingUp, adminOnly: true },
                        ].filter(r => isAdmin || !r.adminOnly).map((report, i) => (
                            <button key={i} className="flex flex-col p-4 bg-slate-800/30 border border-[#334155] rounded-2xl hover:border-blue-500/50 hover:bg-slate-800/50 transition-all text-left group">
                                <div className="p-2 rounded-lg bg-slate-700/50 text-slate-400 mb-3 group-hover:text-blue-400 w-fit">
                                    <report.icon size={20} />
                                </div>
                                <h3 className="text-white font-bold text-sm mb-1">{report.name}</h3>
                                <p className="text-xs text-slate-500 font-medium">{report.desc}</p>
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ReportsPage;

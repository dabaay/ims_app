<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CustomerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $customers = [
            ['full_name' => 'Cali Axmed Salaad', 'phone' => '0615112233', 'address' => 'Xamar Weyne, Muqdisho'],
            ['full_name' => 'Faadumo Jaamac', 'phone' => '0615998877', 'address' => 'Hodan, Muqdisho'],
            ['full_name' => 'Cumar Geedi', 'phone' => '0612445566', 'address' => 'Warta Nabadda, Muqdisho'],
        ];

        foreach ($customers as $customer) {
            \App\Models\Customer::create($customer + ['registered_by' => 1]);
        }
    }
}
